// Real players as contacts. Each poll, online players whose callsign carries a FRIENDLY or HOSTILE
// tag become (or update) a live contact named after their ALL-CAPS callsign:
//   • friendly -> posted to the threat log + picture, never scrambled
//   • hostile  -> posted AND, when it is inside scramble airspace (/territory), a SCRAMBLE alert pings the
//                 scramble role. With no territories defined, hostiles scramble anywhere they're seen.
// A contact fades once its player hasn't been detected for LIVE_FADE_S. Tags of our own force ('us')
// are not contacts (they're patrols).
const contacts = require('../db/repos/contacts');
const tagsRepo = require('../db/repos/tags');
const config = require('../db/repos/config');
const territories = require('../db/repos/territories');
const zones = require('./territory');
const { record } = require('./logger');
const picture = require('./picture');
const { contactLine, contextFor, whereText } = require('./format');
const { toUnix, sqlNow } = require('../util/time');
const { EVENT_TYPE } = require('../util/constants');

const LIVE_FADE_S = 180;       // not detected for 3 minutes -> faded
const SCRAMBLE_REPEAT_S = 300; // a hostile hovering on a border re-scrambles at most every 5 minutes

const feetFrom = (m) => (Number.isFinite(m) ? Math.round(m * 3.28084) : 0);

function fieldsFrom(player, iff) {
  return {
    callsign: player.callsign,
    iff,
    lat: player.lat,
    lon: player.lon,
    altitude_ft: feetFrom(player.altitudeM),
    heading: Math.round(player.headingDeg ?? 0),
    speed_kt: Math.round(player.speedKt ?? 0),
  };
}

async function scramble(client, guildId, contact, player, territoryName) {
  const cfg = config.get(guildId);
  const ctx = contextFor(guildId);
  return record(client, guildId, {
    type: EVENT_TYPE.SCRAMBLE, refTable: 'contacts', refId: contact.id,
    detail: { geofsId: player.geofsId, callsign: contact.callsign },
    content: cfg.scramble_role_id ? `<@&${cfg.scramble_role_id}>` : undefined,
    allowedMentions: cfg.scramble_role_id ? { roles: [cfg.scramble_role_id], users: [] } : undefined,
    text: `**SCRAMBLE** — hostile contact **${contact.callsign}** ${territoryName ? `inside **${territoryName}**` : 'detected'}\n${whereText(contact, ctx)} · ` +
      `${contactLine(contact, ctx).split(' · ').slice(3).join(' · ')}\nGeoFS ID \`${player.geofsId}\`` +
      (cfg.scramble_role_id ? '' : '\n_No scramble role set — use `/aewc setup scramble_role:`._'),
  });
}

// Works out whether a (hostile) contact is in scramble airspace, stores that on the contact, and says
// whether to scramble NOW: only on the transition into airspace, and not again within SCRAMBLE_REPEAT_S.
function evaluateZone(contact, player, defined, prevInZone, nowUnix) {
  if (contact.iff !== 'hostile') {
    return { contact: contacts.setZone(contact.id, { inZone: false, territory: null }), scrambleIn: null };
  }
  const hit = defined.length
    ? zones.firstContaining(defined, { lat: player.lat, lon: player.lon, altitudeFt: contact.altitude_ft })
    : null;
  const eligible = defined.length === 0 || !!hit;       // no airspace defined = legacy "anywhere"
  const updated = contacts.setZone(contact.id, { inZone: eligible, territory: hit?.name ?? null });
  const last = toUnix(updated.scrambled_at);
  const cooledDown = last == null || nowUnix - last >= SCRAMBLE_REPEAT_S;
  return { contact: updated, scrambleIn: eligible && !prevInZone && cooledDown ? { name: hit?.name ?? null } : null };
}

async function sync(client, guildId, players, { nowUnix = Math.floor(Date.now() / 1000) } = {}) {
  const ctx = contextFor(guildId);
  const defined = territories.list(guildId);
  const seen = new Set();
  let changed = false;

  for (const player of players) {
    const parsed = tagsRepo.parseCallsign(guildId, player.callsign);
    if (!parsed || parsed.category === 'us') continue;
    seen.add(player.geofsId);
    const iff = parsed.category; // friendly | hostile
    const existing = contacts.getLive(guildId, player.geofsId);

    if (!existing) {
      const created = contacts.create(guildId, {
        ...fieldsFrom(player, iff), classification: 'unknown', bearing: 0, range_nm: 0,
        expires_at: sqlNow(contacts.FAR_FUTURE_S), source: 'live', geofs_id: player.geofsId,
      });
      changed = true;
      const z = evaluateZone(created, player, defined, false, nowUnix);
      await record(client, guildId, {
        type: EVENT_TYPE.CONTACT_SPAWNED, refTable: 'contacts', refId: created.id,
        detail: { live: true, geofsId: player.geofsId, iff }, text: contactLine(z.contact, ctx),
      });
      if (z.scrambleIn) await scramble(client, guildId, contacts.markScrambled(created.id), player, z.scrambleIn.name);
      continue;
    }

    const refreshed = contacts.updateLive(existing.id, fieldsFrom(player, iff));
    changed = true;
    const z = evaluateZone(refreshed, player, defined, existing.in_zone === 1, nowUnix);
    if (existing.iff !== iff) { // their tag category changed while they were on the picture
      await record(client, guildId, {
        type: EVENT_TYPE.CONTACT_ESCALATED, refTable: 'contacts', refId: existing.id,
        detail: { from: existing.iff, to: iff },
        text: `\`#${existing.id}\` **${z.contact.callsign}** reclassified ${existing.iff.toUpperCase()} → **${iff.toUpperCase()}**\n${contactLine(z.contact, ctx)}`,
      });
    }
    if (z.scrambleIn) await scramble(client, guildId, contacts.markScrambled(existing.id), player, z.scrambleIn.name);
  }

  for (const c of contacts.listLive(guildId)) {
    if (seen.has(c.geofs_id)) continue;
    const last = toUnix(c.last_seen_at) ?? toUnix(c.spawned_at);
    if (nowUnix - last < LIVE_FADE_S) continue;
    contacts.fade(c.id);
    changed = true;
    await record(client, guildId, {
      type: EVENT_TYPE.CONTACT_FADED, refTable: 'contacts', refId: c.id,
      detail: { live: true, reason: 'No longer detected' },
      text: `\`#${c.id}\` **${c.callsign}** — No longer detected`,
    });
  }

  if (changed) await picture.refresh(client, guildId);
}

module.exports = { sync, LIVE_FADE_S };
