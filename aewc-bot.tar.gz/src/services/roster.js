// The automatic callsign roster for each wing. Whenever a wing's membership, seats or ranks change, a fresh
// roster is posted in the wing's member channel (pinging the wing role) and the previous one is deleted.
// Changes are batched: many edits within DEBOUNCE_MS produce ONE post, so bulk onboarding doesn't spam pings.
const { EmbedBuilder } = require('discord.js');
const org = require('../db/repos/org');
const pilotsRepo = require('../db/repos/pilots');

let debounceMs = 10_000;
const pending = new Map(); // "guildId:wingId" -> { timer, client }

function configure({ debounce } = {}) { if (debounce !== undefined) debounceMs = debounce; }

// "LEOPARD-5 – LEOPARD-10" style summary of the free slots.
function openSlotsText(squadron, filled, wing) {
  const free = [];
  for (let s = 1; s <= squadron.slots; s++) if (!filled.has(s)) free.push(s);
  if (!free.length) return null;
  const ranges = []; let start = free[0]; let prev = free[0];
  for (const s of free.slice(1).concat([null])) {
    if (s === prev + 1) { prev = s; continue; }
    ranges.push(start === prev ? start : [start, prev]);
    start = s; prev = s;
  }
  const name = (n) => org.callsignOf(squadron, n, wing);
  return ranges.map((r) => (Array.isArray(r) ? `${name(r[0])} – ${name(r[1])}` : name(r))).join(', ');
}

// Lines for one squadron: heading + one line per filled slot (+ open-slot summary).
function squadronLines(guildId, squadron, wing, { rankOf = (id) => pilotsRepo.getByDiscord(guildId, id)?.rank_name } = {}) {
  const slots = org.slotsOf(squadron.id);
  const lines = [`**${squadron.name}** — ${slots.size}/${squadron.slots}`];
  for (const slot of [...slots.keys()].sort((a, b) => a - b)) {
    const id = slots.get(slot);
    const marks = [];
    if (squadron.squadcom_id === id) marks.push('★ SQUADCOM');
    if (wing?.wingcom_id === id) marks.push('★ WINGCOM');
    const rank = rankOf(id);
    lines.push(`\`${org.callsignOf(squadron, slot, wing)}\` — <@${id}>${rank ? ` · ${rank}` : ''}${marks.length ? ` · ${marks.join(' ')}` : ''}`);
  }
  const open = openSlotsText(squadron, slots, wing);
  if (open) lines.push(`_Open: ${open}_`);
  return lines;
}

function paginate(lines, limit = 3800) {
  const pages = []; let cur = '';
  for (const line of lines) {
    if (cur && cur.length + line.length + 1 > limit) { pages.push(cur); cur = ''; }
    cur += (cur ? '\n' : '') + line;
  }
  if (cur) pages.push(cur);
  return pages;
}

function buildEmbeds(guildId, wing) {
  const lines = [];
  if (wing.wingcom_id) lines.push(`Wing commander: <@${wing.wingcom_id}>`, '');
  const squadrons = org.squadronsInWing(wing.id);
  if (!squadrons.length) lines.push('_No squadrons in this wing yet._');
  squadrons.forEach((sq, i) => { if (i) lines.push(''); lines.push(...squadronLines(guildId, sq, wing)); });
  return paginate(lines).map((text, i) => {
    const e = new EmbedBuilder().setColor(0x3b7ddd).setDescription(text);
    if (i === 0) e.setTitle(`${wing.name} [${wing.force_tag}] — callsign roster`).setTimestamp();
    return e;
  });
}

async function postRoster(client, guildId, wingId) {
  const wing = org.getWingById(wingId);
  if (!wing || !org.squadronsInWing(wing.id).length) return false; // nothing to list yet
  const channel = await client.channels.fetch(wing.channel_id).catch(() => null);
  if (!channel?.isTextBased()) return false;
  const sent = await channel.send({
    content: `<@&${wing.role_id}>`,
    allowedMentions: { roles: [wing.role_id], users: [] },
    embeds: buildEmbeds(guildId, wing).slice(0, 10),
  });
  if (wing.roster_message_id && wing.roster_message_id !== sent.id) {
    const old = await channel.messages.fetch(wing.roster_message_id).catch(() => null);
    if (old) await old.delete().catch(() => {});
  }
  org.setRosterMessage(wing.id, sent.id);
  return true;
}

// Best-effort removal of an old roster post (e.g. in the previous channel after the roster channel changed).
async function deleteMessage(client, channelId, messageId) {
  if (!channelId || !messageId) return;
  const channel = await client.channels.fetch(channelId).catch(() => null);
  const msg = await channel?.messages?.fetch(messageId).catch(() => null);
  if (msg) await msg.delete().catch(() => {});
}

function markDirty(client, guildId, wingId) {
  if (!wingId) return;
  const key = `${guildId}:${wingId}`;
  if (pending.has(key)) return;
  const timer = setTimeout(async () => {
    pending.delete(key);
    try { await postRoster(client, guildId, wingId); } catch (err) { console.warn('[roster] post failed:', err.message); }
  }, debounceMs);
  timer.unref?.();
  pending.set(key, { timer, client, guildId, wingId });
}

// Posts every pending roster right now (used by tests and on shutdown-style flushes).
async function flush() {
  const jobs = [...pending.values()];
  pending.clear();
  for (const j of jobs) {
    clearTimeout(j.timer);
    try { await postRoster(j.client, j.guildId, j.wingId); } catch (err) { console.warn('[roster] post failed:', err.message); }
  }
}

module.exports = { configure, markDirty, flush, deleteMessage, postRoster, buildEmbeds, squadronLines, paginate };
