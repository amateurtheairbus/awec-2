// Builds the /commands list from the SAME command modules the bot runs and `deploy-commands` registers
// (src/util/commandLoader.js). When Discord can be reached, entries are clickable command mentions
// (</force wings create:ID>) and anything in the code that isn't registered yet is flagged.
const { paginate } = require('./roster');

const OPT_SUBCOMMAND = 1; const OPT_GROUP = 2;
const ACCESS_TEXT = { admin: 'Manage Server', controller: 'AEW&C Controller', everyone: null };
const ID_CACHE_MS = 60_000;
const idCache = new Map();

// Every runnable leaf of a command: { path: ['wings','create'], description, options }
function leaves(json) {
  const subs = (json.options ?? []).filter((o) => o.type === OPT_SUBCOMMAND || o.type === OPT_GROUP);
  if (!subs.length) return [{ path: [], description: json.description, options: json.options ?? [] }];
  const out = [];
  for (const o of subs) {
    if (o.type === OPT_GROUP) for (const s of o.options ?? []) out.push({ path: [o.name, s.name], description: s.description, options: s.options ?? [] });
    else out.push({ path: [o.name], description: o.description, options: o.options ?? [] });
  }
  return out;
}

// "wing_name wingcom [squadcom]" — required options bare, optional ones in [brackets]
const usage = (options) => options.map((o) => (o.required ? o.name : `[${o.name}]`)).join(' ');

// Longest matching prefix of the path in module.access, else its default, else 'everyone'.
function accessOf(mod, path) {
  const table = mod.access ?? {};
  for (let n = path.length; n >= 1; n--) {
    const key = path.slice(0, n).join(' ');
    if (table[key]) return table[key];
  }
  return table.default ?? 'everyone';
}

async function fetchCommandIds(client, guildId, { now = Date.now() } = {}) {
  const key = guildId ?? 'global';
  const hit = idCache.get(key);
  if (hit && now - hit.at < ID_CACHE_MS) return hit.value;
  const ids = new Map(); let reached = false;
  for (const opts of [undefined, { guildId }]) { // global first, then this server's (which win)
    try {
      const found = await client.application.commands.fetch(opts);
      reached = true;
      for (const c of found.values()) ids.set(c.name, c.id);
    } catch { /* offline / no permission: fall back to plain text */ }
  }
  const value = { ids, reached };
  idCache.set(key, { at: now, value });
  return value;
}

const clearIdCache = () => idCache.clear();

// -> { lines, count, stale }.  `only` (lowercase top-level name) limits the list to one command.
function renderLines(mods, { ids = new Map(), reached = false, only = null } = {}) {
  const lines = []; let count = 0;
  const sorted = [...mods].sort((a, b) => a.data.name.localeCompare(b.data.name));
  for (const mod of sorted) {
    const json = mod.data.toJSON();
    if (only && json.name !== only) continue;
    const id = ids.get(json.name);
    const deployedNote = reached && !id ? ' ⚠ _not deployed — run `npm run deploy-commands`_' : '';
    lines.push(`**/${json.name}** — ${json.description}${deployedNote}`);
    for (const leaf of leaves(json)) {
      count++;
      const full = [json.name, ...leaf.path].join(' ');
      const mention = id ? `</${full}:${id}>` : `\`/${full}\``;
      const who = ACCESS_TEXT[accessOf(mod, leaf.path)];
      const args = usage(leaf.options);
      lines.push(`• ${mention}${args ? ` \`${args}\`` : ''} — ${leaf.description}${who ? ` · _${who}_` : ''}`);
    }
    lines.push('');
  }
  while (lines.at(-1) === '') lines.pop();
  const names = new Set(mods.map((m) => m.data.name));
  const stale = reached ? [...ids.keys()].filter((n) => !names.has(n)) : [];
  return { lines, count, stale };
}

const renderPages = (lines) => paginate(lines, 3800);

module.exports = { leaves, usage, accessOf, fetchCommandIds, clearIdCache, renderLines, renderPages, ACCESS_TEXT };
