// GeoFS multiplayer presence client.
//
// From the GeoFS client source: the same endpoint the in-sim map uses is
//   POST {multiplayerHost}/map   body: {"id": <myId>, "gid": <licenseId|null>}
// and the client calls it every 10 s (multiplayer.mapUpdatePeriod). It sends no account
// credentials, so a bot can poll it without logging in. Each user entry carries:
//   acid = account ID (this is the "GeoFS ID"), cs = callsign, id = per-session id,
//   co = [lat, lon, alt_m, heading, pitch, roll], ac = aircraft id, ad = ADS-B traffic flag.
// We never join the simulation (no /update call), so the bot never appears as a pilot.
const HOST = process.env.GEOFS_MP_HOST || 'https://mps.geo-fs.com';
const MIN_FETCH_INTERVAL_MS = 10_000; // never poll faster than the real client does
const TIMEOUT_MS = 8_000;
const USER_AGENT = 'aewc-discord-bot/0.1 (roleplay presence tracker)';

let cache = { at: 0, snapshot: null };
let inflight = null;

// Turns one raw /map entry into our shape, or null if it isn't a trackable human pilot.
function normalizeUser(u) {
  if (!u || u.ad) return null;                 // ADS-B / AI traffic, not a person
  const acid = u.acid;
  if (acid == null || acid === '' || Number(acid) <= 0) return null; // anonymous / no account
  const co = Array.isArray(u.co) ? u.co : [];
  return {
    geofsId: String(acid),
    callsign: typeof u.cs === 'string' ? u.cs : '',
    sessionId: u.id != null ? String(u.id) : null,
    aircraftId: u.ac ?? null,
    lat: Number.isFinite(co[0]) ? co[0] : null,
    lon: Number.isFinite(co[1]) ? co[1] : null,
    altitudeM: Number.isFinite(co[2]) ? co[2] : null,
    headingDeg: Number.isFinite(co[3]) ? co[3] : null,
  };
}

async function fetchRaw(fetchImpl) {
  const res = await fetchImpl(`${HOST}/map`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'User-Agent': USER_AGENT },
    body: JSON.stringify({ id: '', gid: null }),
    signal: AbortSignal.timeout(TIMEOUT_MS),
  });
  if (!res.ok) throw new Error(`GeoFS /map responded HTTP ${res.status}`);
  const data = await res.json();
  if (!data || !Array.isArray(data.users)) throw new Error('GeoFS /map response had no users array');
  return data;
}

/**
 * Returns { players, userCount, fetchedAt }. Throws on network/shape errors — callers must
 * treat a throw as "unknown", NOT as "everyone went offline".
 * Results are cached for MIN_FETCH_INTERVAL_MS and concurrent callers share one request, so
 * any number of guilds polling costs GeoFS one request per 10 s at most.
 */
async function getOnlinePlayers({ fetchImpl = globalThis.fetch, now = Date.now(), force = false } = {}) {
  if (!force && cache.snapshot && now - cache.at < MIN_FETCH_INTERVAL_MS) return cache.snapshot;
  if (inflight) return inflight;
  inflight = (async () => {
    try {
      const raw = await fetchRaw(fetchImpl);
      const players = raw.users.map(normalizeUser).filter(Boolean);
      cache = { at: now, snapshot: { players, userCount: raw.userCount ?? raw.users.length, fetchedAt: now } };
      return cache.snapshot;
    } finally {
      inflight = null;
    }
  })();
  return inflight;
}

function _resetCache() { cache = { at: 0, snapshot: null }; inflight = null; }

module.exports = { getOnlinePlayers, normalizeUser, fetchRaw, _resetCache, HOST };
