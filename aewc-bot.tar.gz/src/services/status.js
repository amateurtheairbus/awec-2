// Health report behind /ping: Discord latency, GeoFS latency, poller health and host stats.
// Collects numbers only — no hostnames, addresses or paths are ever exposed.
const os = require('os');
const fs = require('fs');
const { EmbedBuilder, version: discordJsVersion } = require('discord.js');

const SLOW_API_MS = 1500;
const SLOW_GEOFS_MS = 2000;
const POLLER_STALE_MS = 5 * 60_000;

function formatDuration(totalSeconds) {
  const s = Math.max(0, Math.floor(totalSeconds));
  const d = Math.floor(s / 86400); const h = Math.floor((s % 86400) / 3600); const m = Math.floor((s % 3600) / 60);
  if (d) return `${d}d ${h}h ${m}m`;
  if (h) return `${h}h ${m}m`;
  if (m) return `${m}m ${s % 60}s`;
  return `${s}s`;
}

function formatBytes(n) {
  if (n == null) return '—';
  if (n >= 1024 ** 3) return `${(n / 1024 ** 3).toFixed(1)} GB`;
  if (n >= 1024 ** 2) return `${Math.round(n / 1024 ** 2)} MB`;
  return `${Math.max(1, Math.round(n / 1024))} KB`;
}

function hostInfo() {
  return {
    hostUptime: os.uptime(), botUptime: process.uptime(),
    rss: process.memoryUsage().rss, totalMem: os.totalmem(), freeMem: os.freemem(),
    load: os.loadavg(), cores: os.cpus().length, node: process.version,
  };
}

// SELECT 1 round trip + database file size.
function dbInfo(db) {
  const t0 = performance.now();
  let ok = true;
  try { db.prepare('SELECT 1').get(); } catch { ok = false; }
  let bytes = null;
  try { if (db.name && db.name !== ':memory:') bytes = fs.statSync(db.name).size; } catch { /* ignore */ }
  return { ok, ms: Math.round((performance.now() - t0) * 10) / 10, bytes };
}

// Overall verdict: 'ok' | 'warn' | 'bad' plus the reasons.
function verdict({ apiMs, geo, poller, db }, now = Date.now()) {
  const reasons = []; let level = 'ok';
  const raise = (l, why) => { reasons.push(why); if (l === 'bad') level = 'bad'; else if (level === 'ok') level = 'warn'; };
  if (!db.ok) raise('bad', 'database check failed');
  if (!geo.ok) raise('bad', `GeoFS unreachable (${geo.error ?? 'no response'})`);
  else if (geo.ms > SLOW_GEOFS_MS) raise('warn', `GeoFS is slow (${geo.ms} ms)`);
  if (apiMs > SLOW_API_MS) raise('warn', `Discord API is slow (${apiMs} ms)`);
  if (poller?.running) {
    if (poller.failures > 0) raise('warn', `presence poller failing (${poller.lastError ?? 'error'})`);
    else if (poller.lastOkAt && now - poller.lastOkAt > POLLER_STALE_MS) raise('warn', 'presence poller hasn\'t completed a poll in 5+ minutes');
  }
  return { level, reasons };
}

const LEVEL = {
  ok: { color: 0x2e8b57, text: '✅ All systems operational' },
  warn: { color: 0xddaa22, text: '⚠ Degraded' },
  bad: { color: 0xcc2222, text: '❌ Problem detected' },
};

function buildEmbed({ gatewayMs, apiMs, geo, poller, db, host, now = Date.now() }) {
  const v = verdict({ apiMs, geo, poller, db }, now);
  const age = (ms) => formatDuration((now - ms) / 1000);

  const geoLine = geo.ok
    ? `Multiplayer feed: **${geo.ms} ms** · HTTP ${geo.status} · ${geo.players} player${geo.players === 1 ? '' : 's'} online` +
      (geo.cached ? ` _(measured ${formatDuration(geo.ageMs / 1000)} ago)_` : '')
    : `Multiplayer feed: **unreachable** — ${geo.error ?? 'no response'}${geo.status ? ` (HTTP ${geo.status})` : ''}`;
  const pollerLine = !poller?.running ? 'Presence poller: not running'
    : poller.lastOkAt ? `Presence poller: last OK ${age(poller.lastOkAt)} ago · ${poller.lastPlayers} player${poller.lastPlayers === 1 ? '' : 's'}${poller.failures ? ` · ${poller.failures} failed poll${poller.failures === 1 ? '' : 's'} since` : ''}`
    : poller.lastError ? `Presence poller: failing — ${poller.lastError}` : 'Presence poller: starting up (no poll yet)';

  return new EmbedBuilder()
    .setColor(LEVEL[v.level].color)
    .setTitle('🏓 Pong!')
    .setDescription(`**${LEVEL[v.level].text}**${v.reasons.length ? `\n${v.reasons.map((r) => `• ${r}`).join('\n')}` : ''}`)
    .addFields(
      { name: 'Discord', value: `Gateway heartbeat: **${gatewayMs >= 0 ? `${gatewayMs} ms` : 'measuring…'}**\nAPI round-trip: **${apiMs} ms**` },
      { name: 'GeoFS', value: `${geoLine}\n${pollerLine}` },
      {
        name: 'Server',
        value: `Bot uptime ${formatDuration(host.botUptime)} · host uptime ${formatDuration(host.hostUptime)}\n` +
          `Memory: bot ${formatBytes(host.rss)} · host ${formatBytes(host.totalMem - host.freeMem)} / ${formatBytes(host.totalMem)} in use\n` +
          `Load: ${host.load.map((n) => n.toFixed(2)).join(' ')} (${host.cores} core${host.cores === 1 ? '' : 's'})\n` +
          `Database: ${db.ok ? 'OK' : '**FAILED**'} · ${db.ms} ms${db.bytes != null ? ` · ${formatBytes(db.bytes)}` : ''}\n` +
          `Node ${host.node} · discord.js ${discordJsVersion}`,
      },
    )
    .setTimestamp(now);
}

module.exports = { formatDuration, formatBytes, hostInfo, dbInfo, verdict, buildEmbed, SLOW_API_MS, SLOW_GEOFS_MS };
