// Flight-code verification (single force per server).
//   rotate()  — generate a fresh code, post it in the code channel, remember the previous one
//   verify()  — called every presence poll: for online players whose callsign carries the force tag,
//               check the bracketed flight code; mismatch -> ping the roster pilot, or ping the
//               scramble role with "IMPERSONATOR" if that GeoFS ID isn't on the roster.
const crypto = require('crypto');
const { EmbedBuilder } = require('discord.js');
const config = require('../db/repos/config');
const pilots = require('../db/repos/pilots');
const tags = require('../db/repos/tags');
const repo = require('../db/repos/flightcode');
const events = require('../db/repos/events');
const { record } = require('./logger');
const { toUnix } = require('../util/time');
const { EVENT_TYPE } = require('../util/constants');

const PREVIOUS_CODE_GRACE_S = 600;   // after a rotation the old code stays valid this long
const REPING_S = 3600;               // an unresolved mismatch is re-pinged at most this often

const ALPHABETS = {
  alnum: 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789',
  letters: 'ABCDEFGHIJKLMNOPQRSTUVWXYZ',
  numbers: '0123456789',
};

function generateCode(charset, length, randomInt = crypto.randomInt) {
  const alphabet = ALPHABETS[charset];
  if (!alphabet) throw new Error(`Unknown charset: ${charset}`);
  let out = '';
  for (let i = 0; i < length; i++) out += alphabet[randomInt(alphabet.length)];
  return out;
}

// Is `code` (from a callsign) acceptable right now? Case-insensitive; the previous code counts
// only inside the grace window after the latest rotation.
function isValidCode(cfg, code, nowUnix) {
  if (!code) return false;
  const c = String(code).toUpperCase();
  if (cfg.flightcode_current && c === cfg.flightcode_current.toUpperCase()) return true;
  if (cfg.flightcode_previous && c === cfg.flightcode_previous.toUpperCase()) {
    const rotated = toUnix(cfg.flightcode_rotated_at);
    return rotated != null && nowUnix - rotated < PREVIOUS_CODE_GRACE_S;
  }
  return false;
}

/**
 * Posts a new code. The Discord post happens FIRST: if it fails (missing channel/permissions) nothing
 * changes and the old code stays valid, so pilots are never left with a code nobody can see.
 * The code itself is never written to event_log.
 */
async function rotate(client, guildId, { nowUnix = Math.floor(Date.now() / 1000), randomInt } = {}) {
  const cfg = config.get(guildId);
  if (!cfg.flightcode_enabled || !cfg.flightcode_channel_id) throw new Error('Flight codes are not set up.');
  const channel = await client.channels.fetch(cfg.flightcode_channel_id).catch(() => null);
  if (!channel?.isTextBased()) throw new Error('Flight code channel not found or not text-based.');

  let code = generateCode(cfg.flightcode_charset, cfg.flightcode_length, randomInt);
  for (let i = 0; i < 10 && cfg.flightcode_current && code === cfg.flightcode_current; i++) {
    code = generateCode(cfg.flightcode_charset, cfg.flightcode_length, randomInt); // never repeat the live code
  }

  const tag = cfg.flightcode_force_tag;
  const next = nowUnix + cfg.flightcode_interval_s;
  const embed = new EmbedBuilder()
    .setColor(0x3b7ddd)
    .setTitle(`${tag} FLIGHT CODE`)
    .setDescription(
      `Current flight code: **\`${code}\`**\n` +
      `Put it in your callsign right before the force tag, e.g. \`NAME[${code}][${tag}]\`.\n\n` +
      `Valid from <t:${nowUnix}:t>` +
      (cfg.flightcode_current ? ` · the previous code is also accepted until <t:${nowUnix + PREVIOUS_CODE_GRACE_S}:t>` : '') +
      `\nNext rotation <t:${next}:R>`)
    .setTimestamp();
  const sent = await channel.send({ embeds: [embed] });

  const oldMessageId = cfg.flightcode_message_id;
  repo.setCode(guildId, code, sent.id);

  // Remove the stale post so old codes don't linger in the channel history.
  if (oldMessageId && oldMessageId !== sent.id) {
    const old = await channel.messages.fetch(oldMessageId).catch(() => null);
    if (old) await old.delete().catch(() => {});
  }
  events.insert(guildId, {
    type: EVENT_TYPE.FLIGHTCODE_ROTATED, refTable: 'bot_state', refId: guildId,
    detail: { charset: cfg.flightcode_charset, length: cfg.flightcode_length },
  });
  return { code, messageId: sent.id };
}

const posText = (p) => (p.lat != null
  ? `\nLast position: ${p.lat.toFixed(2)}, ${p.lon.toFixed(2)}` +
    (p.altitudeM != null ? ` · ${Math.round(p.altitudeM * 3.28084).toLocaleString('en-US')} ft` : '')
  : '');

async function verify(client, guildId, players, { nowUnix = Math.floor(Date.now() / 1000) } = {}) {
  const cfg = config.get(guildId);
  if (!cfg.flightcode_enabled || !cfg.flightcode_force_tag || !cfg.flightcode_current) return;
  const tag = cfg.flightcode_force_tag;

  for (const player of players) {
    const parsed = tags.parseForTag(player.callsign, tag);
    if (!parsed) continue;                                   // not flying under our force tag

    const valid = isValidCode(cfg, parsed.code, nowUnix);
    const pilot = pilots.getByGeofs(guildId, player.geofsId);
    if (valid && (pilot || !cfg.flightcode_strict)) {        // compliant -> forget earlier alerts
      repo.clearAlerts(guildId, player.geofsId);
      continue;
    }

    const kind = pilot ? 'update' : 'impersonator';
    if (!repo.shouldAlert(guildId, player.geofsId, kind, nowUnix, REPING_S, toUnix)) continue;
    repo.markAlerted(guildId, player.geofsId, kind);

    const state = parsed.code ? `the wrong flight code (\`${parsed.code}\`)` : 'no flight code';
    if (pilot) {
      await record(client, guildId, {
        type: EVENT_TYPE.FLIGHTCODE_MISMATCH, refTable: 'pilots', refId: pilot.discord_id,
        detail: { geofsId: player.geofsId, hadCode: !!parsed.code },
        content: `<@${pilot.discord_id}>`,
        allowedMentions: { users: [pilot.discord_id], roles: [] },
        text: `<@${pilot.discord_id}> you're online as **${player.callsign}** with ${state}.\n` +
          `Update your callsign to the current code posted in <#${cfg.flightcode_channel_id}>.`,
      });
    } else {
      const why = valid ? 'a valid flight code but is **not on the roster**' : `${state} and is **not on the roster**`;
      await record(client, guildId, {
        type: EVENT_TYPE.FLIGHTCODE_IMPERSONATOR, refTable: 'flightcode_alerts', refId: player.geofsId,
        detail: { geofsId: player.geofsId, callsign: player.callsign, hadCode: !!parsed.code },
        content: cfg.flightcode_scramble_role_id ? `<@&${cfg.flightcode_scramble_role_id}>` : undefined,
        allowedMentions: cfg.flightcode_scramble_role_id ? { roles: [cfg.flightcode_scramble_role_id], users: [] } : undefined,
        text: `**IMPERSONATOR** — GeoFS ID \`${player.geofsId}\` is flying as **${player.callsign}** under [${tag}] with ${why}.` + posText(player),
      });
    }
  }
}

module.exports = { generateCode, isValidCode, rotate, verify, PREVIOUS_CODE_GRACE_S, REPING_S };
