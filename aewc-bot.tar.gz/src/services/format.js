const { discordTs } = require('../util/time');
const config = require('../db/repos/config');

const IFF_ICON = { friendly: '🟢', hostile: '🔴', unknown: '🟡' };
const IFF_ORDER = { hostile: 0, unknown: 1, friendly: 2 };

const pad3 = (n) => String(Math.round(n) % 360).padStart(3, '0');

function flightLevel(ft) {
  return ft >= 18000 ? `FL${String(Math.round(ft / 100)).padStart(3, '0')}` : `${Math.round(ft).toLocaleString('en-US')} ft`;
}

// Great-circle bearing (deg, 0–359) and range (nautical miles) from point 1 to point 2.
function bearingRange(lat1, lon1, lat2, lon2) {
  const rad = Math.PI / 180;
  const p1 = lat1 * rad; const p2 = lat2 * rad;
  const dl = (lon2 - lon1) * rad;
  const y = Math.sin(dl) * Math.cos(p2);
  const x = Math.cos(p1) * Math.sin(p2) - Math.sin(p1) * Math.cos(p2) * Math.cos(dl);
  const bearing = (Math.atan2(y, x) / rad + 360) % 360;
  const a = Math.sin((p2 - p1) / 2) ** 2 + Math.cos(p1) * Math.cos(p2) * Math.sin(dl / 2) ** 2;
  const rangeNm = 2 * 3440.065 * Math.asin(Math.min(1, Math.sqrt(a)));
  return { bearing, rangeNm };
}

const coords = (lat, lon) => `${Math.abs(lat).toFixed(2)}${lat >= 0 ? 'N' : 'S'} ${Math.abs(lon).toFixed(2)}${lon >= 0 ? 'E' : 'W'}`;

// Per-guild display context (reference point for live contacts).
function contextFor(guildId) {
  const cfg = config.get(guildId);
  const bullseye = cfg.bullseye_lat != null && cfg.bullseye_lon != null ? { lat: cfg.bullseye_lat, lon: cfg.bullseye_lon } : null;
  return { bullseye };
}

// Where is it? Simulated contacts carry their own bearing/range; live ones are measured from the
// configured bullseye, or shown as coordinates when no bullseye is set.
function whereText(c, ctx = {}) {
  if (c.source !== 'live') return `BRG ${pad3(c.bearing)}/${c.range_nm} nm`;
  if (c.lat == null || c.lon == null) return 'POSITION UNKNOWN';
  if (ctx.bullseye) {
    const { bearing, rangeNm } = bearingRange(ctx.bullseye.lat, ctx.bullseye.lon, c.lat, c.lon);
    return `BULL ${pad3(bearing)}/${Math.round(rangeNm)} nm`;
  }
  return coords(c.lat, c.lon);
}

function contactLine(c, ctx = {}) {
  const cls = c.classification && c.classification !== 'unknown' ? ` ${c.classification.toUpperCase()}` : '';
  const parts = [
    `${IFF_ICON[c.iff] ?? '⚪'} \`#${c.id}\` **${c.callsign}**`,
    `${c.iff.toUpperCase()}${cls}`,
    whereText(c, ctx),
    flightLevel(c.altitude_ft),
    `HDG ${pad3(c.heading)}`,
  ];
  if (c.source !== 'live' || c.speed_kt > 0) parts.push(`${c.speed_kt} kt`);
  return parts.join(' · ');
}

// Hostile first, then unknown, then friendly; stable by callsign.
function sortContacts(list) {
  return [...list].sort((a, b) => (IFF_ORDER[a.iff] ?? 9) - (IFF_ORDER[b.iff] ?? 9) || a.callsign.localeCompare(b.callsign));
}

function patrolLine(p) {
  const unit = [p.aircraft, p.callsign_tag ? `[${p.callsign_tag}]` : null].filter(Boolean).join(' ') || 'unspecified';
  return `<@${p.discord_id}> · ${unit} · **${p.status.toUpperCase()}** since ${discordTs(p.started_at)}` +
    (p.auto_started ? ' · auto' : '');
}

// Joins lines into a string under `limit` chars, appending "+N more" if truncated.
function fitLines(lines, limit = 1000) {
  if (!lines.length) return null;
  const out = [];
  let used = 0;
  for (let i = 0; i < lines.length; i++) {
    const remaining = lines.length - i;
    const tail = `\n…+${remaining} more`;
    if (used + lines[i].length + 1 + tail.length > limit && remaining > 0 && out.length) {
      return out.join('\n') + `\n…+${remaining} more`;
    }
    out.push(lines[i]);
    used += lines[i].length + 1;
  }
  return out.join('\n');
}

module.exports = { contactLine, patrolLine, fitLines, sortContacts, contextFor, bearingRange, whereText, coords, IFF_ICON };
