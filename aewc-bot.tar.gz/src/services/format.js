const { discordTs } = require('../util/time');

const IFF_ICON = { friendly: '🟢', hostile: '🔴', unknown: '🟡' };

const pad3 = (n) => String(n).padStart(3, '0');

function flightLevel(ft) {
  return ft >= 18000 ? `FL${String(Math.round(ft / 100)).padStart(3, '0')}` : `${ft.toLocaleString('en-US')} ft`;
}

function contactLine(c) {
  return `${IFF_ICON[c.iff] ?? '⚪'} \`#${c.id}\` **${c.callsign}** · ${c.iff.toUpperCase()} ${c.classification.toUpperCase()}` +
    ` · BRG ${pad3(c.bearing)}/${c.range_nm} nm · ${flightLevel(c.altitude_ft)} · HDG ${pad3(c.heading)} · ${c.speed_kt} kt`;
}

function patrolLine(p) {
  const unit = [p.aircraft, p.callsign_tag ? `[${p.callsign_tag}]` : null].filter(Boolean).join(' ') || 'unspecified';
  return `<@${p.discord_id}> · ${unit} · **${p.status.toUpperCase()}** since ${discordTs(p.started_at)}` +
    (p.auto_started ? ' · auto' : '');
}

// Joins lines into a string under `limit` chars, appending "+N more" if truncated.
function fitLines(lines, limit = 1000) {
  if (!lines.length) return null;
  const out = [];
  let used = 0;
  for (let i = 0; i < lines.length; i++) {
    const remaining = lines.length - i;
    const tail = `\n…+${remaining} more`;
    if (used + lines[i].length + 1 + tail.length > limit && remaining > 0 && out.length) {
      return out.join('\n') + `\n…+${remaining} more`;
    }
    out.push(lines[i]);
    used += lines[i].length + 1;
  }
  return out.join('\n');
}

module.exports = { contactLine, patrolLine, fitLines, IFF_ICON };
