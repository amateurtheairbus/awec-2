const { EmbedBuilder } = require('discord.js');
const events = require('../db/repos/events');
const config = require('../db/repos/config');
const { EVENT_TYPE } = require('../util/constants');

const STYLE = {
  [EVENT_TYPE.CONTACT_SPAWNED]:   { color: 0xddaa22, title: 'CONTACT',          channel: 'threat' },
  [EVENT_TYPE.CONTACT_FADED]:     { color: 0x888888, title: 'CONTACT LOST',     channel: 'threat' },
  [EVENT_TYPE.CONTACT_ESCALATED]: { color: 0xcc2222, title: 'CONTACT UPGRADED', channel: 'threat' },
  [EVENT_TYPE.SCRAMBLE]:          { color: 0xcc2222, title: 'SCRAMBLE',          channel: 'threat' },
  [EVENT_TYPE.PATROL_STARTED]:    { color: 0x2e8b57, title: 'PATROL ON STATION', channel: 'patrol' },
  [EVENT_TYPE.PATROL_RTB]:        { color: 0x3b7ddd, title: 'PATROL RTB',        channel: 'patrol' },
  [EVENT_TYPE.PATROL_ENDED]:      { color: 0x888888, title: 'PATROL ENDED',      channel: 'patrol' },
  [EVENT_TYPE.INTEL_SIGHTING]:    { color: 0xcc2222, title: 'INTEL SIGHTING',    channel: 'intel' },
  [EVENT_TYPE.INTEL_ADDED]:       { color: 0x6a4fc4, title: 'INTEL WATCHLIST +', channel: 'intel' },
  [EVENT_TYPE.INTEL_REMOVED]:     { color: 0x6a4fc4, title: 'INTEL WATCHLIST −', channel: 'intel' },
  [EVENT_TYPE.FLIGHTCODE_ROTATED]:      { color: 0x3b7ddd, title: 'FLIGHT CODE ROTATED', channel: 'flightcode' },
  [EVENT_TYPE.FLIGHTCODE_MISMATCH]:     { color: 0xddaa22, title: 'FLIGHT CODE CHECK',   channel: 'flightcode' },
  [EVENT_TYPE.FLIGHTCODE_IMPERSONATOR]: { color: 0xcc2222, title: 'IMPERSONATOR',        channel: 'flightcode' },
};

function targetChannelId(cfg, kind) {
  if (kind === 'flightcode') return cfg.flightcode_alert_channel_id || cfg.flightcode_channel_id;
  if (kind === 'patrol') return cfg.patrol_log_channel_id;
  if (kind === 'intel') return cfg.intel_channel_id || cfg.threat_log_channel_id;
  return cfg.threat_log_channel_id;
}

/**
 * Writes the event to event_log FIRST (source of truth), then mirrors it to the
 * relevant Discord channel. A failed Discord post never loses or blocks the event.
 *
 * `text` is the human-readable line shown in the log channel.
 */
async function record(client, guildId, { type, refTable, refId, actorId, detail, text, silent = false, content, allowedMentions }) {
  const row = events.insert(guildId, { type, refTable, refId, actorId, detail });
  if (silent) return row; // DB only — no Discord post

  try {
    const style = STYLE[type];
    const cfg = config.get(guildId);
    const channelId = style && targetChannelId(cfg, style.channel);
    if (!channelId || !client) return row;
    const channel = await client.channels.fetch(channelId).catch(() => null);
    if (!channel?.isTextBased()) return row;
    // Pings only work from message `content` (never from an embed), so alerts pass it explicitly.
    await channel.send({
      ...(content ? { content } : {}),
      ...(allowedMentions ? { allowedMentions } : {}),
      embeds: [new EmbedBuilder().setColor(style.color).setTitle(style.title).setDescription(text).setTimestamp()],
    });
  } catch (err) {
    console.warn(`[logger] mirror failed (${type}):`, err.message);
  }
  return row;
}

module.exports = { record };
