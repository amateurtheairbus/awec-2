// High-level operations. Each one: change DB state -> record to event_log (mirrors to
// Discord) -> refresh the live picture. Commands and background loops both call these,
// so behavior is identical no matter what triggered it.
const patrols = require('../db/repos/patrols');
const contacts = require('../db/repos/contacts');
const pilots = require('../db/repos/pilots');
const intel = require('../db/repos/intel');
const { record } = require('./logger');
const picture = require('./picture');
const contactGen = require('./contactGen');
const { contactLine } = require('./format');
const { EVENT_TYPE } = require('../util/constants');

const unitText = (p) => [p.aircraft, p.callsign_tag ? `[${p.callsign_tag}]` : null].filter(Boolean).join(' ') || 'unspecified';

// ---- Patrols -------------------------------------------------------------

// Returns { patrol } or { error }.
async function startPatrol(client, guildId, { discordId, aircraft, callsignTag, geofsId, auto = false, actorId }) {
  const open = patrols.getOpenForUser(guildId, discordId);
  if (open) return { error: `<@${discordId}> already has an open patrol (#${open.id}, ${open.status}).` };

  // Link to the roster entry if one exists, even for manual starts.
  const roster = pilots.getByDiscord(guildId, discordId);
  const patrol = patrols.start(guildId, { discordId, geofsId: geofsId ?? roster?.geofs_id, aircraft, callsignTag, auto });

  await record(client, guildId, {
    type: EVENT_TYPE.PATROL_STARTED, refTable: 'patrols', refId: patrol.id, actorId: actorId ?? discordId,
    detail: { auto, aircraft, callsignTag },
    text: `<@${discordId}> on station — **${unitText(patrol)}**${auto ? ' _(auto-detected)_' : ''}\nPatrol \`#${patrol.id}\``,
  });
  await picture.refresh(client, guildId);
  return { patrol };
}

async function rtbPatrol(client, guildId, patrol, { actorId, reason } = {}) {
  if (patrol.status !== 'active') return { error: `Patrol #${patrol.id} is already ${patrol.status}.` };
  const updated = patrols.setRtb(patrol.id);
  await record(client, guildId, {
    type: EVENT_TYPE.PATROL_RTB, refTable: 'patrols', refId: patrol.id, actorId: actorId ?? patrol.discord_id,
    detail: { reason },
    text: `<@${patrol.discord_id}> returning to base — **${unitText(patrol)}**${reason ? `\n_${reason}_` : ''}`,
  });
  await picture.refresh(client, guildId);
  return { patrol: updated };
}

async function endPatrol(client, guildId, patrol, { actorId, reason } = {}) {
  if (patrol.status === 'ended') return { error: `Patrol #${patrol.id} has already ended.` };
  const updated = patrols.end(patrol.id);
  await record(client, guildId, {
    type: EVENT_TYPE.PATROL_ENDED, refTable: 'patrols', refId: patrol.id, actorId: actorId ?? patrol.discord_id,
    detail: { reason },
    text: `<@${patrol.discord_id}> patrol ended — **${unitText(patrol)}**${reason ? `\n_${reason}_` : ''}\nPatrol \`#${patrol.id}\``,
  });
  await picture.refresh(client, guildId);
  return { patrol: updated };
}

// ---- Contacts --------------------------------------------------------------

async function spawnContact(client, guildId, { iff, classification, actorId } = {}) {
  const contact = contactGen.generate(guildId, { iff, classification });
  await record(client, guildId, {
    type: EVENT_TYPE.CONTACT_SPAWNED, refTable: 'contacts', refId: contact.id, actorId,
    detail: { manual: !!actorId },
    text: contactLine(contact),
  });
  await picture.refresh(client, guildId);
  return contact;
}

async function fadeContact(client, guildId, contact, { actorId, reason = 'Faded from radar' } = {}) {
  if (contact.status !== 'active') return { error: `Contact #${contact.id} is not active.` };
  const updated = contacts.fade(contact.id);
  await record(client, guildId, {
    type: EVENT_TYPE.CONTACT_FADED, refTable: 'contacts', refId: contact.id, actorId,
    detail: { reason },
    text: `\`#${contact.id}\` **${contact.callsign}** — ${reason}`,
  });
  await picture.refresh(client, guildId);
  return { contact: updated };
}

// Reclassifies an active contact in place (e.g. unknown -> hostile) and extends its life.
async function escalateContact(client, guildId, contact, { iff, expiresAt, actorId }) {
  if (contact.status !== 'active') return { error: `Contact #${contact.id} is not active.` };
  const updated = contacts.escalate(contact.id, { iff, expiresAt });
  await record(client, guildId, {
    type: EVENT_TYPE.CONTACT_ESCALATED, refTable: 'contacts', refId: contact.id, actorId,
    detail: { from: contact.iff, to: iff },
    text: `\`#${contact.id}\` **${contact.callsign}** reclassified ${contact.iff.toUpperCase()} → **${iff.toUpperCase()}**\n${contactLine(updated)}`,
  });
  await picture.refresh(client, guildId);
  return { contact: updated };
}

// ---- Intel -----------------------------------------------------------------

async function addIntel(client, guildId, geofsId, { notes, alertOnSighting, actorId }) {
  const { entry, created } = intel.add(guildId, geofsId, { notes, alertOnSighting, flaggedBy: actorId });
  await record(client, guildId, {
    type: EVENT_TYPE.INTEL_ADDED, refTable: 'intel_contacts', refId: entry.geofs_id, actorId,
    detail: { created, notes, alertOnSighting: !!entry.alert_on_sighting },
    text: `GeoFS ID \`${entry.geofs_id}\` ${created ? 'added to' : 'updated on'} the watchlist` +
      `${entry.notes ? `\n${entry.notes}` : ''}\nSighting alerts: **${entry.alert_on_sighting ? 'on' : 'off'}**`,
  });
  return { entry, created };
}

async function removeIntel(client, guildId, geofsId, { actorId }) {
  const removed = intel.remove(guildId, geofsId);
  if (!removed) return { error: `GeoFS ID \`${geofsId}\` is not on the watchlist.` };
  await record(client, guildId, {
    type: EVENT_TYPE.INTEL_REMOVED, refTable: 'intel_contacts', refId: String(geofsId), actorId,
    text: `GeoFS ID \`${geofsId}\` removed from the watchlist`,
  });
  return {};
}

// A watchlisted GeoFS ID showed up online. Always written to event_log (so /intel lookup has
// history); only posted to Discord when the entry has alerts turned on.
async function intelSighting(client, guildId, entry, player, parsed) {
  const alt = player.altitudeM != null ? ` · ${Math.round(player.altitudeM * 3.28084).toLocaleString('en-US')} ft` : '';
  const pos = player.lat != null ? ` · ${player.lat.toFixed(2)}, ${player.lon.toFixed(2)}${alt}` : '';
  return record(client, guildId, {
    type: EVENT_TYPE.INTEL_SIGHTING, refTable: 'intel_contacts', refId: entry.geofs_id,
    detail: { callsign: player.callsign, tag: parsed?.tag ?? null, aircraftId: player.aircraftId, lat: player.lat, lon: player.lon },
    silent: !entry.alert_on_sighting,
    text: `Watchlisted GeoFS ID \`${entry.geofs_id}\` online as **${player.callsign || 'unknown'}**${pos}` +
      `${entry.notes ? `\n${entry.notes}` : ''}`,
  });
}

module.exports = { startPatrol, rtbPatrol, endPatrol, spawnContact, fadeContact, escalateContact, addIntel, removeIntel, intelSighting, unitText };
