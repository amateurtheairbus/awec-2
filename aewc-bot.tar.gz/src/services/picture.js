const { EmbedBuilder } = require('discord.js');
const config = require('../db/repos/config');
const contacts = require('../db/repos/contacts');
const patrols = require('../db/repos/patrols');
const { contactLine, patrolLine, fitLines } = require('./format');

function buildEmbed(guildId) {
  const cs = contacts.listActive(guildId);
  const ps = patrols.listOpen(guildId);
  const hostile = cs.filter((c) => c.iff === 'hostile').length;

  return new EmbedBuilder()
    .setTitle('AEW&C AIRSPACE PICTURE')
    .setColor(hostile ? 0xcc2222 : cs.length ? 0xddaa22 : 0x2e8b57)
    .setDescription(`**${cs.length}** contact(s) · **${hostile}** hostile · **${ps.length}** patrol(s) on station`)
    .addFields(
      { name: `Contacts (${cs.length})`, value: fitLines(cs.map(contactLine)) ?? '_Airspace clear._' },
      { name: `Patrols (${ps.length})`, value: fitLines(ps.map(patrolLine)) ?? '_No patrols on station._' },
    )
    .setTimestamp();
}

// One refresh at a time per guild, so rapid events can't race and post duplicate pictures.
const chains = new Map();
function refresh(client, guildId, opts = {}) {
  const prev = chains.get(guildId) ?? Promise.resolve();
  const next = prev.then(() => doRefresh(client, guildId, opts)).catch((err) => {
    console.warn(`[picture] refresh failed for ${guildId}:`, err.message);
    return false;
  });
  chains.set(guildId, next);
  return next;
}

async function doRefresh(client, guildId, { forceNew = false } = {}) {
  const cfg = config.get(guildId);
  if (!cfg.picture_channel_id) return false;
  const channel = await client.channels.fetch(cfg.picture_channel_id).catch(() => null);
  if (!channel?.isTextBased()) return false;

  const payload = { embeds: [buildEmbed(guildId)] };

  if (cfg.picture_message_id && !forceNew) {
    const msg = await channel.messages.fetch(cfg.picture_message_id).catch(() => null);
    if (msg) {
      await msg.edit(payload);
      return true;
    }
    // message was deleted — fall through and post a fresh one
  } else if (cfg.picture_message_id && forceNew) {
    const old = await channel.messages.fetch(cfg.picture_message_id).catch(() => null);
    if (old) await old.delete().catch(() => {});
  }

  const sent = await channel.send(payload);
  config.setPictureMessage(guildId, sent.id);
  return true;
}

module.exports = { buildEmbed, refresh };
