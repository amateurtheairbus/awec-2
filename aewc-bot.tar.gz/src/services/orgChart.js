// Text chart of the force: wings, their nested squadrons, and (optionally) every pilot's callsign.
const org = require('../db/repos/org');
const pilotsRepo = require('../db/repos/pilots');
const { paginate } = require('./roster');

function squadronBlock(guildId, sq, wing, { showPilots, last }) {
  const slots = org.slotsOf(sq.id);
  const branch = last ? '└─' : '├─';
  const pad = last ? '\u2003\u2003' : '│\u2003';
  const head = `${branch} **${sq.name}** · ${sq.callsign}-1…${sq.slots} · ${slots.size}/${sq.slots}` +
    (sq.squadcom_id ? ` · squadcom <@${sq.squadcom_id}>` : '');
  const lines = [head];
  if (showPilots) {
    for (const slot of [...slots.keys()].sort((a, b) => a - b)) {
      const id = slots.get(slot);
      const rank = pilotsRepo.getByDiscord(guildId, id)?.rank_name;
      lines.push(`${pad}\`${org.callsignOf(sq, slot, wing)}\` <@${id}>${rank ? ` · ${rank}` : ''}`);
    }
  }
  return lines;
}

function renderLines(guildId, { showPilots = false } = {}) {
  const lines = [];
  for (const wing of org.listWings(guildId)) {
    lines.push(`**WING ${wing.name}** [${wing.force_tag}] — ${wing.wingcom_id ? `wingcom <@${wing.wingcom_id}>` : '_no wingcom_'}`);
    const squadrons = org.squadronsInWing(wing.id);
    if (!squadrons.length) lines.push('└─ _no squadrons yet_');
    squadrons.forEach((sq, i) => lines.push(...squadronBlock(guildId, sq, wing, { showPilots, last: i === squadrons.length - 1 })));
    lines.push('');
  }
  const loose = org.listSquadrons(guildId).filter((s) => !s.wing_id);
  if (loose.length) {
    lines.push('**UNATTACHED SQUADRONS**');
    loose.forEach((sq, i) => lines.push(...squadronBlock(guildId, sq, null, { showPilots, last: i === loose.length - 1 })));
  }
  while (lines.length && lines.at(-1) === '') lines.pop();
  return lines;
}

// -> array of text pages (each safely under Discord's embed limit); empty array when there is nothing yet.
function renderPages(guildId, opts) {
  return paginate(renderLines(guildId, opts));
}

module.exports = { renderLines, renderPages };
