// Scramble-airspace geometry. Pure functions — no I/O.
//   circle  : great-circle distance from a centre point
//   polygon : even-odd ray casting in lat/lon space (edges are straight lines on the map, which is
//             accurate enough for regional airspace). Longitudes are taken relative to the first
//             vertex, so polygons that cross the antimeridian (±180°) work.
// Both can carry an optional altitude band (feet).
const { bearingRange } = require('./format');

const wrapLon = (d) => ((((d + 180) % 360) + 360) % 360) - 180;

function inCircle(t, lat, lon) {
  return bearingRange(t.center_lat, t.center_lon, lat, lon).rangeNm <= t.radius_nm;
}

function inPolygon(points, lat, lon) {
  const ref = points[0][1];
  const xs = points.map(([, plon]) => wrapLon(plon - ref));
  const ys = points.map(([plat]) => plat);
  const x = wrapLon(lon - ref); const y = lat;
  let inside = false;
  for (let i = 0, j = points.length - 1; i < points.length; j = i++) {
    const crosses = (ys[i] > y) !== (ys[j] > y) && x < ((xs[j] - xs[i]) * (y - ys[i])) / (ys[j] - ys[i]) + xs[i];
    if (crosses) inside = !inside;
  }
  return inside;
}

const inAltitudeBand = (t, altFt) =>
  (t.min_alt_ft == null || altFt >= t.min_alt_ft) && (t.max_alt_ft == null || altFt <= t.max_alt_ft);

// t: a territory row (points already parsed to an array)
function contains(t, { lat, lon, altitudeFt }) {
  if (!Number.isFinite(lat) || !Number.isFinite(lon)) return false;
  if (!inAltitudeBand(t, Number.isFinite(altitudeFt) ? altitudeFt : 0)) return false;
  return t.shape === 'circle' ? inCircle(t, lat, lon) : inPolygon(t.points, lat, lon);
}

function firstContaining(territories, position) {
  return territories.find((t) => contains(t, position)) ?? null;
}

// "25.2,55.3; 26,56; 24,57"  or  "25.2,55.3 26,56 24,57"  ->  [[25.2,55.3],[26,56],[24,57]]
// Returns { points } or { error }. The polygon is implicitly closed.
function parsePoints(raw, { min = 3, max = 50 } = {}) {
  const text = String(raw).trim();
  const pieces = text.includes(';') ? text.split(';') : text.split(/\s+/);
  const points = [];
  for (const piece of pieces.map((p) => p.trim()).filter(Boolean)) {
    const nums = piece.split(/[,\s]+/).filter(Boolean).map(Number);
    if (nums.length !== 2 || nums.some((n) => !Number.isFinite(n))) return { error: `Couldn't read "${piece}" — use lat,lon pairs like 25.2,55.3.` };
    const [lat, lon] = nums;
    if (lat < -90 || lat > 90) return { error: `Latitude ${lat} is out of range (-90 to 90).` };
    if (lon < -180 || lon > 180) return { error: `Longitude ${lon} is out of range (-180 to 180).` };
    points.push([lat, lon]);
  }
  if (points.length > 1 && points[0][0] === points.at(-1)[0] && points[0][1] === points.at(-1)[1]) points.pop();
  if (points.length < min) return { error: `A polygon needs at least ${min} points.` };
  if (points.length > max) return { error: `A polygon can have at most ${max} points.` };

  const ref = points[0][1];
  let area = 0; // shoelace, in lat/lon degrees² — only used to reject degenerate (zero-area) shapes
  for (let i = 0; i < points.length; i++) {
    const [y1, lon1] = points[i]; const [y2, lon2] = points[(i + 1) % points.length];
    area += wrapLon(lon1 - ref) * y2 - wrapLon(lon2 - ref) * y1;
  }
  if (Math.abs(area / 2) < 1e-6) return { error: 'Those points are in a straight line — a polygon needs some area.' };
  return { points };
}

module.exports = { contains, firstContaining, inCircle, inPolygon, parsePoints, wrapLon };
