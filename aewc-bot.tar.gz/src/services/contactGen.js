const { IFF, CLASSIFICATION } = require('../util/constants');
const contacts = require('../db/repos/contacts');
const { sqlNow } = require('../util/time');

const rand = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;
const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];

function weighted(table) {
  const total = table.reduce((s, [, w]) => s + w, 0);
  let r = Math.random() * total;
  for (const [value, w] of table) { if ((r -= w) < 0) return value; }
  return table[0][0];
}

// Mostly unknown/friendly, occasionally hostile for drama.
const IFF_WEIGHTS = [[IFF.UNKNOWN, 45], [IFF.FRIENDLY, 35], [IFF.HOSTILE, 20]];
const CLASS_WEIGHTS = [[CLASSIFICATION.FIGHTER, 35], [CLASSIFICATION.TRANSPORT, 30], [CLASSIFICATION.BOMBER, 15], [CLASSIFICATION.UNKNOWN, 20]];

// Speed/altitude bands per classification (kt, ft).
const BANDS = {
  fighter:   { speed: [380, 650], alt: [8000, 42000] },
  bomber:    { speed: [330, 520], alt: [15000, 40000] },
  transport: { speed: [250, 460], alt: [18000, 38000] },
  unknown:   { speed: [200, 600], alt: [5000, 42000] },
};

const LIFESPAN_S = [600, 1800]; // contact persists 10–30 min unless escalated/cleared

function uniqueCallsign(guildId) {
  for (let i = 0; i < 20; i++) {
    const cs = `TRK-${rand(1000, 9999)}`;
    if (!contacts.callsignInUse(guildId, cs)) return cs;
  }
  return `TRK-${Date.now() % 100000}`;
}

function generate(guildId, overrides = {}) {
  const classification = overrides.classification ?? weighted(CLASS_WEIGHTS);
  const band = BANDS[classification];
  return contacts.create(guildId, {
    callsign: uniqueCallsign(guildId),
    iff: overrides.iff ?? weighted(IFF_WEIGHTS),
    classification,
    bearing: rand(0, 359),
    range_nm: rand(20, 250),
    altitude_ft: Math.round(rand(band.alt[0], band.alt[1]) / 500) * 500,
    heading: rand(0, 359),
    speed_kt: Math.round(rand(band.speed[0], band.speed[1]) / 5) * 5,
    expires_at: sqlNow(rand(LIFESPAN_S[0], LIFESPAN_S[1])),
  });
}

module.exports = { generate, rand, pick, LIFESPAN_S };
