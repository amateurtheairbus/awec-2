// Organization service: keeps Discord roles and wing rosters in step with the database.
//   desired roles for a pilot = enlisted roles + their rank's roles + squadron role + wing role (+ wing role if wingcom)
//   Only roles the bot manages (enlisted/rank/squadron/wing roles) are ever added or removed.
const org = require('../db/repos/org');
const pilotsRepo = require('../db/repos/pilots');
const ranksRepo = require('../db/repos/ranks');
const roster = require('./roster');

function managedRoles(guildId) {
  const ids = new Set(ranksRepo.enlistedRoleIds(guildId));
  for (const r of ranksRepo.list(guildId)) r.role_ids.forEach((id) => ids.add(id));
  for (const s of org.listSquadrons(guildId)) ids.add(s.role_id);
  for (const w of org.listWings(guildId)) ids.add(w.role_id);
  return ids;
}

function desiredRoles(guildId, discordId) {
  const pilot = pilotsRepo.getByDiscord(guildId, discordId);
  if (!pilot) return new Set();
  const want = new Set(ranksRepo.enlistedRoleIds(guildId));
  const rank = pilot.rank_name ? ranksRepo.getByName(guildId, pilot.rank_name) : null;
  rank?.role_ids.forEach((id) => want.add(id));
  const a = org.assignmentOf(guildId, discordId);
  if (a.squadron) want.add(a.squadron.role_id);
  if (a.wing) want.add(a.wing.role_id);
  if (a.commandsWing) want.add(a.commandsWing.role_id);
  return want;
}

/**
 * Brings one member's managed roles in line with the database. Never throws: problems (member left the
 * server, role deleted, missing Manage Roles / role order) come back in `problems`.
 */
async function syncMemberRoles(guild, guildId, discordId) {
  const result = { added: [], removed: [], problems: [] };
  const member = await guild.members.fetch(discordId).catch(() => null);
  if (!member) { result.problems.push({ discordId, reason: 'is not in this server' }); return result; }
  const desired = desiredRoles(guildId, discordId);
  const managed = managedRoles(guildId);

  for (const id of desired) {
    if (member.roles.cache.has(id)) continue;
    if (!guild.roles.cache.has(id)) { result.problems.push({ discordId, roleId: id, reason: 'role no longer exists' }); continue; }
    try { await member.roles.add(id); result.added.push(id); }
    catch (err) { result.problems.push({ discordId, roleId: id, reason: `couldn't add it (${err.message})` }); }
  }
  for (const id of managed) {
    if (desired.has(id) || !member.roles.cache.has(id) || !guild.roles.cache.has(id)) continue;
    try { await member.roles.remove(id); result.removed.push(id); }
    catch (err) { result.problems.push({ discordId, roleId: id, reason: `couldn't remove it (${err.message})` }); }
  }
  return result;
}

/**
 * Call after any change. Works out which pilots' seats moved (from a seatSnapshot taken before), syncs their
 * roles, and queues roster posts for every wing involved.
 *   extraPilots / extraWings — things the seat diff can't see (rank change, squadron nested into a wing, …)
 */
async function afterChange(client, guild, guildId, { before, extraPilots = [], extraWings = [] }) {
  const after = org.seatSnapshot(guildId);
  const pilots = new Set(extraPilots);
  const squadronIds = new Set();
  for (const id of new Set([...before.keys(), ...after.keys()])) {
    if (before.get(id) === after.get(id)) continue;
    pilots.add(id);
    for (const v of [before.get(id), after.get(id)]) if (v) squadronIds.add(Number(v.split(':')[0]));
  }
  const wings = new Set(extraWings);
  for (const sid of squadronIds) { const sq = org.getSquadronById(sid); if (sq?.wing_id) wings.add(sq.wing_id); }
  for (const id of pilots) { const a = org.assignmentOf(guildId, id); if (a.wing) wings.add(a.wing.id); if (a.commandsWing) wings.add(a.commandsWing.id); }

  const report = { added: 0, removed: 0, problems: [] };
  for (const id of pilots) {
    const r = await syncMemberRoles(guild, guildId, id);
    report.added += r.added.length; report.removed += r.removed.length; report.problems.push(...r.problems);
  }
  for (const wingId of wings) roster.markDirty(client, guildId, wingId);
  return report;
}

// After a wing/squadron role is replaced, the old role is no longer "managed" so the normal sync won't
// remove it — take it off the members explicitly (unless some other managed rule still wants them to have it).
async function dropRoleFromMembers(guild, guildId, memberIds, roleId) {
  const problems = [];
  if (!roleId || !guild.roles.cache.has(roleId)) return problems;
  for (const discordId of memberIds) {
    if (desiredRoles(guildId, discordId).has(roleId)) continue;
    const member = await guild.members.fetch(discordId).catch(() => null);
    if (!member || !member.roles.cache.has(roleId)) continue;
    try { await member.roles.remove(roleId); }
    catch (err) { problems.push({ discordId, roleId, reason: `couldn't remove it (${err.message})` }); }
  }
  return problems;
}

// Everyone whose roles depend on this wing: pilots seated in its squadrons plus its commander.
function wingMemberIds(wingId) {
  const wing = org.getWingById(wingId);
  const ids = new Set();
  for (const sq of org.squadronsInWing(wingId)) for (const id of org.slotsOf(sq.id).values()) ids.add(id);
  if (wing?.wingcom_id) ids.add(wing.wingcom_id);
  return [...ids];
}

const problemText = (problems) => problems.map((p) => `• <@${p.discordId}>${p.roleId ? ` / <@&${p.roleId}>` : ''}: ${p.reason}`).join('\n');

module.exports = { managedRoles, desiredRoles, syncMemberRoles, afterChange, dropRoleFromMembers, wingMemberIds, problemText };
