// SQLite's datetime('now') yields 'YYYY-MM-DD HH:MM:SS' in UTC.
function toUnix(sqlTs) {
  if (!sqlTs) return null;
  return Math.floor(Date.parse(sqlTs.replace(' ', 'T') + 'Z') / 1000);
}

// Discord timestamp markup — renders in each viewer's local time.
function discordTs(sqlTs, style = 'R') {
  const u = toUnix(sqlTs);
  return u ? `<t:${u}:${style}>` : 'unknown';
}

function sqlNow(offsetSeconds = 0) {
  return new Date(Date.now() + offsetSeconds * 1000)
    .toISOString().replace('T', ' ').slice(0, 19);
}

// Start (unix seconds, UTC) of the current calendar period. 'week' starts Monday 00:00 UTC.
function periodStartUnix(period, nowMs = Date.now()) {
  const d = new Date(nowMs);
  const y = d.getUTCFullYear(); const m = d.getUTCMonth();
  if (period === 'week') return Date.UTC(y, m, d.getUTCDate() - ((d.getUTCDay() + 6) % 7)) / 1000;
  if (period === 'month') return Date.UTC(y, m, 1) / 1000;
  if (period === 'year') return Date.UTC(y, 0, 1) / 1000;
  return 0; // all time
}

const PERIOD_LABEL = { all: 'all time', week: 'this week', month: 'this month', year: 'this year' };

function formatHours(seconds) {
  const h = Math.floor(seconds / 3600); const m = Math.round((seconds % 3600) / 60);
  return `${(seconds / 3600).toFixed(1)} h (${h} h ${String(m).padStart(2, '0')} m)`;
}

module.exports = { toUnix, discordTs, sqlNow, periodStartUnix, PERIOD_LABEL, formatHours };
