// SQLite's datetime('now') yields 'YYYY-MM-DD HH:MM:SS' in UTC.
function toUnix(sqlTs) {
  if (!sqlTs) return null;
  return Math.floor(Date.parse(sqlTs.replace(' ', 'T') + 'Z') / 1000);
}

// Discord timestamp markup — renders in each viewer's local time.
function discordTs(sqlTs, style = 'R') {
  const u = toUnix(sqlTs);
  return u ? `<t:${u}:${style}>` : 'unknown';
}

function sqlNow(offsetSeconds = 0) {
  return new Date(Date.now() + offsetSeconds * 1000)
    .toISOString().replace('T', ' ').slice(0, 19);
}

module.exports = { toUnix, discordTs, sqlNow };
