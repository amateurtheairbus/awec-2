// Every callsign goes through this BEFORE any tag/flight-code recognition or display.
//  • NFKC folds look-alike forms (full-width brackets ［］ -> [], etc.)
//  • invisible characters are stripped (zero-width spaces can't be used to dodge a tag)
//  • whitespace collapsed, then everything upper-cased
// Idempotent: normalizeCallsign(normalizeCallsign(x)) === normalizeCallsign(x)
function normalizeCallsign(raw) {
  return String(raw ?? '')
    .normalize('NFKC')
    .replace(/[\u200B-\u200D\u2060\uFEFF]/g, '')
    .replace(/\s+/g, ' ')
    .trim()
    .toUpperCase();
}

module.exports = { normalizeCallsign };
