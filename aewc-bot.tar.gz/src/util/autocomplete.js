const { normalizeCallsign } = require('./callsign');

// Answers a slash-command autocomplete with the names that contain what's been typed (max 25, Discord's limit).
async function respondNames(interaction, names) {
  const q = normalizeCallsign(interaction.options.getFocused());
  const choices = names.filter((n) => normalizeCallsign(n).includes(q)).slice(0, 25).map((n) => ({ name: n.slice(0, 100), value: n.slice(0, 100) }));
  await interaction.respond(choices);
}

module.exports = { respondNames };
