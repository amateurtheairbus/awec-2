// The ONE place command modules are discovered. The bot, `deploy-commands`, `check-commands` and
// `/commands list` all use it, so what the bot runs, what gets registered and what's listed can't drift apart.
const fs = require('fs');
const path = require('path');

const DEFAULT_ROOT = path.join(__dirname, '..', 'commands');

// Returns every command module: { data: SlashCommandBuilder, execute, autocomplete?, access? }
function loadCommands(root = DEFAULT_ROOT) {
  const out = [];
  for (const group of fs.readdirSync(root)) {
    const dir = path.join(root, group);
    if (!fs.statSync(dir).isDirectory()) continue;
    for (const file of fs.readdirSync(dir).filter((f) => f.endsWith('.js'))) {
      const mod = require(path.join(dir, file));
      if (!mod?.data || !mod?.execute) {
        console.warn(`Skipping ${group}/${file} — missing "data" or "execute" export`);
        continue;
      }
      out.push(mod);
    }
  }
  return out;
}

module.exports = { loadCommands };
