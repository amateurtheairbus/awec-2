// Turns what a user typed into Discord role IDs. Accepts role mentions (<@&123>), raw IDs, or role names
// (with or without a leading @, case-insensitive).
function extractRoleIds(guild, text) {
  const raw = String(text ?? '').trim();
  const ids = [...raw.matchAll(/<@&(\d+)>/g)].map((m) => m[1]);
  const unknown = [];
  if (!ids.length && raw) {
    const token = raw.replace(/^@/, '').trim();
    if (/^\d{5,}$/.test(token)) ids.push(token);
    else {
      const hit = [...guild.roles.cache.values()].find((r) => r.name.toLowerCase() === token.toLowerCase());
      if (hit) ids.push(hit.id); else unknown.push(raw);
    }
  }
  for (const id of ids) if (!guild.roles.cache.has(id)) unknown.push(`<@&${id}>`);
  return { ids: ids.filter((id) => guild.roles.cache.has(id)), unknown };
}

// "<@&1>,<@&2>"  ->  { ids: [...], unknown: [...] }   (comma-separated items)
function extractRoleList(guild, text) {
  const ids = []; const unknown = [];
  for (const item of String(text ?? '').split(',').map((t) => t.trim()).filter(Boolean)) {
    const r = extractRoleIds(guild, item);
    r.ids.forEach((id) => { if (!ids.includes(id)) ids.push(id); });
    unknown.push(...r.unknown);
  }
  return { ids, unknown };
}

// "@of-1,@of-2;2nd Lieutenant,1st Lieutenant"  ->  { ranks: [{ name, roleIds }] } (lowest rank first) or { error }
//   left of ';'  : one item per rank, in the same order as the names (an item may mention several roles)
//   right of ';' : the rank names, comma-separated
function parseRanksSpec(guild, spec) {
  const parts = String(spec ?? '').split(';');
  const example = 'Format: `@role1,@role2;Rank One,Rank Two` — roles on the left, rank names on the right, lowest rank first.';
  if (parts.length !== 2) return { error: `Use exactly one \`;\` to separate the roles from the rank names. ${example}` };
  const roleItems = parts[0].split(',').map((t) => t.trim()).filter(Boolean);
  const names = parts[1].split(',').map((t) => t.trim()).filter(Boolean);
  if (!names.length) return { error: `No rank names found. ${example}` };
  if (roleItems.length !== names.length) return { error: `You gave ${roleItems.length} role(s) but ${names.length} rank name(s) — they must match one-to-one. ${example}` };

  const ranks = []; const seen = new Set();
  for (let i = 0; i < names.length; i++) {
    const name = names[i];
    if (name.length > 40) return { error: `Rank name "${name.slice(0, 20)}…" is too long (max 40 characters).` };
    if (seen.has(name.toLowerCase())) return { error: `Rank "${name}" appears twice.` };
    seen.add(name.toLowerCase());
    const r = extractRoleIds(guild, roleItems[i]);
    if (r.unknown.length) return { error: `I couldn't find the role ${r.unknown[0]} (for rank "${name}"). Mention it with @ so I can match it.` };
    if (!r.ids.length) return { error: `No role found for rank "${name}".` };
    ranks.push({ name, roleIds: r.ids });
  }
  return { ranks };
}

module.exports = { extractRoleIds, extractRoleList, parseRanksSpec };
