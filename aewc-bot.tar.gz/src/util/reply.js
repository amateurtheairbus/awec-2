const { MessageFlags } = require('discord.js');

const ephemeral = (content) => ({ content, flags: MessageFlags.Ephemeral });
const ephemeralEmbed = (embed) => ({ embeds: [embed], flags: MessageFlags.Ephemeral });

module.exports = { ephemeral, ephemeralEmbed };
