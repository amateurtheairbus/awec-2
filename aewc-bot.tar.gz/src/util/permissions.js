const { CONTROLLER_ROLE_NAME } = require('./constants');
const { ephemeral } = require('./reply');

/**
 * True if the interacting member has the AEW&C Controller role, or is a
 * server admin (admins implicitly get controller-tier access too).
 */
function isController(interaction) {
  if (interaction.memberPermissions?.has('ManageGuild')) return true;
  return interaction.member?.roles?.cache?.some((role) => role.name === CONTROLLER_ROLE_NAME) ?? false;
}

async function denyController(interaction) {
  await interaction.reply(ephemeral(`This command requires the **${CONTROLLER_ROLE_NAME}** role (or server admin).`));
}

function isAdmin(interaction) {
  return !!interaction.memberPermissions?.has('ManageGuild');
}

async function denyAdmin(interaction) {
  await interaction.reply(ephemeral('This command requires server admin (Manage Server).'));
}

module.exports = { isController, denyController, isAdmin, denyAdmin };
