const { PermissionFlagsBits } = require('discord.js');

// Name of the role that grants controller-tier access (intel commands, manual
// contact injects). Looked up by name per-guild since role IDs differ per server.
const CONTROLLER_ROLE_NAME = 'AEW&C Controller';

// Admin-tier commands (/aewc setup, /pilot register|remove, etc.) use Discord's
// built-in ManageGuild permission as the default — server owners can still
// override per-command in their own integration settings regardless of this default.
const ADMIN_DEFAULT_PERMISSIONS = PermissionFlagsBits.ManageGuild;

// What a callsign tag means. 'us' = our force (patrols), 'friendly' = allied (shown, no scramble),
// 'hostile' = scramble when seen.
const TAG_CATEGORY = Object.freeze({ US: 'us', FRIENDLY: 'friendly', HOSTILE: 'hostile' });

const IFF = Object.freeze({
  FRIENDLY: 'friendly',
  HOSTILE: 'hostile',
  UNKNOWN: 'unknown',
});

const CLASSIFICATION = Object.freeze({
  FIGHTER: 'fighter',
  BOMBER: 'bomber',
  TRANSPORT: 'transport',
  UNKNOWN: 'unknown',
});

const CONTACT_STATUS = Object.freeze({
  ACTIVE: 'active',
  FADED: 'faded',
  ESCALATED: 'escalated',
});

const PATROL_STATUS = Object.freeze({
  ACTIVE: 'active',
  RTB: 'rtb',
  ENDED: 'ended',
});

const EVENT_TYPE = Object.freeze({
  CONTACT_SPAWNED: 'contact_spawned',
  CONTACT_FADED: 'contact_faded',
  CONTACT_ESCALATED: 'contact_escalated',
  PATROL_STARTED: 'patrol_started',
  PATROL_RTB: 'patrol_rtb',
  PATROL_ENDED: 'patrol_ended',
  INTEL_SIGHTING: 'intel_sighting',
  INTEL_ADDED: 'intel_added',
  INTEL_REMOVED: 'intel_removed',
  SCRAMBLE: 'scramble',
  FLIGHTCODE_ROTATED: 'flightcode_rotated',
  FLIGHTCODE_MISMATCH: 'flightcode_mismatch',
  FLIGHTCODE_IMPERSONATOR: 'flightcode_impersonator',
});

module.exports = {
  CONTROLLER_ROLE_NAME,
  ADMIN_DEFAULT_PERMISSIONS,
  TAG_CATEGORY,
  IFF,
  CLASSIFICATION,
  CONTACT_STATUS,
  PATROL_STATUS,
  EVENT_TYPE,
};
