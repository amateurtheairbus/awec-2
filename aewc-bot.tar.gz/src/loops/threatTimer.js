// Random threat generator. Each guild gets its own spawn schedule (random delay between the
// configured min/max), respecting the population cap. Expired contacts either fade or — if
// they were still "unknown" — get identified (reclassified hostile/friendly) before fading.
const config = require('../db/repos/config');
const contacts = require('../db/repos/contacts');
const ops = require('../services/ops');
const { sqlNow } = require('../util/time');

const TICK_MS = 15_000;
const ESCALATED_LIFE_S = [600, 1200];

function newState() { return { nextSpawnAt: new Map() }; }
const globalState = newState();

function scheduleNext(cfg, nowMs, rng) {
  const span = cfg.threat_spawn_max_s - cfg.threat_spawn_min_s;
  return nowMs + (cfg.threat_spawn_min_s + rng() * span) * 1000;
}

// unknown contacts: 30% turn out hostile, 20% turn out friendly, 50% just fade. Everything else fades.
function decideExpiry(contact, rng = Math.random) {
  if (contact.iff === 'unknown') {
    const r = rng();
    if (r < 0.30) return { action: 'escalate', iff: 'hostile' };
    if (r < 0.50) return { action: 'escalate', iff: 'friendly' };
  }
  return { action: 'fade' };
}

async function tickGuild(client, guildId, { nowMs = Date.now(), rng = Math.random, state = globalState } = {}) {
  const cfg = config.get(guildId);
  if (!cfg.picture_channel_id) return; // guild hasn't run /aewc setup

  for (const c of contacts.listExpired(guildId)) {
    const d = decideExpiry(c, rng);
    if (d.action === 'escalate') {
      const life = ESCALATED_LIFE_S[0] + Math.floor(rng() * (ESCALATED_LIFE_S[1] - ESCALATED_LIFE_S[0]));
      await ops.escalateContact(client, guildId, c, { iff: d.iff, expiresAt: sqlNow(life) });
    } else {
      await ops.fadeContact(client, guildId, c, { reason: 'Faded from radar' });
    }
  }

  const next = state.nextSpawnAt.get(guildId);
  if (next == null) { state.nextSpawnAt.set(guildId, scheduleNext(cfg, nowMs, rng)); return; }
  if (nowMs >= next) {
    if (contacts.countActive(guildId) < cfg.threat_population_cap) await ops.spawnContact(client, guildId, {});
    state.nextSpawnAt.set(guildId, scheduleNext(cfg, nowMs, rng));
  }
}

async function tick(client, opts = {}) {
  for (const guildId of config.listGuildIds()) {
    try { await tickGuild(client, guildId, opts); } catch (err) { console.warn(`[threat] guild ${guildId} failed:`, err); }
  }
}

function start(client, { intervalMs = TICK_MS } = {}) {
  let running = false;
  const timer = setInterval(async () => {
    if (running) return;
    running = true;
    try { await tick(client); } finally { running = false; }
  }, intervalMs);
  timer.unref?.();
  console.log('[threat] timer started');
  return () => clearInterval(timer);
}

module.exports = { start, tick, tickGuild, decideExpiry, newState };
