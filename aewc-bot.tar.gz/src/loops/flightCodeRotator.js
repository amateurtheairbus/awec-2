// Rotates the flight code on its configured interval (and posts it). Checked every 30 s.
const config = require('../db/repos/config');
const flightcode = require('../services/flightcode');
const { toUnix } = require('../util/time');

const TICK_MS = 30_000;
const RETRY_AFTER_FAILURE_MS = 5 * 60_000;

function newState() { return { retryAfter: new Map() }; }
const globalState = newState();

async function tickGuild(client, guildId, { nowMs = Date.now(), state = globalState } = {}) {
  const cfg = config.get(guildId);
  if (!cfg.flightcode_enabled || !cfg.flightcode_channel_id) return;
  if (nowMs < (state.retryAfter.get(guildId) ?? 0)) return;

  const rotated = toUnix(cfg.flightcode_rotated_at);
  const due = !cfg.flightcode_current || rotated == null || Math.floor(nowMs / 1000) - rotated >= cfg.flightcode_interval_s;
  if (!due) return;

  try {
    await flightcode.rotate(client, guildId, { nowUnix: Math.floor(nowMs / 1000) });
    state.retryAfter.delete(guildId);
  } catch (err) {
    state.retryAfter.set(guildId, nowMs + RETRY_AFTER_FAILURE_MS); // keep the old code; try again later
    console.warn(`[flightcode] rotation failed for ${guildId}: ${err.message}`);
  }
}

async function tick(client, opts = {}) {
  for (const guildId of config.listGuildIds()) await tickGuild(client, guildId, opts);
}

function start(client, { intervalMs = TICK_MS } = {}) {
  let running = false;
  const timer = setInterval(async () => {
    if (running) return;
    running = true;
    try { await tick(client); } catch (err) { console.warn('[flightcode] tick error:', err); } finally { running = false; }
  }, intervalMs);
  timer.unref?.();
  console.log('[flightcode] rotator started');
  return () => clearInterval(timer);
}

module.exports = { start, tick, tickGuild, newState };
