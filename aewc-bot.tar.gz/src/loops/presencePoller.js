// GeoFS presence poller. One shared fetch of the online-player list per tick, then every
// configured guild is processed against it:
//   • registered pilot online with a recognized force tag  -> auto-start a patrol (or keep it alive)
//   • auto-started patrol whose pilot hasn't been seen tagged for the grace period -> auto-end
//   • watchlisted (intel) GeoFS ID appears online -> sighting event (+ alert if enabled for that entry)
const config = require('../db/repos/config');
const tagsRepo = require('../db/repos/tags');
const pilots = require('../db/repos/pilots');
const patrols = require('../db/repos/patrols');
const intel = require('../db/repos/intel');
const ops = require('../services/ops');
const geofs = require('../services/geofs');
const flightcode = require('../services/flightcode');
const { toUnix } = require('../util/time');

const TICK_MS = 5_000;            // how often we check whether any guild is due
const INTEL_COOLDOWN_S = 300;     // a watchlisted ID seen within this window is the same "session"
const BACKOFF_BASE_MS = 15_000;
const BACKOFF_MAX_MS = 300_000;

function newState() {
  return {
    lastPollAt: new Map(),    // guildId -> ms of last processed poll
    online: new Map(),        // guildId -> Set(geofsId) online at previous poll
    seenTagged: new Map(),    // guildId -> Set(discordId) seen tagged at previous poll
    failures: 0,
    backoffUntil: 0,
  };
}
const globalState = newState();

async function processGuild(client, guildId, players, { nowUnix = Math.floor(Date.now() / 1000), state = globalState } = {}) {
  const cfg = config.get(guildId);
  const prevOnline = state.online.get(guildId) ?? null;
  const prevSeenTagged = state.seenTagged.get(guildId) ?? new Set();
  const nowOnline = new Set();
  const seenTagged = new Set(); // Discord IDs of roster pilots online with a force tag this poll

  for (const player of players) {
    nowOnline.add(player.geofsId);
    const parsed = tagsRepo.parseCallsign(guildId, player.callsign);

    // ---- Intel watchlist ----
    const entry = intel.get(guildId, player.geofsId);
    if (entry) {
      const lastSeen = toUnix(entry.last_seen_at);                       // read BEFORE we update it
      const newSession = !(prevOnline && prevOnline.has(player.geofsId));
      const cooledDown = !lastSeen || nowUnix - lastSeen > INTEL_COOLDOWN_S;
      intel.recordSighting(guildId, player.geofsId, player.callsign, parsed?.tag);
      if (newSession && cooledDown) await ops.intelSighting(client, guildId, entry, player, parsed);
    }

    // ---- Roster pilot flying under a force tag ----
    if (!parsed) continue;
    const pilot = pilots.getByGeofs(guildId, player.geofsId);
    if (!pilot) continue;
    seenTagged.add(pilot.discord_id);

    const open = patrols.getOpenForUser(guildId, pilot.discord_id);
    if (open) {
      patrols.touchSeen(open.id);
    } else if (!prevSeenTagged.has(pilot.discord_id)) {
      // Newly appeared (or first poll after boot) with no patrol -> auto-start.
      // If they WERE already online last poll with no patrol, they ended it themselves — respect that
      // until they drop off and come back.
      await ops.startPatrol(client, guildId, {
        discordId: pilot.discord_id,
        geofsId: player.geofsId,
        aircraft: (parsed.name || player.callsign).slice(0, 60),
        callsignTag: parsed.tag,
        auto: true,
      });
    }
  }

  // ---- Grace-period expiry for auto-started patrols ----
  const grace = cfg.patrol_grace_period_s;
  for (const p of patrols.listOpenAuto(guildId)) {
    if (seenTagged.has(p.discord_id)) continue;
    const last = toUnix(p.last_seen_at) ?? toUnix(p.started_at);
    if (nowUnix - last >= grace) {
      await ops.endPatrol(client, guildId, p, { reason: `No contact for ${Math.round(grace / 60)} min — auto-ended` });
    }
  }

  // ---- Flight-code verification (no-op unless set up) ----
  try {
    await flightcode.verify(client, guildId, players, { nowUnix });
  } catch (err) {
    console.warn(`[flightcode] verify failed for ${guildId}:`, err.message);
  }

  state.online.set(guildId, nowOnline);
  state.seenTagged.set(guildId, seenTagged);
}

async function tick(client, { now = Date.now(), fetchImpl, state = globalState } = {}) {
  if (now < state.backoffUntil) return;
  const due = config.listGuildIds().filter(
    (g) => now - (state.lastPollAt.get(g) ?? 0) >= config.get(g).poll_interval_s * 1000);
  if (!due.length) return;

  let snapshot;
  try {
    snapshot = await geofs.getOnlinePlayers({ now, fetchImpl });
    state.failures = 0;
  } catch (err) {
    // Unknown != offline: skip this poll entirely so nobody's patrol gets ended by a feed outage.
    state.failures += 1;
    const delay = Math.min(BACKOFF_MAX_MS, BACKOFF_BASE_MS * 2 ** (state.failures - 1));
    state.backoffUntil = now + delay;
    console.warn(`[presence] GeoFS poll failed (${err.message}); retrying in ${Math.round(delay / 1000)}s`);
    return;
  }

  for (const guildId of due) {
    state.lastPollAt.set(guildId, now);
    try {
      await processGuild(client, guildId, snapshot.players, { nowUnix: Math.floor(now / 1000), state });
    } catch (err) {
      console.warn(`[presence] guild ${guildId} failed:`, err);
    }
  }
}

function start(client, { intervalMs = TICK_MS } = {}) {
  let running = false;
  const timer = setInterval(async () => {
    if (running) return;
    running = true;
    try { await tick(client); } catch (err) { console.warn('[presence] tick error:', err); } finally { running = false; }
  }, intervalMs);
  timer.unref?.();
  console.log('[presence] poller started');
  return () => clearInterval(timer);
}

module.exports = { start, tick, processGuild, newState, INTEL_COOLDOWN_S };
