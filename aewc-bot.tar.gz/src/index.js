require('dotenv').config();
if (!process.env.DISCORD_TOKEN) {
  console.error('DISCORD_TOKEN is not set. Copy .env.example to .env and fill it in (see README).');
  process.exit(1);
}
const fs = require('fs');
const path = require('path');
const { Client, Collection, GatewayIntentBits } = require('discord.js');
const { ephemeral } = require('./util/reply');
require('./db/migrate')(); // ensure schema is applied on boot

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers, // needed to resolve roles for permission checks
  ],
});

client.commands = new Collection();

// --- Command discovery -------------------------------------------------
// Each subfolder under src/commands/ is a command group (e.g. "pilot", "intel").
// Each .js file inside must export { data: SlashCommandBuilder, execute: fn }.
const commandsRoot = path.join(__dirname, 'commands');
for (const group of fs.readdirSync(commandsRoot)) {
  const groupPath = path.join(commandsRoot, group);
  if (!fs.statSync(groupPath).isDirectory()) continue;

  for (const file of fs.readdirSync(groupPath).filter((f) => f.endsWith('.js'))) {
    const command = require(path.join(groupPath, file));
    if (!command?.data || !command?.execute) {
      console.warn(`Skipping ${group}/${file} — missing "data" or "execute" export`);
      continue;
    }
    client.commands.set(command.data.name, command);
  }
}

// --- Interaction handling -----------------------------------------------
client.on('interactionCreate', async (interaction) => {
  if (!interaction.isChatInputCommand()) return;
  if (!interaction.inGuild()) {
    await interaction.reply(ephemeral('AEW&C commands can only be used inside a server.'));
    return;
  }

  const sub = interaction.options.getSubcommand(false);
  const grp = interaction.options.getSubcommandGroup(false);
  console.log(`[cmd] /${[interaction.commandName, grp, sub].filter(Boolean).join(' ')} from ${interaction.user.tag} in guild ${interaction.guildId}`);
  const command = client.commands.get(interaction.commandName);
  if (!command) {
    console.warn(`No handler found for command: ${interaction.commandName}`);
    return;
  }

  try {
    await command.execute(interaction);
  } catch (err) {
    console.error(`Error executing /${interaction.commandName}:`, err);
    const payload = ephemeral('Something went wrong running that command.');
    if (interaction.replied || interaction.deferred) {
      await interaction.followUp(payload);
    } else {
      await interaction.reply(payload);
    }
  }
});

client.once('clientReady', () => {
  console.log(`Logged in as ${client.user.tag} — in ${client.guilds.cache.size} server(s): ${client.guilds.cache.map((g) => `${g.name} (${g.id})`).join(', ') || 'none (invite the bot first)'}`);
  console.log(`Loaded ${client.commands.size} command group(s): ${[...client.commands.keys()].join(', ')}`);
  require('./loops/threatTimer').start(client);
  require('./loops/presencePoller').start(client);
  require('./loops/flightCodeRotator').start(client);
});

client.on('error', (err) => console.error('[discord] client error:', err));
client.on('warn', (msg) => console.warn('[discord] warn:', msg));
process.on('unhandledRejection', (err) => console.error('[unhandledRejection]', err));

client.login(process.env.DISCORD_TOKEN).catch((err) => {
  console.error(`Login failed: ${err.message}`);
  if (/disallowed intents/i.test(err.message)) {
    console.error('→ Developer Portal → your app → Bot → turn ON "Server Members Intent", save, and restart.');
  } else if (/invalid token/i.test(err.message)) {
    console.error('→ DISCORD_TOKEN in .env is wrong. Bot tab → Reset Token → paste the new token (no quotes, no spaces).');
  }
  process.exit(1);
});
