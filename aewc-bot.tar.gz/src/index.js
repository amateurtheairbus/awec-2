require('dotenv').config();
const fs = require('fs');
const path = require('path');
const { Client, Collection, GatewayIntentBits } = require('discord.js');
const { ephemeral } = require('./util/reply');
require('./db/migrate')(); // ensure schema is applied on boot

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers, // needed to resolve roles for permission checks
  ],
});

client.commands = new Collection();

// --- Command discovery -------------------------------------------------
// Each subfolder under src/commands/ is a command group (e.g. "pilot", "intel").
// Each .js file inside must export { data: SlashCommandBuilder, execute: fn }.
const commandsRoot = path.join(__dirname, 'commands');
for (const group of fs.readdirSync(commandsRoot)) {
  const groupPath = path.join(commandsRoot, group);
  if (!fs.statSync(groupPath).isDirectory()) continue;

  for (const file of fs.readdirSync(groupPath).filter((f) => f.endsWith('.js'))) {
    const command = require(path.join(groupPath, file));
    if (!command?.data || !command?.execute) {
      console.warn(`Skipping ${group}/${file} — missing "data" or "execute" export`);
      continue;
    }
    client.commands.set(command.data.name, command);
  }
}

// --- Interaction handling -----------------------------------------------
client.on('interactionCreate', async (interaction) => {
  if (!interaction.isChatInputCommand()) return;
  if (!interaction.inGuild()) {
    await interaction.reply(ephemeral('AEW&C commands can only be used inside a server.'));
    return;
  }

  const command = client.commands.get(interaction.commandName);
  if (!command) {
    console.warn(`No handler found for command: ${interaction.commandName}`);
    return;
  }

  try {
    await command.execute(interaction);
  } catch (err) {
    console.error(`Error executing /${interaction.commandName}:`, err);
    const payload = ephemeral('Something went wrong running that command.');
    if (interaction.replied || interaction.deferred) {
      await interaction.followUp(payload);
    } else {
      await interaction.reply(payload);
    }
  }
});

client.once('clientReady', () => {
  console.log(`Logged in as ${client.user.tag}`);
  require('./loops/threatTimer').start(client);
  require('./loops/presencePoller').start(client);
  require('./loops/flightCodeRotator').start(client);
});

client.login(process.env.DISCORD_TOKEN);
