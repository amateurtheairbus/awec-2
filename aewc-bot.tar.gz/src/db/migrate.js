// Applies schema.sql, then adds any columns introduced after a DB was first created.
// Safe to re-run: every statement is idempotent.
require('dotenv').config();
const fs = require('fs');
const path = require('path');
const db = require('./index');

// bot_state columns added after v1. Kept here (not in schema.sql) so fresh installs and
// upgraded installs take exactly the same path.
const ADD_COLUMNS = {
  bot_state: [
    // flight-code verification (single force per server)
    ['flightcode_enabled',         'INTEGER NOT NULL DEFAULT 0'],
    ['flightcode_force_tag',       'TEXT'],
    ['flightcode_charset',         "TEXT NOT NULL DEFAULT 'alnum'"],   // alnum | letters | numbers
    ['flightcode_length',          'INTEGER NOT NULL DEFAULT 3'],
    ['flightcode_interval_s',      'INTEGER NOT NULL DEFAULT 86400'],
    ['flightcode_channel_id',      'TEXT'],
    ['flightcode_alert_channel_id','TEXT'],
    ['flightcode_scramble_role_id','TEXT'],
    ['flightcode_strict',          'INTEGER NOT NULL DEFAULT 0'],      // also flag unregistered players with a VALID code
    ['flightcode_current',         'TEXT'],
    ['flightcode_previous',        'TEXT'],
    ['flightcode_rotated_at',      'TEXT'],
    ['flightcode_message_id',      'TEXT'],
  ],
};

function ensureColumns() {
  for (const [table, cols] of Object.entries(ADD_COLUMNS)) {
    const have = new Set(db.prepare(`PRAGMA table_info(${table})`).all().map((r) => r.name));
    for (const [name, ddl] of cols) {
      if (!have.has(name)) db.exec(`ALTER TABLE ${table} ADD COLUMN ${name} ${ddl}`);
    }
  }
}

function migrate() {
  db.exec(fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8'));
  ensureColumns();
  console.log(`Migration applied to ${process.env.DB_PATH || './data/aewc.db'}`);
}

if (require.main === module) migrate();

module.exports = migrate;
