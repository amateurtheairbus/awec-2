const db = require('../index');

function insert(guildId, { type, refTable, refId, actorId, detail }) {
  const res = db.prepare(`INSERT INTO event_log (guild_id, event_type, ref_table, ref_id, actor_id, detail)
                          VALUES (?, ?, ?, ?, ?, ?)`)
    .run(guildId, type, refTable ?? null, refId == null ? null : String(refId), actorId ?? null,
         detail == null ? null : (typeof detail === 'string' ? detail : JSON.stringify(detail)));
  return db.prepare('SELECT * FROM event_log WHERE id = ?').get(res.lastInsertRowid);
}

function forRef(guildId, type, refId, limit = 5) {
  return db.prepare('SELECT * FROM event_log WHERE guild_id = ? AND event_type = ? AND ref_id = ? ORDER BY id DESC LIMIT ?')
    .all(guildId, type, String(refId), limit);
}

module.exports = { insert, forRef };
