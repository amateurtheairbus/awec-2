const db = require('../index');

const parseIds = (json) => { try { return JSON.parse(json ?? '[]'); } catch { return []; } };
const hydrate = (r) => (r ? { ...r, role_ids: parseIds(r.role_ids) } : r);

function list(guildId) {
  return db.prepare('SELECT * FROM ranks WHERE guild_id = ? ORDER BY position').all(guildId).map(hydrate);
}
function getByName(guildId, name) {
  return hydrate(db.prepare('SELECT * FROM ranks WHERE guild_id = ? AND name = ?').get(guildId, String(name).trim()));
}

// ranks: [{ name, roleIds: [...] }] lowest first. Replaces the whole ladder.
function replace(guildId, ranks, enlistedRoleIds = []) {
  db.transaction(() => {
    db.prepare('DELETE FROM ranks WHERE guild_id = ?').run(guildId);
    const ins = db.prepare('INSERT INTO ranks (guild_id, position, name, role_ids) VALUES (?, ?, ?, ?)');
    ranks.forEach((r, i) => ins.run(guildId, i, r.name, JSON.stringify(r.roleIds)));
    db.prepare('INSERT OR IGNORE INTO bot_state (guild_id) VALUES (?)').run(guildId);
    db.prepare("UPDATE bot_state SET enlisted_role_ids = ?, updated_at = datetime('now') WHERE guild_id = ?")
      .run(JSON.stringify(enlistedRoleIds), guildId);
  })();
}

function enlistedRoleIds(guildId) {
  const row = db.prepare('SELECT enlisted_role_ids FROM bot_state WHERE guild_id = ?').get(guildId);
  return parseIds(row?.enlisted_role_ids);
}

module.exports = { list, getByName, replace, enlistedRoleIds };
