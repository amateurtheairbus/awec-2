const db = require('../index');

const OPEN = "('active','rtb')";

function get(id) {
  return db.prepare('SELECT * FROM patrols WHERE id = ?').get(id);
}

// A user can hold one open (active or rtb) patrol at a time.
function getOpenForUser(guildId, discordId) {
  return db.prepare(`SELECT * FROM patrols WHERE guild_id = ? AND discord_id = ? AND status IN ${OPEN}
                     ORDER BY id DESC LIMIT 1`).get(guildId, discordId);
}

function start(guildId, { discordId, geofsId, aircraft, callsignTag, auto }) {
  const res = db.prepare(`INSERT INTO patrols (guild_id, discord_id, geofs_id, aircraft, callsign_tag, auto_started, last_seen_at)
                          VALUES (?, ?, ?, ?, ?, ?, datetime('now'))`)
    .run(guildId, discordId, geofsId ?? null, aircraft ?? null, callsignTag ?? null, auto ? 1 : 0);
  return get(res.lastInsertRowid);
}

function setRtb(id) {
  db.prepare("UPDATE patrols SET status = 'rtb' WHERE id = ? AND status = 'active'").run(id);
  return get(id);
}

// endedAt (optional 'YYYY-MM-DD HH:MM:SS' UTC): auto-ended patrols are closed at the last time the pilot
// was actually seen, so the grace period waiting for them never counts as flight time.
function end(id, endedAt) {
  db.prepare("UPDATE patrols SET status = 'ended', ended_at = COALESCE(?, datetime('now')) WHERE id = ? AND status IN ('active','rtb')").run(endedAt ?? null, id);
  return get(id);
}

function listOpen(guildId) {
  return db.prepare(`SELECT * FROM patrols WHERE guild_id = ? AND status IN ${OPEN} ORDER BY started_at`).all(guildId);
}

// Auto-started patrols the poller is responsible for (used for grace-period RTB).
function listOpenAuto(guildId) {
  return db.prepare(`SELECT * FROM patrols WHERE guild_id = ? AND auto_started = 1 AND status IN ${OPEN}`).all(guildId);
}

function touchSeen(id) {
  db.prepare("UPDATE patrols SET last_seen_at = datetime('now') WHERE id = ?").run(id);
}

function history(guildId, discordId, limit = 10) {
  return db.prepare('SELECT * FROM patrols WHERE guild_id = ? AND discord_id = ? ORDER BY id DESC LIMIT ?')
    .all(guildId, discordId, limit);
}

function countForUser(guildId, discordId) {
  return db.prepare('SELECT COUNT(*) AS n FROM patrols WHERE guild_id = ? AND discord_id = ?').get(guildId, discordId).n;
}

// Patrol hours per pilot. Patrols are clipped to the window (a patrol that straddles the start of
// the week only counts from then on); a patrol still open counts up to `nowUnix`.
// Returns [{ discord_id, patrols, secs }] sorted by time flown.
function statsByPilot(guildId, { fromUnix = 0, nowUnix = Math.floor(Date.now() / 1000), discordId } = {}) {
  const params = { guild: guildId, from: fromUnix, now: nowUnix };
  if (discordId) params.user = discordId;
  return db.prepare(`
    SELECT discord_id,
           COUNT(*) AS patrols,
           SUM(MAX(0, COALESCE(CAST(strftime('%s', ended_at) AS INTEGER), @now)
                      - MAX(CAST(strftime('%s', started_at) AS INTEGER), @from))) AS secs
    FROM patrols
    WHERE guild_id = @guild
      AND COALESCE(CAST(strftime('%s', ended_at) AS INTEGER), @now) > @from
      ${discordId ? 'AND discord_id = @user' : ''}
    GROUP BY discord_id
    ORDER BY secs DESC, patrols DESC, discord_id`).all(params);
}

module.exports = { statsByPilot, get, getOpenForUser, start, setRtb, end, listOpen, listOpenAuto, touchSeen, history, countForUser };
