const db = require('../index');

const OPEN = "('active','rtb')";

function get(id) {
  return db.prepare('SELECT * FROM patrols WHERE id = ?').get(id);
}

// A user can hold one open (active or rtb) patrol at a time.
function getOpenForUser(guildId, discordId) {
  return db.prepare(`SELECT * FROM patrols WHERE guild_id = ? AND discord_id = ? AND status IN ${OPEN}
                     ORDER BY id DESC LIMIT 1`).get(guildId, discordId);
}

function start(guildId, { discordId, geofsId, aircraft, callsignTag, auto }) {
  const res = db.prepare(`INSERT INTO patrols (guild_id, discord_id, geofs_id, aircraft, callsign_tag, auto_started, last_seen_at)
                          VALUES (?, ?, ?, ?, ?, ?, datetime('now'))`)
    .run(guildId, discordId, geofsId ?? null, aircraft ?? null, callsignTag ?? null, auto ? 1 : 0);
  return get(res.lastInsertRowid);
}

function setRtb(id) {
  db.prepare("UPDATE patrols SET status = 'rtb' WHERE id = ? AND status = 'active'").run(id);
  return get(id);
}

function end(id) {
  db.prepare("UPDATE patrols SET status = 'ended', ended_at = datetime('now') WHERE id = ? AND status IN ('active','rtb')").run(id);
  return get(id);
}

function listOpen(guildId) {
  return db.prepare(`SELECT * FROM patrols WHERE guild_id = ? AND status IN ${OPEN} ORDER BY started_at`).all(guildId);
}

// Auto-started patrols the poller is responsible for (used for grace-period RTB).
function listOpenAuto(guildId) {
  return db.prepare(`SELECT * FROM patrols WHERE guild_id = ? AND auto_started = 1 AND status IN ${OPEN}`).all(guildId);
}

function touchSeen(id) {
  db.prepare("UPDATE patrols SET last_seen_at = datetime('now') WHERE id = ?").run(id);
}

function history(guildId, discordId, limit = 10) {
  return db.prepare('SELECT * FROM patrols WHERE guild_id = ? AND discord_id = ? ORDER BY id DESC LIMIT ?')
    .all(guildId, discordId, limit);
}

function countForUser(guildId, discordId) {
  return db.prepare('SELECT COUNT(*) AS n FROM patrols WHERE guild_id = ? AND discord_id = ?').get(guildId, discordId).n;
}

module.exports = { get, getOpenForUser, start, setRtb, end, listOpen, listOpenAuto, touchSeen, history, countForUser };
