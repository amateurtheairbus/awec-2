// Wings, squadrons and callsign slots.
//
// Model
//   • A squadron has callsign slots 1..N  (LEOPARD-1 … LEOPARD-N). A pilot holds at most one slot server-wide.
//   • The SQUADCOM holds slot 1 of their squadron.
//   • The WINGCOM holds slot 2 of the wing's FIRST squadron (lowest wing_seq), i.e. the first one nested into it.
//   • Ordinary assignment takes the lowest free slot. Taking a command seat bumps whoever is there to the next
//     free slot; if the squadron has no room the whole operation is refused and nothing changes.
//   • Command roles are exclusive: a pilot can't be squadcom and wingcom, or command two squadrons/wings.
// Every public function is atomic (one transaction) and returns { error } instead of throwing for rule violations.
const db = require('../index');
const pilotsRepo = require('./pilots');

class OrgError extends Error {}
const fail = (msg) => { throw new OrgError(msg); };

function attempt(fn) {
  try { return db.transaction(fn)(); } catch (e) { if (e instanceof OrgError) return { error: e.message }; throw e; }
}

// ---------- reads ----------
const getWingById = (id) => db.prepare('SELECT * FROM wings WHERE id = ?').get(id);
const getWing = (guildId, name) => db.prepare('SELECT * FROM wings WHERE guild_id = ? AND name = ?').get(guildId, name);
const listWings = (guildId) => db.prepare('SELECT * FROM wings WHERE guild_id = ? ORDER BY name').all(guildId);
const getSquadronById = (id) => db.prepare('SELECT * FROM squadrons WHERE id = ?').get(id);
const getSquadron = (guildId, name) => db.prepare('SELECT * FROM squadrons WHERE guild_id = ? AND name = ?').get(guildId, name);
const listSquadrons = (guildId) => db.prepare('SELECT * FROM squadrons WHERE guild_id = ? ORDER BY name').all(guildId);
const squadronsInWing = (wingId) => db.prepare('SELECT * FROM squadrons WHERE wing_id = ? ORDER BY wing_seq').all(wingId);
const firstSquadron = (wingId) => db.prepare('SELECT * FROM squadrons WHERE wing_id = ? ORDER BY wing_seq LIMIT 1').get(wingId);

function slotsOf(squadronId) {
  return new Map(db.prepare('SELECT slot, discord_id FROM squadron_slots WHERE squadron_id = ?').all(squadronId).map((r) => [r.slot, r.discord_id]));
}
const seatOf = (guildId, discordId) => db.prepare('SELECT squadron_id, slot FROM squadron_slots WHERE guild_id = ? AND discord_id = ?').get(guildId, discordId);

// Everything about one pilot's place in the force (or null fields when unassigned).
function assignmentOf(guildId, discordId) {
  const seat = seatOf(guildId, discordId);
  const squadron = seat ? getSquadronById(seat.squadron_id) : null;
  const wing = squadron?.wing_id ? getWingById(squadron.wing_id) : null;
  const commandsSquadron = db.prepare('SELECT * FROM squadrons WHERE guild_id = ? AND squadcom_id = ?').get(guildId, discordId) ?? null;
  const commandsWing = db.prepare('SELECT * FROM wings WHERE guild_id = ? AND wingcom_id = ?').get(guildId, discordId) ?? null;
  return {
    squadron, slot: seat?.slot ?? null, wing,
    callsign: squadron ? callsignOf(squadron, seat.slot, wing) : null,
    commandsSquadron, commandsWing,
  };
}

// LEOPARD-2[SAAF]  (tag only when the squadron is in a wing)
function callsignOf(squadron, slot, wing) {
  return `${squadron.callsign}-${slot}${wing ? `[${wing.force_tag}]` : ''}`;
}

// pilotId -> "squadronId:slot" for every seated pilot. Used to work out who changed after an operation.
function seatSnapshot(guildId) {
  return new Map(db.prepare('SELECT discord_id, squadron_id, slot FROM squadron_slots WHERE guild_id = ?').all(guildId)
    .map((r) => [r.discord_id, `${r.squadron_id}:${r.slot}`]));
}

function setRosterMessage(wingId, messageId) {
  db.prepare('UPDATE wings SET roster_message_id = ? WHERE id = ?').run(messageId ?? null, wingId);
}

// ---------- internals (call inside attempt) ----------
const lowestFree = (n, occupied, exclude) => {
  for (let s = 1; s <= n; s++) if (!occupied.has(s) && s !== exclude) return s;
  return null;
};

function requireRegistered(guildId, discordId) {
  if (!pilotsRepo.getByDiscord(guildId, discordId)) {
    fail(`<@${discordId}> isn't a registered pilot yet. Register them first with \`/pilot register\` (or \`/onboard\`).`);
  }
}

// Puts a pilot in a squadron: the given slot, or the lowest free one. See the model notes above.
function seat(guildId, squadron, discordId, { slot } = {}) {
  if (slot !== undefined && (slot < 1 || slot > squadron.slots)) fail(`${squadron.name} has no slot ${slot} (it has ${squadron.slots}).`);
  const current = seatOf(guildId, discordId);
  const inHere = current && current.squadron_id === squadron.id;

  const occupied = slotsOf(squadron.id);
  if (inHere) occupied.delete(current.slot); // their own seat counts as free while we work out the move

  const target = slot ?? (inHere ? current.slot : lowestFree(squadron.slots, occupied));
  if (target == null) fail(`${squadron.name} is full (${squadron.slots}/${squadron.slots}).`);
  if (inHere && current.slot === target) return { changed: false, slot: target };

  const occupant = occupied.get(target); // someone else holding the seat we want
  let bumpedTo = null;
  if (occupant) {
    bumpedTo = lowestFree(squadron.slots, occupied, target);
    if (bumpedTo == null) fail(`${squadron.name} is full — there's no room to move <@${occupant}> aside. Free a slot first.`);
  }

  db.prepare('DELETE FROM squadron_slots WHERE guild_id = ? AND discord_id = ?').run(guildId, discordId);
  if (occupant) {
    db.prepare('DELETE FROM squadron_slots WHERE squadron_id = ? AND slot = ?').run(squadron.id, target);
    db.prepare('INSERT INTO squadron_slots (squadron_id, slot, guild_id, discord_id) VALUES (?, ?, ?, ?)').run(squadron.id, bumpedTo, guildId, occupant);
  }
  db.prepare('INSERT INTO squadron_slots (squadron_id, slot, guild_id, discord_id) VALUES (?, ?, ?, ?)').run(squadron.id, target, guildId, discordId);
  return { changed: true, slot: target, bumped: occupant ? { discordId: occupant, to: bumpedTo } : null };
}

function vacate(guildId, discordId) {
  db.prepare('DELETE FROM squadron_slots WHERE guild_id = ? AND discord_id = ?').run(guildId, discordId);
}

// Keep the wingcom in slot 2 of the wing's first squadron.
function reconcileWingSeat(guildId, wing) {
  if (!wing.wingcom_id) return;
  const first = firstSquadron(wing.id);
  if (!first) return; // waits for the first squadron to be nested in
  if (first.slots < 2) fail(`${first.name} is the first squadron in ${wing.name}, so it needs at least 2 slots to seat the wing commander.`);
  seat(guildId, first, wing.wingcom_id, { slot: 2 });
}

function seatSquadcom(guildId, squadron, pilotId) {
  requireRegistered(guildId, pilotId);
  const wingOf = db.prepare('SELECT name FROM wings WHERE guild_id = ? AND wingcom_id = ?').get(guildId, pilotId);
  if (wingOf) fail(`<@${pilotId}> is the wing commander of ${wingOf.name}; command roles are exclusive.`);
  const other = db.prepare('SELECT name FROM squadrons WHERE guild_id = ? AND squadcom_id = ? AND id != ?').get(guildId, pilotId, squadron.id);
  if (other) fail(`<@${pilotId}> already commands ${other.name}.`);
  seat(guildId, squadron, pilotId, { slot: 1 });
  db.prepare('UPDATE squadrons SET squadcom_id = ? WHERE id = ?').run(pilotId, squadron.id);
}

function nextWingSeq(wingId) {
  return (db.prepare('SELECT MAX(wing_seq) AS m FROM squadrons WHERE wing_id = ?').get(wingId).m ?? 0) + 1;
}

// ---------- public operations ----------
function createWing(guildId, { name, forceTag, roleId, channelId, wingcomId }) {
  return attempt(() => {
    if (getWing(guildId, name)) fail(`There's already a wing called **${name}**.`);
    if (wingcomId) {
      requireRegistered(guildId, wingcomId);
      if (db.prepare('SELECT 1 FROM squadrons WHERE guild_id = ? AND squadcom_id = ?').get(guildId, wingcomId)) fail(`<@${wingcomId}> is a squadron commander; command roles are exclusive.`);
      const other = db.prepare('SELECT name FROM wings WHERE guild_id = ? AND wingcom_id = ?').get(guildId, wingcomId);
      if (other) fail(`<@${wingcomId}> already commands ${other.name}.`);
    }
    const res = db.prepare('INSERT INTO wings (guild_id, name, force_tag, role_id, channel_id, wingcom_id) VALUES (?, ?, ?, ?, ?, ?)')
      .run(guildId, name, forceTag, roleId, channelId, wingcomId ?? null);
    return { wing: getWingById(res.lastInsertRowid) };
  });
}

function createSquadron(guildId, { name, callsign, slots, roleId, wingId, squadcomId }) {
  return attempt(() => {
    if (getSquadron(guildId, name)) fail(`There's already a squadron called **${name}**.`);
    if (db.prepare('SELECT 1 FROM squadrons WHERE guild_id = ? AND callsign = ?').get(guildId, callsign)) fail(`The callsign **${callsign}** is already used by another squadron.`);
    const wing = wingId ? getWingById(wingId) : null;
    const res = db.prepare('INSERT INTO squadrons (guild_id, name, callsign, slots, role_id, wing_id, wing_seq) VALUES (?, ?, ?, ?, ?, ?, ?)')
      .run(guildId, name, callsign, slots, roleId, wing?.id ?? null, wing ? nextWingSeq(wing.id) : null);
    const squadron = getSquadronById(res.lastInsertRowid);
    if (squadcomId) seatSquadcom(guildId, squadron, squadcomId);
    if (wing) reconcileWingSeat(guildId, getWingById(wing.id));
    return { squadron: getSquadronById(squadron.id), wing };
  });
}

function doNest(guildId, squadronId, wingId) {
  const squadron = getSquadronById(squadronId); const wing = getWingById(wingId);
  if (squadron.wing_id === wing.id) fail(`${squadron.name} is already in ${wing.name}.`);
  const oldWing = squadron.wing_id ? getWingById(squadron.wing_id) : null;

  // The old wing's commander sits in this squadron only if it was that wing's first squadron — release them.
  if (oldWing?.wingcom_id) {
    const s = seatOf(guildId, oldWing.wingcom_id);
    if (s && s.squadron_id === squadron.id && firstSquadron(oldWing.id)?.id === squadron.id) vacate(guildId, oldWing.wingcom_id);
  }
  db.prepare('UPDATE squadrons SET wing_id = ?, wing_seq = ? WHERE id = ?').run(wing.id, nextWingSeq(wing.id), squadron.id);
  if (oldWing) reconcileWingSeat(guildId, getWingById(oldWing.id));
  reconcileWingSeat(guildId, getWingById(wing.id));
  return { squadron: getSquadronById(squadron.id), wing, oldWing };
}

const nestSquadron = (guildId, squadronId, wingId) => attempt(() => doNest(guildId, squadronId, wingId));

// Ordinary assignment: lowest free slot. Refuses command holders (replace them first).
function assignPilot(guildId, squadronId, pilotId) {
  return attempt(() => {
    requireRegistered(guildId, pilotId);
    const squadron = getSquadronById(squadronId);
    const a = assignmentOf(guildId, pilotId);
    if (a.commandsSquadron) fail(`<@${pilotId}> is the squadron commander of ${a.commandsSquadron.name}. Name a replacement with \`/force squadcom assign\` first.`);
    if (a.commandsWing) fail(`<@${pilotId}> is the wing commander of ${a.commandsWing.name}. Name a replacement with \`/force wingcom assign\` first.`);
    const before = a.squadron;
    const r = seat(guildId, squadron, pilotId);
    return { squadron, slot: r.slot, changed: r.changed, from: before && before.id !== squadron.id ? before : null };
  });
}

function doAssignSquadcom(guildId, squadronId, pilotId) {
  const squadron = getSquadronById(squadronId);
  const previous = squadron.squadcom_id;
  seatSquadcom(guildId, squadron, pilotId);
  return { squadron: getSquadronById(squadronId), previous: previous && previous !== pilotId ? previous : null };
}
const assignSquadcom = (guildId, squadronId, pilotId) => attempt(() => doAssignSquadcom(guildId, squadronId, pilotId));

function doAssignWingcom(guildId, wingId, pilotId) {
  const wing = getWingById(wingId);
  requireRegistered(guildId, pilotId);
  if (db.prepare('SELECT 1 FROM squadrons WHERE guild_id = ? AND squadcom_id = ?').get(guildId, pilotId)) fail(`<@${pilotId}> is a squadron commander; command roles are exclusive.`);
  const other = db.prepare('SELECT name FROM wings WHERE guild_id = ? AND wingcom_id = ? AND id != ?').get(guildId, pilotId, wing.id);
  if (other) fail(`<@${pilotId}> already commands ${other.name}.`);
  const previous = wing.wingcom_id;
  db.prepare('UPDATE wings SET wingcom_id = ? WHERE id = ?').run(pilotId, wing.id);
  reconcileWingSeat(guildId, getWingById(wing.id));
  return { wing: getWingById(wing.id), previous: previous && previous !== pilotId ? previous : null };
}
const assignWingcom = (guildId, wingId, pilotId) => attempt(() => doAssignWingcom(guildId, wingId, pilotId));

// ---------- editing ----------
// Shrinks/grows a squadron. Pilots sitting in slots that no longer exist move to the lowest free slots;
// refuses (changing nothing) if they won't all fit or the wingcom's seat (slot 2) would disappear.
function resizeSquadron(guildId, squadron, newSlots, moved) {
  if (newSlots < squadron.slots) {
    const members = [...slotsOf(squadron.id).entries()].sort((a, b) => a[0] - b[0]);
    if (members.length > newSlots) fail(`${squadron.name} has ${members.length} pilots, so it can't shrink to ${newSlots} slots. Reassign some pilots first.`);
    const wing = squadron.wing_id ? getWingById(squadron.wing_id) : null;
    if (wing?.wingcom_id && firstSquadron(wing.id)?.id === squadron.id && newSlots < 2) {
      fail(`${squadron.name} is the first squadron in ${wing.name}, so it needs at least 2 slots to seat the wing commander.`);
    }
    for (const [slot, id] of members.filter(([s]) => s > newSlots)) {
      const free = lowestFree(newSlots, slotsOf(squadron.id));
      if (free == null) fail(`${squadron.name} can't shrink to ${newSlots} slots — no room to move <@${id}>.`);
      db.prepare('DELETE FROM squadron_slots WHERE squadron_id = ? AND slot = ?').run(squadron.id, slot);
      db.prepare('INSERT INTO squadron_slots (squadron_id, slot, guild_id, discord_id) VALUES (?, ?, ?, ?)').run(squadron.id, free, guildId, id);
      moved.push({ discordId: id, from: slot, to: free });
    }
  }
  db.prepare('UPDATE squadrons SET slots = ? WHERE id = ?').run(newSlots, squadron.id);
}

// ch: any of { name, forceTag, roleId, channelId, wingcomId } — omitted/unchanged fields are ignored. One transaction:
// if any part is refused, NOTHING is changed. Returns { wing, old, changed: [...] } or { error }.
function editWing(guildId, wingId, ch) {
  return attempt(() => {
    const wing = getWingById(wingId);
    const old = { name: wing.name, forceTag: wing.force_tag, roleId: wing.role_id, channelId: wing.channel_id, rosterMessageId: wing.roster_message_id, wingcomId: wing.wingcom_id };
    const changed = [];
    if (ch.name && ch.name !== wing.name) {
      if (getWing(guildId, ch.name)) fail(`There's already a wing called **${ch.name}**.`);
      db.prepare('UPDATE wings SET name = ? WHERE id = ?').run(ch.name, wing.id); changed.push('name');
    }
    if (ch.forceTag && ch.forceTag !== wing.force_tag) { db.prepare('UPDATE wings SET force_tag = ? WHERE id = ?').run(ch.forceTag, wing.id); changed.push('tag'); }
    if (ch.roleId && ch.roleId !== wing.role_id) { db.prepare('UPDATE wings SET role_id = ? WHERE id = ?').run(ch.roleId, wing.id); changed.push('role'); }
    if (ch.channelId && ch.channelId !== wing.channel_id) {
      // the old roster message lives in the old channel; the service deletes it, and a fresh one is posted in the new channel
      db.prepare('UPDATE wings SET channel_id = ?, roster_message_id = NULL WHERE id = ?').run(ch.channelId, wing.id); changed.push('channel');
    }
    if (ch.wingcomId && ch.wingcomId !== wing.wingcom_id) { doAssignWingcom(guildId, wing.id, ch.wingcomId); changed.push('wingcom'); }
    return { wing: getWingById(wing.id), old, changed };
  });
}

// ch: any of { name, callsign, slots, roleId, wingId, squadcomId }. Same all-or-nothing rule as editWing.
// Returns { squadron, old, changed, moved: [{discordId, from, to}], nested: {wing, oldWing}|null, squadcomPrevious } or { error }.
function editSquadron(guildId, squadronId, ch) {
  return attempt(() => {
    const sq = getSquadronById(squadronId);
    const old = { name: sq.name, callsign: sq.callsign, slots: sq.slots, roleId: sq.role_id, wingId: sq.wing_id, squadcomId: sq.squadcom_id };
    const changed = []; const moved = []; let nested = null; let squadcomPrevious = null;

    if (ch.name && ch.name !== sq.name) {
      if (getSquadron(guildId, ch.name)) fail(`There's already a squadron called **${ch.name}**.`);
      db.prepare('UPDATE squadrons SET name = ? WHERE id = ?').run(ch.name, sq.id); changed.push('name');
    }
    if (ch.callsign && ch.callsign !== sq.callsign) {
      if (db.prepare('SELECT 1 FROM squadrons WHERE guild_id = ? AND callsign = ? AND id != ?').get(guildId, ch.callsign, sq.id)) fail(`The callsign **${ch.callsign}** is already used by another squadron.`);
      db.prepare('UPDATE squadrons SET callsign = ? WHERE id = ?').run(ch.callsign, sq.id); changed.push('callsign');
    }
    if (ch.roleId && ch.roleId !== sq.role_id) { db.prepare('UPDATE squadrons SET role_id = ? WHERE id = ?').run(ch.roleId, sq.id); changed.push('role'); }
    if (ch.slots && ch.slots !== sq.slots) { resizeSquadron(guildId, getSquadronById(sq.id), ch.slots, moved); changed.push('slots'); }
    if (ch.wingId && ch.wingId !== sq.wing_id) { nested = doNest(guildId, sq.id, ch.wingId); changed.push('wing'); }
    if (ch.squadcomId && ch.squadcomId !== getSquadronById(sq.id).squadcom_id) {
      squadcomPrevious = doAssignSquadcom(guildId, sq.id, ch.squadcomId).previous; changed.push('squadcom');
    }
    return { squadron: getSquadronById(sq.id), old, changed, moved, nested, squadcomPrevious };
  });
}

// Register (if needed) + seat + starting rank, all or nothing.
function onboardPilot(guildId, { discordId, geofsId, squadronId, actorId, startingRank }) {
  return attempt(() => {
    const squadron = getSquadronById(squadronId);
    if (geofsId) {
      const r = pilotsRepo.register(guildId, discordId, geofsId, actorId);
      if (r.error) fail(r.error);
    } else {
      requireRegistered(guildId, discordId);
    }
    const a = assignmentOf(guildId, discordId);
    if (a.commandsSquadron || a.commandsWing) fail(`<@${discordId}> holds a command seat, so they can't be moved by onboarding. Use the command-assign commands.`);
    const r = seat(guildId, squadron, discordId);
    if (startingRank && !pilotsRepo.getByDiscord(guildId, discordId).rank_name) pilotsRepo.setRank(guildId, discordId, startingRank);
    return { squadron, slot: r.slot, from: a.squadron && a.squadron.id !== squadron.id ? a.squadron : null };
  });
}

module.exports = {
  getWing, getWingById, listWings, getSquadron, getSquadronById, listSquadrons, squadronsInWing, firstSquadron,
  slotsOf, seatOf, assignmentOf, callsignOf, seatSnapshot, setRosterMessage,
  createWing, createSquadron, nestSquadron, assignPilot, assignSquadcom, assignWingcom, onboardPilot, editWing, editSquadron,
};
