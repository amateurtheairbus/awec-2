const db = require('../index');

function get(guildId, geofsId) {
  return db.prepare('SELECT * FROM intel_contacts WHERE guild_id = ? AND geofs_id = ?').get(guildId, String(geofsId));
}

// Returns { entry, created }.
function add(guildId, geofsId, { notes, alertOnSighting, flaggedBy }) {
  geofsId = String(geofsId).trim();
  const existing = get(guildId, geofsId);
  if (existing) {
    db.prepare('UPDATE intel_contacts SET notes = COALESCE(?, notes), alert_on_sighting = COALESCE(?, alert_on_sighting) WHERE guild_id = ? AND geofs_id = ?')
      .run(notes ?? null, alertOnSighting == null ? null : (alertOnSighting ? 1 : 0), guildId, geofsId);
    return { entry: get(guildId, geofsId), created: false };
  }
  db.prepare('INSERT INTO intel_contacts (guild_id, geofs_id, notes, alert_on_sighting, flagged_by) VALUES (?, ?, ?, ?, ?)')
    .run(guildId, geofsId, notes ?? null, alertOnSighting === false ? 0 : 1, flaggedBy);
  return { entry: get(guildId, geofsId), created: true };
}

function remove(guildId, geofsId) {
  return db.prepare('DELETE FROM intel_contacts WHERE guild_id = ? AND geofs_id = ?').run(guildId, String(geofsId)).changes > 0;
}

function list(guildId) {
  return db.prepare('SELECT * FROM intel_contacts WHERE guild_id = ? ORDER BY flagged_at').all(guildId);
}

function setAlert(guildId, geofsId, on) {
  return db.prepare('UPDATE intel_contacts SET alert_on_sighting = ? WHERE guild_id = ? AND geofs_id = ?')
    .run(on ? 1 : 0, guildId, String(geofsId)).changes > 0;
}

function recordSighting(guildId, geofsId, callsign, tag) {
  db.prepare("UPDATE intel_contacts SET last_seen_callsign = ?, last_seen_tag = ?, last_seen_at = datetime('now') WHERE guild_id = ? AND geofs_id = ?")
    .run(callsign, tag ?? null, guildId, String(geofsId));
}

module.exports = { get, add, remove, list, setAlert, recordSighting };
