const db = require('../index');

const TUNABLES = {
  threat_spawn_min_s:    { min: 30,  max: 86400 },
  threat_spawn_max_s:    { min: 30,  max: 86400 },
  threat_population_cap: { min: 1,   max: 20 },
  poll_interval_s:       { min: 10,  max: 600 },
  patrol_grace_period_s: { min: 30,  max: 7200 },
};

function get(guildId) {
  db.prepare('INSERT OR IGNORE INTO bot_state (guild_id) VALUES (?)').run(guildId);
  return db.prepare('SELECT * FROM bot_state WHERE guild_id = ?').get(guildId);
}

function setChannels(guildId, { picture, threatLog, patrolLog, intel }) {
  get(guildId);
  db.prepare(`UPDATE bot_state SET picture_channel_id = ?, threat_log_channel_id = ?,
              patrol_log_channel_id = ?, intel_channel_id = ?, picture_message_id = NULL,
              updated_at = datetime('now') WHERE guild_id = ?`)
    .run(picture, threatLog, patrolLog, intel ?? null, guildId);
  return get(guildId);
}

function setPictureMessage(guildId, messageId) {
  db.prepare("UPDATE bot_state SET picture_message_id = ?, updated_at = datetime('now') WHERE guild_id = ?")
    .run(messageId, guildId);
}

// Only whitelisted tunable columns can be set; returns { config } or { error }.
function setTunables(guildId, changes) {
  const current = get(guildId);
  const next = { ...current };
  for (const [key, value] of Object.entries(changes)) {
    const rule = TUNABLES[key];
    if (!rule) return { error: `Unknown setting: ${key}` };
    if (!Number.isInteger(value) || value < rule.min || value > rule.max) {
      return { error: `\`${key}\` must be between ${rule.min} and ${rule.max}.` };
    }
    next[key] = value;
  }
  if (next.threat_spawn_min_s > next.threat_spawn_max_s) {
    return { error: 'Spawn min interval cannot exceed spawn max interval.' };
  }
  const sets = Object.keys(changes).map((k) => `${k} = @${k}`).join(', ');
  if (sets) {
    db.prepare(`UPDATE bot_state SET ${sets}, updated_at = datetime('now') WHERE guild_id = @guild_id`)
      .run({ ...changes, guild_id: guildId });
  }
  return { config: get(guildId) };
}

function listGuildIds() {
  return db.prepare('SELECT guild_id FROM bot_state').all().map((r) => r.guild_id);
}

module.exports = { get, setChannels, setPictureMessage, setTunables, listGuildIds, TUNABLES };
