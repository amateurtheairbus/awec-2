const db = require('../index');

const MAX_PER_GUILD = 25;

const hydrate = (row) => (row ? { ...row, points: row.points ? JSON.parse(row.points) : null } : row);

function list(guildId) {
  return db.prepare('SELECT * FROM territories WHERE guild_id = ? ORDER BY name').all(guildId).map(hydrate);
}

function getByName(guildId, name) {
  return hydrate(db.prepare('SELECT * FROM territories WHERE guild_id = ? AND name = ?').get(guildId, name));
}

// t: { name, shape, centerLat, centerLon, radiusNm, points, minAltFt, maxAltFt, addedBy }
// Returns { territory } or { error }.
function add(guildId, t) {
  if (getByName(guildId, t.name)) return { error: `There's already a territory called **${t.name}**. Remove it first, or pick another name.` };
  if (list(guildId).length >= MAX_PER_GUILD) return { error: `Limit reached (${MAX_PER_GUILD} territories). Remove one first.` };
  const res = db.prepare(`INSERT INTO territories
    (guild_id, name, shape, center_lat, center_lon, radius_nm, points, min_alt_ft, max_alt_ft, added_by)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
    .run(guildId, t.name, t.shape, t.centerLat ?? null, t.centerLon ?? null, t.radiusNm ?? null,
      t.points ? JSON.stringify(t.points) : null, t.minAltFt ?? null, t.maxAltFt ?? null, t.addedBy);
  return { territory: hydrate(db.prepare('SELECT * FROM territories WHERE id = ?').get(res.lastInsertRowid)) };
}

function remove(guildId, name) {
  return db.prepare('DELETE FROM territories WHERE guild_id = ? AND name = ?').run(guildId, name).changes > 0;
}

module.exports = { MAX_PER_GUILD, list, getByName, add, remove };
