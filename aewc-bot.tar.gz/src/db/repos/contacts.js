const db = require('../index');

const FAR_FUTURE_S = 10 * 365 * 24 * 3600;

function get(id) {
  return db.prepare('SELECT * FROM contacts WHERE id = ?').get(id);
}

// Simulated contacts pass every field; live contacts (real GeoFS players) also set source/geofs_id/lat/lon.
function create(guildId, c) {
  const row = { source: 'sim', geofs_id: null, lat: null, lon: null, ...c, guild_id: guildId };
  const res = db.prepare(`INSERT INTO contacts
    (guild_id, callsign, iff, classification, bearing, range_nm, altitude_ft, heading, speed_kt, expires_at,
     source, geofs_id, lat, lon, last_seen_at)
    VALUES (@guild_id, @callsign, @iff, @classification, @bearing, @range_nm, @altitude_ft, @heading, @speed_kt, @expires_at,
     @source, @geofs_id, @lat, @lon, CASE WHEN @source = 'live' THEN datetime('now') ELSE NULL END)`)
    .run(row);
  return get(res.lastInsertRowid);
}

function listActive(guildId) {
  return db.prepare("SELECT * FROM contacts WHERE guild_id = ? AND status = 'active' ORDER BY id").all(guildId);
}

// source: 'sim' | 'live' | undefined (= both)
function countActive(guildId, source) {
  const sql = "SELECT COUNT(*) AS n FROM contacts WHERE guild_id = ? AND status = 'active'" + (source ? ' AND source = ?' : '');
  return (source ? db.prepare(sql).get(guildId, source) : db.prepare(sql).get(guildId)).n;
}

// Only simulated contacts have a lifespan; live ones last as long as the player is seen.
function listExpired(guildId) {
  return db.prepare("SELECT * FROM contacts WHERE guild_id = ? AND status = 'active' AND source = 'sim' AND expires_at <= datetime('now')").all(guildId);
}

function fade(id) {
  db.prepare("UPDATE contacts SET status = 'faded', ended_at = datetime('now') WHERE id = ? AND status = 'active'").run(id);
  return get(id);
}

// Escalation keeps the contact on the picture but changes its IFF/classification in place,
// and pushes its expiry out so it doesn't fade immediately after being upgraded.
function escalate(id, { iff, classification, expiresAt }) {
  db.prepare("UPDATE contacts SET iff = ?, classification = COALESCE(?, classification), expires_at = ? WHERE id = ? AND status = 'active'")
    .run(iff, classification ?? null, expiresAt, id);
  return get(id);
}

function callsignInUse(guildId, callsign) {
  return !!db.prepare("SELECT 1 FROM contacts WHERE guild_id = ? AND callsign = ? AND status = 'active'").get(guildId, callsign);
}

// ---- live contacts (one active contact per GeoFS ID) ----
function getLive(guildId, geofsId) {
  return db.prepare("SELECT * FROM contacts WHERE guild_id = ? AND source = 'live' AND geofs_id = ? AND status = 'active'")
    .get(guildId, String(geofsId));
}

function listLive(guildId) {
  return db.prepare("SELECT * FROM contacts WHERE guild_id = ? AND source = 'live' AND status = 'active' ORDER BY id").all(guildId);
}

function updateLive(id, { callsign, iff, lat, lon, altitude_ft, heading, speed_kt }) {
  db.prepare(`UPDATE contacts SET callsign = ?, iff = ?, lat = ?, lon = ?, altitude_ft = ?, heading = ?, speed_kt = ?,
              last_seen_at = datetime('now') WHERE id = ? AND status = 'active'`)
    .run(callsign, iff, lat, lon, altitude_ft, heading, speed_kt, id);
  return get(id);
}

module.exports = { FAR_FUTURE_S, get, create, listActive, countActive, listExpired, fade, escalate, callsignInUse, getLive, listLive, updateLive };
