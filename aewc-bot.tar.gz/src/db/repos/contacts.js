const db = require('../index');

function get(id) {
  return db.prepare('SELECT * FROM contacts WHERE id = ?').get(id);
}

function create(guildId, c) {
  const res = db.prepare(`INSERT INTO contacts
    (guild_id, callsign, iff, classification, bearing, range_nm, altitude_ft, heading, speed_kt, expires_at)
    VALUES (@guild_id, @callsign, @iff, @classification, @bearing, @range_nm, @altitude_ft, @heading, @speed_kt, @expires_at)`)
    .run({ guild_id: guildId, ...c });
  return get(res.lastInsertRowid);
}

function listActive(guildId) {
  return db.prepare("SELECT * FROM contacts WHERE guild_id = ? AND status = 'active' ORDER BY id").all(guildId);
}

function countActive(guildId) {
  return db.prepare("SELECT COUNT(*) AS n FROM contacts WHERE guild_id = ? AND status = 'active'").get(guildId).n;
}

function listExpired(guildId) {
  return db.prepare("SELECT * FROM contacts WHERE guild_id = ? AND status = 'active' AND expires_at <= datetime('now')").all(guildId);
}

function fade(id) {
  db.prepare("UPDATE contacts SET status = 'faded', ended_at = datetime('now') WHERE id = ? AND status = 'active'").run(id);
  return get(id);
}

// Escalation keeps the contact on the picture but changes its IFF/classification in place,
// and pushes its expiry out so it doesn't fade immediately after being upgraded.
function escalate(id, { iff, classification, expiresAt }) {
  db.prepare("UPDATE contacts SET iff = ?, classification = COALESCE(?, classification), expires_at = ? WHERE id = ? AND status = 'active'")
    .run(iff, classification ?? null, expiresAt, id);
  return get(id);
}

function callsignInUse(guildId, callsign) {
  return !!db.prepare("SELECT 1 FROM contacts WHERE guild_id = ? AND callsign = ? AND status = 'active'").get(guildId, callsign);
}

module.exports = { get, create, listActive, countActive, listExpired, fade, escalate, callsignInUse };
