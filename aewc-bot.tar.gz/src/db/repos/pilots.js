const db = require('../index');

function getByDiscord(guildId, discordId) {
  return db.prepare('SELECT * FROM pilots WHERE guild_id = ? AND discord_id = ? AND active = 1').get(guildId, discordId);
}

function getByGeofs(guildId, geofsId) {
  return db.prepare('SELECT * FROM pilots WHERE guild_id = ? AND geofs_id = ? AND active = 1').get(guildId, String(geofsId));
}

// Returns { pilot } or { error }. A GeoFS ID can belong to only one active pilot per guild.
function register(guildId, discordId, geofsId, registeredBy) {
  geofsId = String(geofsId).trim();
  const owner = getByGeofs(guildId, geofsId);
  if (owner && owner.discord_id !== discordId) {
    return { error: `GeoFS ID \`${geofsId}\` is already registered to <@${owner.discord_id}>.` };
  }
  db.prepare(`INSERT INTO pilots (guild_id, discord_id, geofs_id, registered_by, active)
              VALUES (?, ?, ?, ?, 1)
              ON CONFLICT(guild_id, discord_id) DO UPDATE SET
                geofs_id = excluded.geofs_id, registered_by = excluded.registered_by,
                registered_at = datetime('now'), active = 1`)
    .run(guildId, discordId, geofsId, registeredBy);
  return { pilot: getByDiscord(guildId, discordId) };
}

function remove(guildId, discordId) {
  return db.prepare('UPDATE pilots SET active = 0 WHERE guild_id = ? AND discord_id = ? AND active = 1')
    .run(guildId, discordId).changes > 0;
}

function list(guildId) {
  return db.prepare('SELECT * FROM pilots WHERE guild_id = ? AND active = 1 ORDER BY registered_at').all(guildId);
}

module.exports = { getByDiscord, getByGeofs, register, remove, list };
