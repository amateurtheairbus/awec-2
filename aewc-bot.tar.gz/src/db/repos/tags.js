const db = require('../index');
const { normalizeCallsign } = require('../../util/callsign');
const { TAG_CATEGORY } = require('../../util/constants');

const CATEGORIES = Object.values(TAG_CATEGORY);
// If a callsign carries tags of several categories, the most security-relevant one wins:
// a callsign with a hostile tag is hostile even if it also carries one of ours.
const PRECEDENCE = [TAG_CATEGORY.HOSTILE, TAG_CATEGORY.US, TAG_CATEGORY.FRIENDLY];

// Tags are stored uppercase, without brackets. Accepts "[usaf]", "usaf", "USAF".
function normalize(raw) {
  const t = normalizeCallsign(String(raw).trim().replace(/^\[|\]$/g, ''));
  return /^[A-Z0-9_-]{1,12}$/.test(t) ? t : null;
}

// Adds a tag to a category; re-adding under a different category MOVES it.
// Returns { status: 'added' | 'moved' | 'unchanged', from? }.
function add(guildId, tag, addedBy, category = TAG_CATEGORY.US) {
  if (!CATEGORIES.includes(category)) throw new Error(`Unknown tag category: ${category}`);
  const existing = db.prepare('SELECT category FROM callsign_tags WHERE guild_id = ? AND tag = ?').get(guildId, tag);
  if (!existing) {
    db.prepare('INSERT INTO callsign_tags (guild_id, tag, added_by, category) VALUES (?, ?, ?, ?)').run(guildId, tag, addedBy, category);
    return { status: 'added' };
  }
  if (existing.category === category) return { status: 'unchanged' };
  db.prepare('UPDATE callsign_tags SET category = ?, added_by = ? WHERE guild_id = ? AND tag = ?').run(category, addedBy, guildId, tag);
  return { status: 'moved', from: existing.category };
}

function remove(guildId, tag) {
  return db.prepare('DELETE FROM callsign_tags WHERE guild_id = ? AND tag = ?').run(guildId, tag).changes > 0;
}

function list(guildId) {
  return db.prepare('SELECT tag FROM callsign_tags WHERE guild_id = ? ORDER BY tag').all(guildId).map((r) => r.tag);
}

function listByCategory(guildId) {
  const out = { us: [], friendly: [], hostile: [] };
  for (const r of db.prepare('SELECT tag, category FROM callsign_tags WHERE guild_id = ? ORDER BY tag').all(guildId)) {
    (out[r.category] ?? (out[r.category] = [])).push(r.tag);
  }
  return out;
}

function categoryMap(guildId) {
  return new Map(db.prepare('SELECT tag, category FROM callsign_tags WHERE guild_id = ?').all(guildId).map((r) => [r.tag, r.category]));
}

function bracketTokens(upperCallsign) {
  return [...upperCallsign.matchAll(/\[([^\]]{1,12})\]/g)].map((m) => ({
    text: m[1].trim(), start: m.index, end: m.index + m[0].length,
  }));
}

// Splits an in-sim callsign like "LEOPARD-2[H7T][SAAF]" into its parts. The callsign is normalized
// (upper-cased etc.) first, so recognition is always case-insensitive.
//   tag      — the recognized tag that decided the category
//   category — us | friendly | hostile (hostile beats us beats friendly)
//   code     — the bracket token immediately BEFORE the tag bracket (the flight code), if any
//   name     — the callsign with all bracket tokens removed
// Returns null when no configured tag is present. Tags may appear anywhere in the callsign.
function parseCallsign(guildId, callsign) {
  const raw = normalizeCallsign(callsign);
  const tokens = bracketTokens(raw);
  if (!tokens.length) return null;
  const known = categoryMap(guildId);

  let idx = -1;
  for (const cat of PRECEDENCE) {
    idx = tokens.findIndex((t) => known.get(t.text) === cat);
    if (idx !== -1) break;
  }
  if (idx === -1) return null;

  const prev = tokens[idx - 1];
  const code = prev && prev.end === tokens[idx].start && !known.has(prev.text) ? prev.text : null;
  return {
    tag: tokens[idx].text,
    category: known.get(tokens[idx].text),
    code,
    name: raw.replace(/\[[^\]]*\]/g, '').replace(/\s+/g, ' ').trim(),
  };
}

// Parses a callsign for ONE specific tag (independent of the guild's tag list).
// Returns { code, name } or null.
function parseForTag(callsign, tag) {
  const raw = normalizeCallsign(callsign);
  const want = normalizeCallsign(tag);
  const tokens = bracketTokens(raw);
  const idx = tokens.findIndex((t) => t.text === want);
  if (idx === -1) return null;
  const prev = tokens[idx - 1];
  return {
    code: prev && prev.end === tokens[idx].start ? prev.text : null,
    name: raw.replace(/\[[^\]]*\]/g, '').replace(/\s+/g, ' ').trim(),
  };
}

// Back-compat helper: just the matched tag (or null).
function matchCallsign(guildId, callsign) {
  return parseCallsign(guildId, callsign)?.tag ?? null;
}

module.exports = { CATEGORIES, normalize, add, remove, list, listByCategory, categoryMap, parseCallsign, parseForTag, matchCallsign };
