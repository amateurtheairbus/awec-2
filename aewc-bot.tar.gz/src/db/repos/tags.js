const db = require('../index');

// Tags are stored uppercase, without brackets. Accepts "[usaf]", "usaf", "USAF".
function normalize(raw) {
  const t = String(raw).trim().replace(/^\[|\]$/g, '').toUpperCase();
  return /^[A-Z0-9_-]{1,12}$/.test(t) ? t : null;
}

function add(guildId, tag, addedBy) {
  const res = db.prepare('INSERT OR IGNORE INTO callsign_tags (guild_id, tag, added_by) VALUES (?, ?, ?)')
    .run(guildId, tag, addedBy);
  return res.changes > 0;
}

function remove(guildId, tag) {
  return db.prepare('DELETE FROM callsign_tags WHERE guild_id = ? AND tag = ?').run(guildId, tag).changes > 0;
}

function list(guildId) {
  return db.prepare('SELECT tag FROM callsign_tags WHERE guild_id = ? ORDER BY tag').all(guildId).map((r) => r.tag);
}

// Splits an in-sim callsign like "LEOPARD-2[H7T][SAAF]" into its parts.
//   tag  — first [BRACKET] that is a configured tag for this guild (uppercase)
//   code — the bracket token immediately BEFORE the tag bracket (the flight code), if any
//   name — the callsign with all bracket tokens removed
// Returns null when no configured tag is present. Tags may appear anywhere in the callsign.
function parseCallsign(guildId, callsign) {
  const raw = String(callsign || '');
  const tokens = [...raw.matchAll(/\[([^\]]{1,12})\]/g)].map((m) => ({
    text: m[1].trim().toUpperCase(), start: m.index, end: m.index + m[0].length,
  }));
  if (!tokens.length) return null;
  const known = new Set(list(guildId));
  const idx = tokens.findIndex((t) => known.has(t.text));
  if (idx === -1) return null;

  let code = null;
  const prev = tokens[idx - 1];
  if (prev && prev.end === tokens[idx].start && !known.has(prev.text)) code = prev.text;

  return {
    tag: tokens[idx].text,
    code,
    name: raw.replace(/\[[^\]]*\]/g, '').trim(),
  };
}

// Parses a callsign for ONE specific tag (independent of the guild's tag list).
// Returns { code, name } or null. `code` is the bracket token right before the tag, if any.
function parseForTag(callsign, tag) {
  const raw = String(callsign || '');
  const want = String(tag || '').toUpperCase();
  const tokens = [...raw.matchAll(/\[([^\]]{1,12})\]/g)].map((m) => ({
    text: m[1].trim().toUpperCase(), start: m.index, end: m.index + m[0].length,
  }));
  const idx = tokens.findIndex((t) => t.text === want);
  if (idx === -1) return null;
  const prev = tokens[idx - 1];
  return {
    code: prev && prev.end === tokens[idx].start ? prev.text : null,
    name: raw.replace(/\[[^\]]*\]/g, '').trim(),
  };
}

// Back-compat helper: just the matched tag (or null).
function matchCallsign(guildId, callsign) {
  return parseCallsign(guildId, callsign)?.tag ?? null;
}

module.exports = { normalize, add, remove, list, parseCallsign, parseForTag, matchCallsign };
