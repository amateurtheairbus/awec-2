const db = require('../index');
const config = require('./config');
const tags = require('./tags');

const CHARSETS = ['alnum', 'letters', 'numbers'];
const LIMITS = { length: [1, 8], intervalMin: [5, 10080] };

// Validates raw setup input; returns an error string or null.
function validate({ charset, length, intervalMinutes }) {
  if (!CHARSETS.includes(charset)) return 'Charset must be letters+numbers, letters only, or numbers only.';
  if (!Number.isInteger(length) || length < LIMITS.length[0] || length > LIMITS.length[1]) {
    return `Code length must be ${LIMITS.length[0]}–${LIMITS.length[1]}.`;
  }
  if (!Number.isInteger(intervalMinutes) || intervalMinutes < LIMITS.intervalMin[0] || intervalMinutes > LIMITS.intervalMin[1]) {
    return `Interval must be ${LIMITS.intervalMin[0]}–${LIMITS.intervalMin[1]} minutes.`;
  }
  return null;
}

// Saves the schema/targets. Also makes sure the force tag is a recognized callsign tag so the
// patrol logic treats it like any other force tag. Does NOT touch the current code.
function setup(guildId, { forceTag, charset, length, intervalMinutes, channelId, alertChannelId, scrambleRoleId, strict, addedBy }) {
  config.get(guildId);
  tags.add(guildId, forceTag, addedBy);
  db.prepare(`UPDATE bot_state SET flightcode_enabled = 1, flightcode_force_tag = ?, flightcode_charset = ?,
              flightcode_length = ?, flightcode_interval_s = ?, flightcode_channel_id = ?,
              flightcode_alert_channel_id = ?, flightcode_scramble_role_id = ?, flightcode_strict = ?,
              updated_at = datetime('now') WHERE guild_id = ?`)
    .run(forceTag, charset, length, intervalMinutes * 60, channelId, alertChannelId ?? null, scrambleRoleId, strict ? 1 : 0, guildId);
  return config.get(guildId);
}

function disable(guildId) {
  db.prepare("UPDATE bot_state SET flightcode_enabled = 0, updated_at = datetime('now') WHERE guild_id = ?").run(guildId);
}

// Rotating moves the current code to "previous" (accepted for a short grace window).
function setCode(guildId, code, messageId) {
  db.prepare(`UPDATE bot_state SET flightcode_previous = flightcode_current, flightcode_current = ?,
              flightcode_rotated_at = datetime('now'), flightcode_message_id = ?, updated_at = datetime('now')
              WHERE guild_id = ?`).run(code, messageId ?? null, guildId);
  return config.get(guildId);
}

// ---- alert throttle ----
function shouldAlert(guildId, geofsId, kind, nowUnix, cooldownS, toUnix) {
  const row = db.prepare('SELECT last_alert_at FROM flightcode_alerts WHERE guild_id = ? AND geofs_id = ? AND kind = ?')
    .get(guildId, geofsId, kind);
  return !row || nowUnix - toUnix(row.last_alert_at) >= cooldownS;
}
function markAlerted(guildId, geofsId, kind) {
  db.prepare(`INSERT INTO flightcode_alerts (guild_id, geofs_id, kind) VALUES (?, ?, ?)
              ON CONFLICT(guild_id, geofs_id, kind) DO UPDATE SET last_alert_at = datetime('now')`)
    .run(guildId, geofsId, kind);
}
function clearAlerts(guildId, geofsId) {
  db.prepare('DELETE FROM flightcode_alerts WHERE guild_id = ? AND geofs_id = ?').run(guildId, geofsId);
}
function countAlerts(guildId) {
  return db.prepare('SELECT COUNT(*) AS n FROM flightcode_alerts WHERE guild_id = ?').get(guildId).n;
}

module.exports = { CHARSETS, LIMITS, validate, setup, disable, setCode, shouldAlert, markAlerted, clearAlerts, countAlerts };
