-- AEW&C bot schema
-- Discord messages are always a VIEW of this state — every trigger writes here first,
-- then re-renders. Nothing is Discord-side-only.

-- Per-guild bot configuration: channel mappings, tunables, live picture message id.
-- One row per guild.
CREATE TABLE IF NOT EXISTS bot_state (
  guild_id            TEXT PRIMARY KEY,
  picture_channel_id  TEXT,
  picture_message_id  TEXT,
  threat_log_channel_id TEXT,
  patrol_log_channel_id TEXT,
  intel_channel_id    TEXT,

  -- tunables (all in seconds unless noted)
  threat_spawn_min_s     INTEGER NOT NULL DEFAULT 300,   -- 5 min
  threat_spawn_max_s     INTEGER NOT NULL DEFAULT 1200,  -- 20 min
  threat_population_cap  INTEGER NOT NULL DEFAULT 8,
  poll_interval_s        INTEGER NOT NULL DEFAULT 45,
  patrol_grace_period_s  INTEGER NOT NULL DEFAULT 300,   -- 5 min

  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Callsign tags this guild treats as "military roleplay" e.g. [USAF], [UAEAF], [SAAF]
CREATE TABLE IF NOT EXISTS callsign_tags (
  guild_id TEXT NOT NULL,
  tag      TEXT NOT NULL,   -- stored WITHOUT brackets, e.g. "USAF"
  added_by TEXT,
  added_at TEXT NOT NULL DEFAULT (datetime('now')),
  PRIMARY KEY (guild_id, tag)
);

-- Registered pilot roster: Discord user <-> GeoFS ID
CREATE TABLE IF NOT EXISTS pilots (
  guild_id      TEXT NOT NULL,
  discord_id    TEXT NOT NULL,
  geofs_id      TEXT NOT NULL,
  registered_by TEXT NOT NULL,
  registered_at TEXT NOT NULL DEFAULT (datetime('now')),
  active        INTEGER NOT NULL DEFAULT 1,  -- 0 = removed but kept for history
  PRIMARY KEY (guild_id, discord_id)
);
CREATE INDEX IF NOT EXISTS idx_pilots_geofs_id ON pilots(guild_id, geofs_id);

-- Intelligence watchlist: GeoFS IDs of interest not on our own roster
CREATE TABLE IF NOT EXISTS intel_contacts (
  guild_id           TEXT NOT NULL,
  geofs_id           TEXT NOT NULL,
  notes              TEXT,
  alert_on_sighting  INTEGER NOT NULL DEFAULT 1,
  last_seen_callsign TEXT,
  last_seen_tag      TEXT,
  last_seen_at       TEXT,
  flagged_by         TEXT NOT NULL,
  flagged_at         TEXT NOT NULL DEFAULT (datetime('now')),
  PRIMARY KEY (guild_id, geofs_id)
);

-- Patrols: both manually started and auto-started (from GeoFS presence detection)
CREATE TABLE IF NOT EXISTS patrols (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  guild_id      TEXT NOT NULL,
  discord_id    TEXT NOT NULL,
  geofs_id      TEXT,              -- populated when auto-started or linked to a roster pilot
  aircraft      TEXT,
  callsign_tag  TEXT,              -- tag pilot was flying under at patrol start
  status        TEXT NOT NULL DEFAULT 'active',  -- active | rtb | ended
  auto_started  INTEGER NOT NULL DEFAULT 0,
  last_seen_at  TEXT,              -- for auto-started patrols: last poll tick pilot was seen online
  started_at    TEXT NOT NULL DEFAULT (datetime('now')),
  ended_at      TEXT
);
CREATE INDEX IF NOT EXISTS idx_patrols_active ON patrols(guild_id, status);
CREATE INDEX IF NOT EXISTS idx_patrols_discord_id ON patrols(guild_id, discord_id);

-- Simulated radar contacts (independent of real GeoFS state — the random threat timer)
CREATE TABLE IF NOT EXISTS contacts (
  id             INTEGER PRIMARY KEY AUTOINCREMENT,
  guild_id       TEXT NOT NULL,
  callsign       TEXT NOT NULL,
  iff            TEXT NOT NULL,   -- friendly | hostile | unknown
  classification TEXT NOT NULL,  -- fighter | bomber | transport | unknown
  bearing        INTEGER NOT NULL,  -- degrees 0-359
  range_nm       INTEGER NOT NULL,
  altitude_ft    INTEGER NOT NULL,
  heading        INTEGER NOT NULL,  -- degrees 0-359
  speed_kt       INTEGER NOT NULL,
  status         TEXT NOT NULL DEFAULT 'active',  -- active | faded | escalated
  spawned_at     TEXT NOT NULL DEFAULT (datetime('now')),
  expires_at     TEXT NOT NULL,
  ended_at       TEXT
);
CREATE INDEX IF NOT EXISTS idx_contacts_active ON contacts(guild_id, status);

-- Append-only log of every state transition. Powers #threat-log / #patrol-log —
-- those channels mirror inserts here, so DB writes and Discord posts never desync.
CREATE TABLE IF NOT EXISTS event_log (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  guild_id   TEXT NOT NULL,
  event_type TEXT NOT NULL,  -- contact_spawned | contact_faded | contact_escalated |
                              -- patrol_started | patrol_rtb | patrol_ended |
                              -- intel_sighting | intel_added | intel_removed
  ref_table  TEXT,           -- 'contacts' | 'patrols' | 'intel_contacts'
  ref_id     TEXT,           -- id or geofs_id of the referenced row
  actor_id   TEXT,           -- discord user id who caused it, if applicable
  detail     TEXT,           -- freeform / JSON blob for extra context
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_event_log_guild_time ON event_log(guild_id, created_at);

-- Flight-code alert throttle: one row per (player, kind) so a mismatch pings once, then again
-- only after the re-ping cooldown. Cleared when the player is seen compliant.
CREATE TABLE IF NOT EXISTS flightcode_alerts (
  guild_id      TEXT NOT NULL,
  geofs_id      TEXT NOT NULL,
  kind          TEXT NOT NULL,      -- update | impersonator
  last_alert_at TEXT NOT NULL DEFAULT (datetime('now')),
  PRIMARY KEY (guild_id, geofs_id, kind)
);

-- Scramble airspace: a hostile contact inside one of these (and inside its altitude band) triggers a
-- scramble. With NO territories defined, hostiles scramble anywhere they are seen.
CREATE TABLE IF NOT EXISTS territories (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  guild_id    TEXT NOT NULL,
  name        TEXT NOT NULL,            -- stored UPPER-CASE
  shape       TEXT NOT NULL,            -- circle | polygon
  center_lat  REAL,
  center_lon  REAL,
  radius_nm   REAL,
  points      TEXT,                     -- JSON [[lat,lon],...] for polygons
  min_alt_ft  INTEGER,
  max_alt_ft  INTEGER,
  added_by    TEXT NOT NULL,
  created_at  TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE (guild_id, name)
);
