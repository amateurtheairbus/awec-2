// Registers all slash commands with Discord. Run this whenever command
// definitions change (`npm run deploy-commands`).
//
// If DISCORD_DEV_GUILD_ID is set, commands are registered to that single guild
// (updates propagate instantly — good for development). Otherwise commands are
// registered globally (can take up to ~1hr to propagate to all servers).
require('dotenv').config();
const { REST, Routes } = require('discord.js');
const { loadCommands } = require('./util/commandLoader');

async function deploy() {
  const commands = loadCommands().map((c) => c.data.toJSON());
  const rest = new REST().setToken(process.env.DISCORD_TOKEN);
  const clientId = process.env.DISCORD_CLIENT_ID;
  const devGuildId = process.env.DISCORD_DEV_GUILD_ID;

  const route = devGuildId
    ? Routes.applicationGuildCommands(clientId, devGuildId)
    : Routes.applicationCommands(clientId);

  console.log(`Deploying ${commands.length} command(s) ${devGuildId ? `to guild ${devGuildId}` : 'globally'}...`);
  const result = await rest.put(route, { body: commands });
  console.log(`Successfully deployed ${result.length} command(s): ${result.map((c) => c.name).join(', ')}`);
}

deploy().catch((err) => { console.error('Deploy failed:', err.message); process.exit(1); });
