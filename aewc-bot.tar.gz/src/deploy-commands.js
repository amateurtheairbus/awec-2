// Registers all slash commands with Discord. Run this whenever command
// definitions change (`npm run deploy-commands`).
//
// If DISCORD_DEV_GUILD_ID is set, commands are registered to that single guild
// (updates propagate instantly — good for development). Otherwise commands are
// registered globally (can take up to ~1hr to propagate to all servers).
require('dotenv').config();
const fs = require('fs');
const path = require('path');
const { REST, Routes } = require('discord.js');

function loadCommandData() {
  const commandsRoot = path.join(__dirname, 'commands');
  const data = [];
  for (const group of fs.readdirSync(commandsRoot)) {
    const groupPath = path.join(commandsRoot, group);
    if (!fs.statSync(groupPath).isDirectory()) continue;
    for (const file of fs.readdirSync(groupPath).filter((f) => f.endsWith('.js'))) {
      const command = require(path.join(groupPath, file));
      if (command?.data) data.push(command.data.toJSON());
    }
  }
  return data;
}

async function deploy() {
  const commands = loadCommandData();
  const rest = new REST().setToken(process.env.DISCORD_TOKEN);
  const clientId = process.env.DISCORD_CLIENT_ID;
  const devGuildId = process.env.DISCORD_DEV_GUILD_ID;

  const route = devGuildId
    ? Routes.applicationGuildCommands(clientId, devGuildId)
    : Routes.applicationCommands(clientId);

  console.log(`Deploying ${commands.length} command(s) ${devGuildId ? `to guild ${devGuildId}` : 'globally'}...`);
  const result = await rest.put(route, { body: commands });
  console.log(`Successfully deployed ${result.length} command(s).`);
}

deploy().catch(console.error);
