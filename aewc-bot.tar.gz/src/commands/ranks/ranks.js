const { SlashCommandBuilder } = require('discord.js');
const { ephemeral } = require('../../util/reply');
const { isAdmin, denyAdmin } = require('../../util/permissions');
const { parseRanksSpec, extractRoleList } = require('../../util/roles');
const ranksRepo = require('../../db/repos/ranks');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ranks')
    .setDescription('Set up and view the rank ladder')
    .addSubcommand((s) =>
      s.setName('setup').setDescription('Define the ranks and the Discord roles each one grants (replaces the old ladder)')
        .addStringOption((o) => o.setName('ranks').setDescription('Format: @role1,@role2;Rank One,Rank Two — lowest rank first').setRequired(true))
        .addStringOption((o) => o.setName('enlisted_roles').setDescription('Roles EVERY registered pilot gets, e.g. @Pilot,@Enlisted (optional)')))
    .addSubcommand((s) => s.setName('list').setDescription('Show the rank ladder')),

  async execute(interaction) {
    const guildId = interaction.guildId;
    const sub = interaction.options.getSubcommand();

    if (sub === 'list') {
      const ranks = ranksRepo.list(guildId);
      if (!ranks.length) return interaction.reply(ephemeral('No ranks set up yet. An admin can run `/ranks setup`.'));
      const enlisted = ranksRepo.enlistedRoleIds(guildId);
      const lines = ranks.map((r, i) => `${i + 1}. **${r.name}** — ${r.role_ids.map((id) => `<@&${id}>`).join(' ')}${i === 0 ? ' _(starting rank)_' : ''}`);
      return interaction.reply(ephemeral(`**Rank ladder** (lowest first)\n${lines.join('\n')}` +
        (enlisted.length ? `\n\n**Given to every registered pilot:** ${enlisted.map((id) => `<@&${id}>`).join(' ')}` : '')));
    }

    if (!isAdmin(interaction)) return denyAdmin(interaction);
    const guild = interaction.guild;
    const parsed = parseRanksSpec(guild, interaction.options.getString('ranks', true));
    if (parsed.error) return interaction.reply(ephemeral(parsed.error));

    let enlisted = [];
    const enlistedRaw = interaction.options.getString('enlisted_roles');
    if (enlistedRaw) {
      const r = extractRoleList(guild, enlistedRaw);
      if (r.unknown.length) return interaction.reply(ephemeral(`I couldn't find the role ${r.unknown[0]} in enlisted_roles. Mention it with @.`));
      enlisted = r.ids;
    }

    ranksRepo.replace(guildId, parsed.ranks, enlisted);
    const lines = parsed.ranks.map((r, i) => `${i + 1}. **${r.name}** — ${r.roleIds.map((id) => `<@&${id}>`).join(' ')}`);
    return interaction.reply(ephemeral(
      `Rank ladder saved (lowest first):\n${lines.join('\n')}` +
      (enlisted.length ? `\nEvery registered pilot also gets: ${enlisted.map((id) => `<@&${id}>`).join(' ')}` : '') +
      `\n\n\`/onboard\` starts pilots at **${parsed.ranks[0].name}**; use \`/promote\` to change a pilot's rank (it swaps their rank roles).` +
      '\nMake sure my role is above these roles in Server Settings → Roles, and that I have **Manage Roles**.'));
  },
};

// Who may run it (shown by /commands list). Keys are subcommand paths (longest prefix wins); enforced in execute().
module.exports.access = { default: 'everyone', setup: 'admin' };
