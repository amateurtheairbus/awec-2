const { SlashCommandBuilder, ChannelType } = require('discord.js');
const { MessageFlags } = require('discord.js');
const { isAdmin, denyAdmin } = require('../../util/permissions');
const { ephemeral } = require('../../util/reply');
const configRepo = require('../../db/repos/config');
const tagsRepo = require('../../db/repos/tags');
const pictureSvc = require('../../services/picture');
const flightRepo = require('../../db/repos/flightcode');
const flightSvc = require('../../services/flightcode');
const { discordTs, toUnix } = require('../../util/time');
const { ADMIN_DEFAULT_PERMISSIONS } = require('../../util/constants');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('aewc')
    .setDescription('AEW&C bot administration')
    .setDefaultMemberPermissions(ADMIN_DEFAULT_PERMISSIONS)
    .addSubcommand((sub) =>
      sub
        .setName('setup')
        .setDescription('Configure channel mappings for this server')
        .addChannelOption((opt) =>
          opt.setName('picture_channel').setDescription('Live airspace picture channel')
            .addChannelTypes(ChannelType.GuildText).setRequired(true))
        .addChannelOption((opt) =>
          opt.setName('threat_log_channel').setDescription('Threat contact log channel')
            .addChannelTypes(ChannelType.GuildText).setRequired(true))
        .addChannelOption((opt) =>
          opt.setName('patrol_log_channel').setDescription('Patrol log channel')
            .addChannelTypes(ChannelType.GuildText).setRequired(true))
        .addChannelOption((opt) =>
          opt.setName('intel_channel').setDescription('Intel sighting alerts channel (defaults to threat log)')
            .addChannelTypes(ChannelType.GuildText).setRequired(false))
    )
    .addSubcommand((sub) =>
      sub
        .setName('config')
        .setDescription('View or adjust tunable parameters')
        .addIntegerOption((opt) => opt.setName('threat_spawn_min_s').setDescription('Min seconds between threat spawns'))
        .addIntegerOption((opt) => opt.setName('threat_spawn_max_s').setDescription('Max seconds between threat spawns'))
        .addIntegerOption((opt) => opt.setName('threat_population_cap').setDescription('Max concurrent simulated contacts'))
        .addIntegerOption((opt) => opt.setName('poll_interval_s').setDescription('GeoFS presence poll interval (seconds)'))
        .addIntegerOption((opt) => opt.setName('patrol_grace_period_s').setDescription('Grace period before auto-RTB (seconds)'))
    )
    .addSubcommandGroup((group) =>
      group
        .setName('tags')
        .setDescription('Manage recognized military roleplay callsign tags')
        .addSubcommand((sub) =>
          sub.setName('add').setDescription('Add a recognized callsign tag')
            .addStringOption((opt) => opt.setName('tag').setDescription('Tag without brackets, e.g. USAF').setRequired(true)))
        .addSubcommand((sub) =>
          sub.setName('remove').setDescription('Remove a recognized callsign tag')
            .addStringOption((opt) => opt.setName('tag').setDescription('Tag without brackets, e.g. USAF').setRequired(true)))
        .addSubcommand((sub) =>
          sub.setName('list').setDescription('List recognized callsign tags'))
    )
    .addSubcommandGroup((group) =>
      group
        .setName('flightcode')
        .setDescription('Flight-code verification for callsigns')
        .addSubcommand((sub) =>
          sub.setName('setup').setDescription('Configure (or reconfigure) flight codes and post the first one')
            .addStringOption((o) => o.setName('force_tag').setDescription('Force tag to police, e.g. SAAF').setRequired(true))
            .addChannelOption((o) => o.setName('channel').setDescription('Channel the code is posted in')
              .addChannelTypes(ChannelType.GuildText).setRequired(true))
            .addRoleOption((o) => o.setName('scramble_role').setDescription('Role pinged for impersonators').setRequired(true))
            .addStringOption((o) => o.setName('charset').setDescription('Characters used in the code (default: letters + numbers)')
              .addChoices({ name: 'Letters + numbers', value: 'alnum' }, { name: 'Letters only', value: 'letters' }, { name: 'Numbers only', value: 'numbers' }))
            .addIntegerOption((o) => o.setName('length').setDescription('Code length (default 3)').setMinValue(1).setMaxValue(8))
            .addIntegerOption((o) => o.setName('interval_minutes').setDescription('Minutes between new codes (default 1440 = daily)').setMinValue(5).setMaxValue(10080))
            .addChannelOption((o) => o.setName('alert_channel').setDescription('Where mismatch/impersonator alerts go (default: the code channel)')
              .addChannelTypes(ChannelType.GuildText))
            .addBooleanOption((o) => o.setName('strict').setDescription('Also flag unregistered players who DO have a valid code (default off)')))
        .addSubcommand((sub) => sub.setName('rotate').setDescription('Post a new flight code right now'))
        .addSubcommand((sub) => sub.setName('status').setDescription('Show the flight-code configuration'))
        .addSubcommand((sub) => sub.setName('disable').setDescription('Turn flight-code verification off'))
    ),

  async execute(interaction) {
    if (!isAdmin(interaction)) return denyAdmin(interaction);

    const guildId = interaction.guildId;
    const sub = interaction.options.getSubcommand();
    const group = interaction.options.getSubcommandGroup(false);

    // ---- /aewc tags ----
    if (group === 'tags') {
      if (sub === 'list') {
        const tags = tagsRepo.list(guildId);
        return interaction.reply(ephemeral(tags.length ? `Recognized tags: ${tags.map((t) => `\`[${t}]\``).join(' ')}` : 'No callsign tags configured yet. Add one with `/aewc tags add`.'));
      }
      const tag = tagsRepo.normalize(interaction.options.getString('tag', true));
      if (!tag) return interaction.reply(ephemeral('Invalid tag. Use 1–12 letters, digits, `-` or `_` (brackets optional).'));
      if (sub === 'add') {
        const added = tagsRepo.add(guildId, tag, interaction.user.id);
        return interaction.reply(ephemeral(added ? `Added \`[${tag}]\`.` : `\`[${tag}]\` is already recognized.`));
      }
      const removed = tagsRepo.remove(guildId, tag);
      return interaction.reply(ephemeral(removed ? `Removed \`[${tag}]\`.` : `\`[${tag}]\` wasn't in the list.`));
    }

    // ---- /aewc flightcode ----
    if (group === 'flightcode') {
      if (sub === 'setup') {
        const forceTag = tagsRepo.normalize(interaction.options.getString('force_tag', true));
        if (!forceTag) return interaction.reply(ephemeral('Invalid force tag. Use 1–12 letters/digits (brackets optional).'));
        const channel = interaction.options.getChannel('channel', true);
        const role = interaction.options.getRole('scramble_role', true);
        const alertCh = interaction.options.getChannel('alert_channel');
        const input = {
          charset: interaction.options.getString('charset') ?? 'alnum',
          length: interaction.options.getInteger('length') ?? 3,
          intervalMinutes: interaction.options.getInteger('interval_minutes') ?? 1440,
        };
        const bad = flightRepo.validate(input);
        if (bad) return interaction.reply(ephemeral(bad));

        const me = interaction.guild.members.me;
        const problems = [];
        for (const ch of [channel, alertCh].filter(Boolean)) {
          const perms = ch.permissionsFor(me);
          const missing = ['ViewChannel', 'SendMessages', 'EmbedLinks'].filter((f) => !perms?.has(f));
          if (missing.length) problems.push(`<#${ch.id}> — missing ${missing.join(', ')}`);
        }
        if (problems.length) return interaction.reply(ephemeral(`I can't post in all of those channels yet:\n${problems.join('\n')}`));

        await interaction.deferReply({ flags: MessageFlags.Ephemeral });
        flightRepo.setup(guildId, {
          forceTag, ...input, channelId: channel.id, alertChannelId: alertCh?.id,
          scrambleRoleId: role.id, strict: interaction.options.getBoolean('strict') ?? false, addedBy: interaction.user.id,
        });
        const notes = [];
        if (!role.mentionable && !me.permissions?.has?.('MentionEveryone')) {
          notes.push(`⚠ <@&${role.id}> isn't mentionable and I lack "Mention Everyone", so scramble pings won't notify anyone. Make the role mentionable or grant me that permission.`);
        }
        let posted = 'Posted the first code.';
        try {
          await flightSvc.rotate(interaction.client, guildId);
        } catch (err) {
          posted = `Saved, but I couldn't post the first code (${err.message}). I'll keep retrying every few minutes.`;
        }
        return interaction.editReply(
          `Flight codes configured for **[${forceTag}]**: ${input.length} × ${input.charset === 'alnum' ? 'letters+numbers' : input.charset}, ` +
          `new code every ${input.intervalMinutes} min in <#${channel.id}>.\n${posted}` +
          (notes.length ? `\n${notes.join('\n')}` : ''));
      }

      const cfg = configRepo.get(guildId);
      if (sub === 'status') {
        if (!cfg.flightcode_enabled) return interaction.reply(ephemeral('Flight-code verification is **off**. Turn it on with `/aewc flightcode setup`.'));
        const rotated = toUnix(cfg.flightcode_rotated_at);
        return interaction.reply(ephemeral(
          `**Flight codes: on** for [${cfg.flightcode_force_tag}]\n` +
          `• Current code: \`${cfg.flightcode_current ?? '—'}\` (${cfg.flightcode_length} × ${cfg.flightcode_charset})\n` +
          `• Posted in <#${cfg.flightcode_channel_id}> · alerts in <#${cfg.flightcode_alert_channel_id || cfg.flightcode_channel_id}>\n` +
          `• Rotates every ${Math.round(cfg.flightcode_interval_s / 60)} min` +
          (rotated ? ` · last ${discordTs(cfg.flightcode_rotated_at)}, next <t:${rotated + cfg.flightcode_interval_s}:R>` : '') + '\n' +
          `• Scramble role: <@&${cfg.flightcode_scramble_role_id}> · strict mode: ${cfg.flightcode_strict ? 'on' : 'off'}\n` +
          `• Open alert throttles: ${flightRepo.countAlerts(guildId)}`));
      }
      if (sub === 'disable') {
        flightRepo.disable(guildId);
        return interaction.reply(ephemeral('Flight-code verification turned **off**. (Settings are kept; run setup again to turn it back on.)'));
      }
      if (sub === 'rotate') {
        if (!cfg.flightcode_enabled) return interaction.reply(ephemeral('Flight codes aren\'t set up — run `/aewc flightcode setup` first.'));
        await interaction.deferReply({ flags: MessageFlags.Ephemeral });
        try {
          await flightSvc.rotate(interaction.client, guildId);
          return interaction.editReply(`New flight code posted in <#${cfg.flightcode_channel_id}>. The previous code stays valid for 10 minutes.`);
        } catch (err) {
          return interaction.editReply(`Couldn't rotate: ${err.message}`);
        }
      }
      return;
    }

    // ---- /aewc setup ----
    if (sub === 'setup') {
      const picture = interaction.options.getChannel('picture_channel', true);
      const threat = interaction.options.getChannel('threat_log_channel', true);
      const patrol = interaction.options.getChannel('patrol_log_channel', true);
      const intelCh = interaction.options.getChannel('intel_channel');

      const me = interaction.guild.members.me;
      const problems = [];
      for (const ch of [picture, threat, patrol, intelCh].filter(Boolean)) {
        const perms = ch.permissionsFor(me);
        const missing = ['ViewChannel', 'SendMessages', 'EmbedLinks'].filter((f) => !perms?.has(f));
        if (missing.length) problems.push(`<#${ch.id}> — missing ${missing.join(', ')}`);
      }
      if (problems.length) {
        return interaction.reply(ephemeral(`I can't post in all of those channels yet:\n${problems.join('\n')}`));
      }

      await interaction.deferReply({ flags: MessageFlags.Ephemeral });
      configRepo.setChannels(guildId, { picture: picture.id, threatLog: threat.id, patrolLog: patrol.id, intel: intelCh?.id });
      await pictureSvc.refresh(interaction.client, guildId, { forceNew: true });
      return interaction.editReply(
        `Configured.\n• Picture: <#${picture.id}>\n• Threat log: <#${threat.id}>\n• Patrol log: <#${patrol.id}>\n• Intel: <#${(intelCh ?? threat).id}>` +
        (tagsRepo.list(guildId).length ? '' : '\n\nNo callsign tags yet — add some with `/aewc tags add` so presence detection knows what to look for.'));
    }

    // ---- /aewc config ----
    if (sub === 'config') {
      const changes = {};
      for (const key of Object.keys(configRepo.TUNABLES)) {
        const v = interaction.options.getInteger(key);
        if (v !== null) changes[key] = v;
      }
      const result = configRepo.setTunables(guildId, changes);
      if (result.error) return interaction.reply(ephemeral(result.error));
      const c = result.config;
      const head = Object.keys(changes).length ? 'Updated.\n' : '';
      return interaction.reply(ephemeral(
        `${head}**Current settings**\n` +
        `• Threat spawn interval: ${c.threat_spawn_min_s}–${c.threat_spawn_max_s}s\n` +
        `• Max simultaneous contacts: ${c.threat_population_cap}\n` +
        `• GeoFS poll interval: ${c.poll_interval_s}s\n` +
        `• Patrol grace period: ${c.patrol_grace_period_s}s`));
    }
  },
};
