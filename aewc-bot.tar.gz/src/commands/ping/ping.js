const { SlashCommandBuilder, MessageFlags } = require('discord.js');
const db = require('../../db');
const geofs = require('../../services/geofs');
const presence = require('../../loops/presencePoller');
const status = require('../../services/status');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ping')
    .setDescription('Pong! Bot status, latency to Discord, and latency from the server to GeoFS')
    .addBooleanOption((o) => o.setName('public').setDescription('Show the result to everyone (default: only you)')),

  async execute(interaction) {
    const pub = interaction.options.getBoolean('public') ?? false;

    // Deferring is a real round trip to Discord's REST API, so it doubles as the API latency measurement.
    const t0 = performance.now();
    await interaction.deferReply(pub ? {} : { flags: MessageFlags.Ephemeral });
    const apiMs = Math.round(performance.now() - t0);

    const geo = await geofs.measure(); // fresh unless GeoFS was hit in the last 10 s (it then reuses that)
    const embed = status.buildEmbed({
      gatewayMs: Math.round(interaction.client.ws?.ping ?? -1),
      apiMs, geo,
      poller: presence.status(),
      db: status.dbInfo(db),
      host: status.hostInfo(),
    });
    await interaction.editReply({ content: 'Pong!', embeds: [embed] });
  },
};

module.exports.access = { default: 'everyone' };
