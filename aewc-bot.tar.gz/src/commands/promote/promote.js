const { SlashCommandBuilder } = require('discord.js');
const { ephemeral } = require('../../util/reply');
const { isController, denyController } = require('../../util/permissions');
const { respondNames } = require('../../util/autocomplete');
const pilotsRepo = require('../../db/repos/pilots');
const ranksRepo = require('../../db/repos/ranks');
const orgRepo = require('../../db/repos/org');
const orgSvc = require('../../services/org');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('promote')
    .setDescription('Set a pilot\'s rank (swaps their rank roles)')
    .addUserOption((o) => o.setName('user').setDescription('The pilot').setRequired(true))
    .addStringOption((o) => o.setName('rank').setDescription('Rank from /ranks setup').setRequired(true).setAutocomplete(true)),

  async autocomplete(interaction) {
    await respondNames(interaction, ranksRepo.list(interaction.guildId).map((r) => r.name));
  },

  async execute(interaction) {
    if (!isController(interaction)) return denyController(interaction);
    const guildId = interaction.guildId;
    const user = interaction.options.getUser('user', true);
    const ladder = ranksRepo.list(guildId);
    if (!ladder.length) return interaction.reply(ephemeral('No ranks set up yet. An admin can run `/ranks setup`.'));

    const pilot = pilotsRepo.getByDiscord(guildId, user.id);
    if (!pilot) return interaction.reply(ephemeral(`<@${user.id}> isn't a registered pilot. Use \`/onboard\` first.`));
    const rank = ranksRepo.getByName(guildId, interaction.options.getString('rank', true));
    if (!rank) return interaction.reply(ephemeral(`No rank by that name. Ranks: ${ladder.map((r) => `\`${r.name}\``).join(', ')}`));

    await interaction.deferReply({ flags: 64 });
    const oldPos = ladder.findIndex((r) => r.name.toLowerCase() === (pilot.rank_name ?? '').toLowerCase());
    const newPos = ladder.findIndex((r) => r.name === rank.name);
    if (oldPos === newPos) return interaction.editReply(`<@${user.id}> is already **${rank.name}**.`);

    const before = orgRepo.seatSnapshot(guildId);
    pilotsRepo.setRank(guildId, user.id, rank.name);
    const a = orgRepo.assignmentOf(guildId, user.id);
    const report = await orgSvc.afterChange(interaction.client, interaction.guild, guildId, {
      before, extraPilots: [user.id], extraWings: a.wing ? [a.wing.id] : [],
    });
    const verb = oldPos === -1 ? 'Ranked' : newPos > oldPos ? 'Promoted' : 'Demoted';
    return interaction.editReply(
      `${verb} <@${user.id}> ${oldPos === -1 ? 'to' : `from **${pilot.rank_name}** to`} **${rank.name}**.` +
      (report.problems.length ? `\n⚠ Some roles couldn't be updated:\n${orgSvc.problemText(report.problems)}` : ''));
  },
};

// Who may run it (shown by /commands list). Keys are subcommand paths (longest prefix wins); enforced in execute().
module.exports.access = { default: 'controller' };
