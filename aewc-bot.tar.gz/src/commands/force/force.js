const { SlashCommandBuilder, ChannelType, EmbedBuilder } = require('discord.js');
const { ephemeral } = require('../../util/reply');
const { isAdmin, denyAdmin, isController, denyController } = require('../../util/permissions');
const { respondNames } = require('../../util/autocomplete');
const { normalizeCallsign } = require('../../util/callsign');
const orgRepo = require('../../db/repos/org');
const tagsRepo = require('../../db/repos/tags');
const orgSvc = require('../../services/org');
const orgChart = require('../../services/orgChart');

const NAME_RE = /^[A-Z0-9][A-Z0-9 _-]{0,29}$/;
const CALLSIGN_RE = /^[A-Z][A-Z0-9]{1,15}$/;
const normName = (raw) => { const n = normalizeCallsign(raw); return NAME_RE.test(n) ? n : null; };

const squadronOption = (o) => o.setName('squadron').setDescription('Squadron').setRequired(true).setAutocomplete(true);

function mentionWarning(me, role, what) {
  return role && !role.mentionable && !me.permissions?.has?.('MentionEveryone')
    ? `\n⚠ <@&${role.id}> isn't mentionable and I lack "Mention Everyone", so ${what} won't notify anyone.` : '';
}
const problems = (report) => (report.problems.length
  ? `\n⚠ Some roles couldn't be updated (check my **Manage Roles** permission and that my role is above them):\n${orgSvc.problemText(report.problems)}` : '');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('force')
    .setDescription('Organize the force: wings, squadrons and commanders')
    .addSubcommandGroup((g) =>
      g.setName('wings').setDescription('Wings')
        .addSubcommand((s) =>
          s.setName('create').setDescription('Create a wing')
            .addStringOption((o) => o.setName('wing_name').setDescription('Wing name, e.g. 1ST WING').setRequired(true))
            .addUserOption((o) => o.setName('wingcom').setDescription('Wing commander — takes callsign-2 of the first squadron nested in').setRequired(true))
            .addRoleOption((o) => o.setName('wing_role').setDescription('Role given to every member of the wing').setRequired(true))
            .addChannelOption((o) => o.setName('member_channel').setDescription('Where the callsign roster is posted (pings the wing role on changes)')
              .addChannelTypes(ChannelType.GuildText).setRequired(true))
            .addStringOption((o) => o.setName('force_tag').setDescription('Callsign tag for this wing, e.g. SAAF').setRequired(true))))
    .addSubcommandGroup((g) =>
      g.setName('squadrons').setDescription('Squadrons')
        .addSubcommand((s) =>
          s.setName('create').setDescription('Create a squadron with callsign slots 1..N')
            .addStringOption((o) => o.setName('squad_name').setDescription('Squadron name, e.g. LEOPARD SQUADRON').setRequired(true))
            .addStringOption((o) => o.setName('callsign').setDescription('Callsign, e.g. LEOPARD (slots become LEOPARD-1, LEOPARD-2, …)').setRequired(true))
            .addIntegerOption((o) => o.setName('pilots').setDescription('Number of pilots/slots').setMinValue(1).setMaxValue(40).setRequired(true))
            .addRoleOption((o) => o.setName('squadron_role').setDescription('Role given to every member of the squadron').setRequired(true))
            .addUserOption((o) => o.setName('squadcom').setDescription('Squadron commander — carries callsign-1 (optional)'))
            .addStringOption((o) => o.setName('parent_wing').setDescription('Wing to nest it in (optional)').setAutocomplete(true)))
        .addSubcommand((s) =>
          s.setName('nest').setDescription('Move a squadron into a wing')
            .addStringOption(squadronOption)
            .addStringOption((o) => o.setName('parent_wing').setDescription('Wing').setRequired(true).setAutocomplete(true)))
        .addSubcommand((s) =>
          s.setName('assign').setDescription('Put a pilot in a squadron (closest free callsign slot)')
            .addUserOption((o) => o.setName('pilot').setDescription('The pilot').setRequired(true))
            .addStringOption(squadronOption)))
    .addSubcommandGroup((g) =>
      g.setName('squadcom').setDescription('Squadron commanders')
        .addSubcommand((s) =>
          s.setName('assign').setDescription('Make a pilot the squadron commander (callsign-1)')
            .addUserOption((o) => o.setName('pilot').setDescription('The pilot').setRequired(true))
            .addStringOption(squadronOption)))
    .addSubcommandGroup((g) =>
      g.setName('wingcom').setDescription('Wing commanders')
        .addSubcommand((s) =>
          s.setName('assign').setDescription('Make a pilot the wing commander (callsign-2 of the first squadron)')
            .addUserOption((o) => o.setName('pilot').setDescription('The pilot').setRequired(true))
            .addStringOption((o) => o.setName('wing').setDescription('Wing').setRequired(true).setAutocomplete(true))))
    .addSubcommandGroup((g) =>
      g.setName('organization').setDescription('The force at a glance')
        .addSubcommand((s) =>
          s.setName('list').setDescription('Text chart of every wing and its squadrons')
            .addBooleanOption((o) => o.setName('show_pilots').setDescription('Also list every pilot and callsign (default: no)')))),

  async autocomplete(interaction) {
    const guildId = interaction.guildId;
    const focused = interaction.options.getFocused(true).name;
    if (focused === 'squadron') return respondNames(interaction, orgRepo.listSquadrons(guildId).map((s) => s.name));
    if (focused === 'wing' || focused === 'parent_wing') return respondNames(interaction, orgRepo.listWings(guildId).map((w) => w.name));
    return interaction.respond([]);
  },

  async execute(interaction) {
    const guildId = interaction.guildId;
    const group = interaction.options.getSubcommandGroup();
    const sub = interaction.options.getSubcommand();
    const o = interaction.options;
    const me = interaction.guild?.members?.me;

    const findSquadron = (key) => orgRepo.getSquadron(guildId, normalizeCallsign(o.getString(key, true)));
    const findWing = (key) => orgRepo.getWing(guildId, normalizeCallsign(o.getString(key, true)));
    const unknownSquadron = () => ephemeral(`No squadron by that name. Squadrons: ${orgRepo.listSquadrons(guildId).map((s) => `\`${s.name}\``).join(', ') || '_none yet_'}`);
    const unknownWing = () => ephemeral(`No wing by that name. Wings: ${orgRepo.listWings(guildId).map((w) => `\`${w.name}\``).join(', ') || '_none yet_'}`);

    // ================= organization list (open to everyone) =================
    if (group === 'organization') {
      const pages = orgChart.renderPages(guildId, { showPilots: o.getBoolean('show_pilots') ?? false });
      if (!pages.length) return interaction.reply(ephemeral('No wings or squadrons yet. Start with `/force wings create` and `/force squadrons create`.'));
      const embeds = pages.map((text, i) => {
        const e = new EmbedBuilder().setColor(0x3b7ddd).setDescription(text);
        if (i === 0) e.setTitle('Force organization');
        return e;
      });
      await interaction.reply({ embeds: embeds.slice(0, 10) });
      for (let i = 10; i < embeds.length; i += 10) await interaction.followUp({ embeds: embeds.slice(i, i + 10) });
      return;
    }

    // ================= wings create (admin) =================
    if (group === 'wings' && sub === 'create') {
      if (!isAdmin(interaction)) return denyAdmin(interaction);
      const name = normName(o.getString('wing_name', true));
      if (!name) return interaction.reply(ephemeral('Invalid wing name. Use up to 30 letters, digits, spaces, `-` or `_`.'));
      const tag = tagsRepo.normalize(o.getString('force_tag', true));
      if (!tag) return interaction.reply(ephemeral('Invalid force tag. Use 1–12 letters/digits.'));
      const channel = o.getChannel('member_channel', true); const role = o.getRole('wing_role', true); const wingcom = o.getUser('wingcom', true);
      if (wingcom.bot) return interaction.reply(ephemeral('A bot can\'t be wing commander.'));
      const perms = channel.permissionsFor(me);
      const missing = ['ViewChannel', 'SendMessages', 'EmbedLinks'].filter((f) => !perms?.has(f));
      if (missing.length) return interaction.reply(ephemeral(`I can't post in <#${channel.id}> yet — missing ${missing.join(', ')}.`));

      await interaction.deferReply({ flags: 64 });
      const before = orgRepo.seatSnapshot(guildId);
      const r = orgRepo.createWing(guildId, { name, forceTag: tag, roleId: role.id, channelId: channel.id, wingcomId: wingcom.id });
      if (r.error) return interaction.editReply(r.error);
      tagsRepo.add(guildId, tag, interaction.user.id, 'us'); // the wing's tag is one of OUR force tags
      const report = await orgSvc.afterChange(interaction.client, interaction.guild, guildId, { before, extraPilots: [wingcom.id] });
      return interaction.editReply(
        `Created wing **${name}** [${tag}] · role <@&${role.id}> · roster channel <#${channel.id}> · wingcom <@${wingcom.id}>.\n` +
        `The wingcom will take callsign-2 of the first squadron nested into the wing (\`/force squadrons create parent_wing:${name}\` or \`/force squadrons nest\`).` +
        mentionWarning(me, role, 'roster pings') + problems(report));
    }

    // ================= squadrons create (admin) =================
    if (group === 'squadrons' && sub === 'create') {
      if (!isAdmin(interaction)) return denyAdmin(interaction);
      const name = normName(o.getString('squad_name', true));
      if (!name) return interaction.reply(ephemeral('Invalid squadron name. Use up to 30 letters, digits, spaces, `-` or `_`.'));
      const callsign = normalizeCallsign(o.getString('callsign', true));
      if (!CALLSIGN_RE.test(callsign)) return interaction.reply(ephemeral('Invalid callsign. Use 2–16 letters/digits starting with a letter, no hyphen — e.g. `LEOPARD` (I add the -1, -2, … myself).'));
      const slots = o.getInteger('pilots', true); const role = o.getRole('squadron_role', true);
      const squadcom = o.getUser('squadcom');
      let wing = null;
      if (o.getString('parent_wing')) { wing = findWing('parent_wing'); if (!wing) return interaction.reply(unknownWing()); }

      await interaction.deferReply({ flags: 64 });
      const before = orgRepo.seatSnapshot(guildId);
      const r = orgRepo.createSquadron(guildId, { name, callsign, slots, roleId: role.id, wingId: wing?.id, squadcomId: squadcom?.id });
      if (r.error) return interaction.editReply(r.error);
      const report = await orgSvc.afterChange(interaction.client, interaction.guild, guildId, { before, extraPilots: squadcom ? [squadcom.id] : [], extraWings: wing ? [wing.id] : [] });
      const seated = wing?.wingcom_id ? orgRepo.assignmentOf(guildId, wing.wingcom_id) : null;
      return interaction.editReply(
        `Created **${name}** — callsigns ${callsign}-1 … ${callsign}-${slots} · role <@&${role.id}>` +
        (squadcom ? `\nSquadcom <@${squadcom.id}> → **${orgRepo.assignmentOf(guildId, squadcom.id).callsign}**` : '') +
        (wing ? `\nNested in **${wing.name}** [${wing.force_tag}].` : '') +
        (seated?.squadron?.id === r.squadron.id ? `\nWingcom <@${wing.wingcom_id}> → **${seated.callsign}**` : '') +
        mentionWarning(me, role, 'role pings') + problems(report));
    }

    // ================= squadrons nest (admin) =================
    if (group === 'squadrons' && sub === 'nest') {
      if (!isAdmin(interaction)) return denyAdmin(interaction);
      const squadron = findSquadron('squadron'); if (!squadron) return interaction.reply(unknownSquadron());
      const wing = findWing('parent_wing'); if (!wing) return interaction.reply(unknownWing());
      await interaction.deferReply({ flags: 64 });
      const before = orgRepo.seatSnapshot(guildId);
      const r = orgRepo.nestSquadron(guildId, squadron.id, wing.id);
      if (r.error) return interaction.editReply(r.error);
      const members = [...orgRepo.slotsOf(squadron.id).values()];
      const report = await orgSvc.afterChange(interaction.client, interaction.guild, guildId, {
        before, extraPilots: members, extraWings: [wing.id, ...(r.oldWing ? [r.oldWing.id] : [])],
      });
      const wc = wing.wingcom_id ? orgRepo.assignmentOf(guildId, wing.wingcom_id) : null;
      return interaction.editReply(
        `Nested **${squadron.name}** in **${wing.name}** [${wing.force_tag}]${r.oldWing ? ` (was in ${r.oldWing.name})` : ''}. ` +
        `${members.length} pilot(s) now carry the ${wing.name} role and [${wing.force_tag}] callsigns.` +
        (wc?.callsign ? `\nWingcom <@${wing.wingcom_id}> → **${wc.callsign}**` : '') + problems(report));
    }

    // ================= assignments (controller) =================
    if (group === 'squadrons' && sub === 'assign') {
      if (!isController(interaction)) return denyController(interaction);
      const squadron = findSquadron('squadron'); if (!squadron) return interaction.reply(unknownSquadron());
      const pilot = o.getUser('pilot', true);
      await interaction.deferReply({ flags: 64 });
      const before = orgRepo.seatSnapshot(guildId);
      const r = orgRepo.assignPilot(guildId, squadron.id, pilot.id);
      if (r.error) return interaction.editReply(r.error);
      const a = orgRepo.assignmentOf(guildId, pilot.id);
      if (!r.changed) return interaction.editReply(`<@${pilot.id}> is already in ${squadron.name} as **${a.callsign}**.`);
      const report = await orgSvc.afterChange(interaction.client, interaction.guild, guildId, { before, extraPilots: [pilot.id] });
      return interaction.editReply(`Assigned <@${pilot.id}> to **${a.callsign}** (${squadron.name})` + (r.from ? ` — moved from ${r.from.name}` : '') + '.' + problems(report));
    }

    if (group === 'squadcom' && sub === 'assign') {
      if (!isController(interaction)) return denyController(interaction);
      const squadron = findSquadron('squadron'); if (!squadron) return interaction.reply(unknownSquadron());
      const pilot = o.getUser('pilot', true);
      await interaction.deferReply({ flags: 64 });
      const before = orgRepo.seatSnapshot(guildId);
      const r = orgRepo.assignSquadcom(guildId, squadron.id, pilot.id);
      if (r.error) return interaction.editReply(r.error);
      const report = await orgSvc.afterChange(interaction.client, interaction.guild, guildId, { before, extraPilots: [pilot.id, ...(r.previous ? [r.previous] : [])] });
      return interaction.editReply(
        `<@${pilot.id}> is now squadron commander of **${squadron.name}** → **${orgRepo.assignmentOf(guildId, pilot.id).callsign}**.` +
        (r.previous ? `\nPrevious commander <@${r.previous}> is now **${orgRepo.assignmentOf(guildId, r.previous).callsign}**.` : '') + problems(report));
    }

    if (group === 'wingcom' && sub === 'assign') {
      if (!isController(interaction)) return denyController(interaction);
      const wing = findWing('wing'); if (!wing) return interaction.reply(unknownWing());
      const pilot = o.getUser('pilot', true);
      await interaction.deferReply({ flags: 64 });
      const before = orgRepo.seatSnapshot(guildId);
      const r = orgRepo.assignWingcom(guildId, wing.id, pilot.id);
      if (r.error) return interaction.editReply(r.error);
      const report = await orgSvc.afterChange(interaction.client, interaction.guild, guildId, { before, extraPilots: [pilot.id, ...(r.previous ? [r.previous] : [])], extraWings: [wing.id] });
      const a = orgRepo.assignmentOf(guildId, pilot.id);
      return interaction.editReply(
        `<@${pilot.id}> is now wing commander of **${wing.name}**` +
        (a.commandsWing && a.callsign ? ` → **${a.callsign}**.` : `. They'll take callsign-2 of the wing's first squadron as soon as one is nested in.`) +
        (r.previous ? `\nPrevious wingcom <@${r.previous}> is now ${orgRepo.assignmentOf(guildId, r.previous).callsign ?? 'unseated'}.` : '') + problems(report));
    }
  },
};
