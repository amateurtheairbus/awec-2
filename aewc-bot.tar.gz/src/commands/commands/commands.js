const { SlashCommandBuilder, EmbedBuilder, MessageFlags } = require('discord.js');
const { ephemeral } = require('../../util/reply');
const { respondNames } = require('../../util/autocomplete');
const commandList = require('../../services/commandList');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('commands')
    .setDescription('See everything this bot can do')
    .addSubcommand((s) =>
      s.setName('list').setDescription('List every command, its options, and who can use it')
        .addStringOption((o) => o.setName('command').setDescription('Only show this command (e.g. force)').setAutocomplete(true))),

  async autocomplete(interaction) {
    await respondNames(interaction, [...interaction.client.commands.keys()].sort());
  },

  async execute(interaction) {
    const mods = [...interaction.client.commands.values()];
    const wanted = interaction.options.getString('command')?.trim().replace(/^\//, '').toLowerCase() || null;
    if (wanted && !mods.some((m) => m.data.name === wanted)) {
      return interaction.reply(ephemeral(`No command called \`/${wanted}\`. Commands: ${mods.map((m) => `\`${m.data.name}\``).sort().join(', ')}`));
    }

    await interaction.deferReply({ flags: MessageFlags.Ephemeral }); // asking Discord for command IDs can take a moment
    const { ids, reached } = await commandList.fetchCommandIds(interaction.client, interaction.guildId);
    const { lines, count, stale } = commandList.renderLines(mods, { ids, reached, only: wanted });

    const pages = commandList.renderPages(lines);
    const embeds = pages.map((text, i) => {
      const e = new EmbedBuilder().setColor(0x3b7ddd).setDescription(text);
      if (i === 0) e.setTitle(wanted ? `/${wanted}` : `Commands — ${mods.length} commands, ${count} subcommands`);
      if (i === pages.length - 1) {
        e.setFooter({ text: 'Role tags show what a command requires; everything without one is open to everyone.' +
          (stale.length ? ` Registered in Discord but no longer in the bot: ${stale.join(', ')}.` : '') });
      }
      return e;
    });
    await interaction.editReply({ embeds: embeds.slice(0, 10) });
    for (let i = 10; i < embeds.length; i += 10) await interaction.followUp({ embeds: embeds.slice(i, i + 10), flags: MessageFlags.Ephemeral });
  },
};

module.exports.access = { default: 'everyone' };
