const { SlashCommandBuilder } = require('discord.js');
const { EmbedBuilder, MessageFlags } = require('discord.js');
const { ephemeral } = require('../../util/reply');
const { discordTs } = require('../../util/time');
const { fitLines } = require('../../services/format');
const ops = require('../../services/ops');
const intel = require('../../db/repos/intel');
const events = require('../../db/repos/events');
const { isController, denyController } = require('../../util/permissions');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('intel')
    .setDescription('Manage the intelligence watchlist')
    .addSubcommand((sub) =>
      sub
        .setName('add')
        .setDescription('Add a GeoFS ID to the watchlist')
        .addStringOption((opt) => opt.setName('geofs_id').setDescription('GeoFS player ID').setRequired(true))
        .addStringOption((opt) => opt.setName('notes').setDescription('Why this contact is flagged').setRequired(false))
        .addBooleanOption((opt) => opt.setName('alert_on_sighting').setDescription('Alert when this ID appears online (default: yes)').setRequired(false))
    )
    .addSubcommand((sub) =>
      sub
        .setName('remove')
        .setDescription('Remove a GeoFS ID from the watchlist')
        .addStringOption((opt) => opt.setName('geofs_id').setDescription('GeoFS player ID').setRequired(true))
    )
    .addSubcommand((sub) =>
      sub.setName('list').setDescription('List all watchlist entries')
    )
    .addSubcommand((sub) =>
      sub
        .setName('lookup')
        .setDescription('Full detail on one watchlist entry')
        .addStringOption((opt) => opt.setName('geofs_id').setDescription('GeoFS player ID').setRequired(true))
    )
    .addSubcommand((sub) =>
      sub
        .setName('alerts')
        .setDescription('Toggle sighting alerts for a watchlist entry')
        .addStringOption((opt) => opt.setName('geofs_id').setDescription('GeoFS player ID').setRequired(true))
        .addBooleanOption((opt) => opt.setName('on').setDescription('Enable alerts?').setRequired(true))
    ),

  async execute(interaction) {
    if (!isController(interaction)) return denyController(interaction);

    const guildId = interaction.guildId;
    const sub = interaction.options.getSubcommand();
    const rawId = interaction.options.getString('geofs_id')?.trim();
    if (rawId !== undefined && !/^\d{1,12}$/.test(rawId)) {
      return interaction.reply(ephemeral('GeoFS IDs are numeric account IDs — double-check it and try again.'));
    }

    if (sub === 'add') {
      await interaction.deferReply({ flags: MessageFlags.Ephemeral });
      const { entry, created } = await ops.addIntel(interaction.client, guildId, rawId, {
        notes: interaction.options.getString('notes') ?? undefined,
        alertOnSighting: interaction.options.getBoolean('alert_on_sighting') ?? undefined,
        actorId: interaction.user.id,
      });
      return interaction.editReply(`${created ? 'Added' : 'Updated'} \`${entry.geofs_id}\` — alerts ${entry.alert_on_sighting ? 'on' : 'off'}.`);
    }

    if (sub === 'remove') {
      await interaction.deferReply({ flags: MessageFlags.Ephemeral });
      const res = await ops.removeIntel(interaction.client, guildId, rawId, { actorId: interaction.user.id });
      return interaction.editReply(res.error ?? `Removed \`${rawId}\` from the watchlist.`);
    }

    if (sub === 'list') {
      const rows = intel.list(guildId);
      if (!rows.length) return interaction.reply(ephemeral('The watchlist is empty.'));
      const lines = rows.map((r) =>
        `\`${r.geofs_id}\` ${r.alert_on_sighting ? '🔔' : '🔕'} ${r.notes ? `— ${r.notes}` : ''}` +
        `${r.last_seen_at ? `\n　last seen ${discordTs(r.last_seen_at)} as **${r.last_seen_callsign}**` : ''}`);
      return interaction.reply({
        embeds: [new EmbedBuilder().setTitle(`Intel watchlist (${rows.length})`).setDescription(fitLines(lines, 4000)).setColor(0x6a4fc4)],
        flags: MessageFlags.Ephemeral,
      });
    }

    if (sub === 'lookup') {
      const entry = intel.get(guildId, rawId);
      if (!entry) return interaction.reply(ephemeral(`\`${rawId}\` is not on the watchlist.`));
      const sightings = events.forRef(guildId, 'intel_sighting', rawId, 5).map((e) => {
        let d = {}; try { d = JSON.parse(e.detail ?? '{}'); } catch { /* ignore malformed detail */ }
        return `${discordTs(e.created_at)} — **${d.callsign ?? 'unknown callsign'}**`;
      });
      const embed = new EmbedBuilder()
        .setTitle(`Intel: ${entry.geofs_id}`)
        .setColor(0x6a4fc4)
        .addFields(
          { name: 'Notes', value: entry.notes || '_None_' },
          { name: 'Sighting alerts', value: entry.alert_on_sighting ? 'On' : 'Off', inline: true },
          { name: 'Flagged', value: `${discordTs(entry.flagged_at, 'D')} by <@${entry.flagged_by}>`, inline: true },
          { name: 'Last seen', value: entry.last_seen_at ? `${discordTs(entry.last_seen_at)} as **${entry.last_seen_callsign}**` : '_Never_' },
          { name: 'Recent sightings', value: sightings.join('\n') || '_None logged_' },
        );
      return interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
    }

    if (sub === 'alerts') {
      const on = interaction.options.getBoolean('on', true);
      const ok = intel.setAlert(guildId, rawId, on);
      return interaction.reply(ephemeral(ok ? `Alerts for \`${rawId}\` turned ${on ? 'on' : 'off'}.` : `\`${rawId}\` is not on the watchlist.`));
    }
  },
};
