const { SlashCommandBuilder } = require('discord.js');
const { EmbedBuilder, MessageFlags } = require('discord.js');
const { isAdmin, denyAdmin } = require('../../util/permissions');
const { ephemeral } = require('../../util/reply');
const { discordTs } = require('../../util/time');
const { patrolLine, fitLines } = require('../../services/format');
const { unitText } = require('../../services/ops');
const pilots = require('../../db/repos/pilots');
const patrols = require('../../db/repos/patrols');
const { ADMIN_DEFAULT_PERMISSIONS } = require('../../util/constants');

// NOTE: register/remove are gated to admins at execute-time (not via
// setDefaultMemberPermissions) because list/lookup on this same command must
// stay open to everyone — Discord's default-permission gate applies to the
// whole command, not per-subcommand.
module.exports = {
  data: new SlashCommandBuilder()
    .setName('pilot')
    .setDescription('Manage the registered pilot roster')
    .addSubcommand((sub) =>
      sub
        .setName('register')
        .setDescription('[Admin] Register a pilot\'s GeoFS ID')
        .addUserOption((opt) => opt.setName('discord_user').setDescription('Discord user').setRequired(true))
        .addStringOption((opt) => opt.setName('geofs_id').setDescription('GeoFS player ID').setRequired(true))
    )
    .addSubcommand((sub) =>
      sub
        .setName('remove')
        .setDescription('[Admin] Remove a pilot from the roster')
        .addUserOption((opt) => opt.setName('discord_user').setDescription('Discord user').setRequired(true))
    )
    .addSubcommand((sub) =>
      sub.setName('list').setDescription('List all registered pilots')
    )
    .addSubcommand((sub) =>
      sub
        .setName('lookup')
        .setDescription('Look up a pilot\'s record')
        .addUserOption((opt) => opt.setName('discord_user').setDescription('Discord user').setRequired(false))
        .addStringOption((opt) => opt.setName('geofs_id').setDescription('GeoFS player ID').setRequired(false))
    ),

  async execute(interaction) {
    const guildId = interaction.guildId;
    const sub = interaction.options.getSubcommand();

    if (['register', 'remove'].includes(sub) && !isAdmin(interaction)) return denyAdmin(interaction);

    if (sub === 'register') {
      const user = interaction.options.getUser('discord_user', true);
      if (user.bot) return interaction.reply(ephemeral('Bots can\'t be registered as pilots.'));
      const geofsId = interaction.options.getString('geofs_id', true).trim();
      if (!/^\d{1,12}$/.test(geofsId)) {
        return interaction.reply(ephemeral('GeoFS IDs are numeric account IDs — double-check it and try again.'));
      }
      const result = pilots.register(interaction.guildId, user.id, geofsId, interaction.user.id);
      if (result.error) return interaction.reply(ephemeral(result.error));
      return interaction.reply(ephemeral(`Registered <@${user.id}> with GeoFS ID \`${geofsId}\`.`));
    }

    if (sub === 'remove') {
      const user = interaction.options.getUser('discord_user', true);
      const removed = pilots.remove(guildId, user.id);
      return interaction.reply(ephemeral(removed ? `Removed <@${user.id}> from the roster.` : `<@${user.id}> isn't on the roster.`));
    }

    if (sub === 'list') {
      const rows = pilots.list(guildId);
      if (!rows.length) return interaction.reply(ephemeral('No pilots registered yet.'));
      const lines = rows.map((p) => `<@${p.discord_id}> — GeoFS \`${p.geofs_id}\``);
      return interaction.reply({
        embeds: [new EmbedBuilder().setTitle(`Pilot roster (${rows.length})`).setDescription(fitLines(lines, 4000)).setColor(0x3b7ddd)],
        flags: MessageFlags.Ephemeral,
      });
    }

    if (sub === 'lookup') {
      const user = interaction.options.getUser('discord_user');
      const geofsId = interaction.options.getString('geofs_id');
      const pilot = geofsId
        ? pilots.getByGeofs(guildId, geofsId.trim())
        : pilots.getByDiscord(guildId, (user ?? interaction.user).id);
      if (!pilot) return interaction.reply(ephemeral('No registered pilot found for that lookup.'));

      const open = patrols.getOpenForUser(guildId, pilot.discord_id);
      const last = patrols.history(guildId, pilot.discord_id, 1)[0];
      const embed = new EmbedBuilder()
        .setTitle('Pilot record')
        .setColor(0x3b7ddd)
        .addFields(
          { name: 'Discord', value: `<@${pilot.discord_id}>`, inline: true },
          { name: 'GeoFS ID', value: `\`${pilot.geofs_id}\``, inline: true },
          { name: 'Registered', value: `${discordTs(pilot.registered_at, 'D')} by <@${pilot.registered_by}>`, inline: true },
          { name: 'Total patrols', value: String(patrols.countForUser(guildId, pilot.discord_id)), inline: true },
          { name: 'Current patrol', value: open ? patrolLine(open) : '_None_' },
          { name: 'Last known unit', value: last ? unitText(last) : '_No patrols yet_', inline: true },
        );
      return interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
    }
  },
};
