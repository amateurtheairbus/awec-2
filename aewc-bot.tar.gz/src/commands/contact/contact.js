const { SlashCommandBuilder } = require('discord.js');
const { MessageFlags } = require('discord.js');
const { ephemeral } = require('../../util/reply');
const { contactLine, fitLines } = require('../../services/format');
const ops = require('../../services/ops');
const contacts = require('../../db/repos/contacts');
const { isController, denyController } = require('../../util/permissions');
const { IFF, CLASSIFICATION } = require('../../util/constants');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('contact')
    .setDescription('Manage simulated radar contacts')
    .addSubcommand((sub) =>
      sub
        .setName('spawn')
        .setDescription('[Controller] Manually inject a contact')
        .addStringOption((opt) =>
          opt.setName('iff').setDescription('IFF status (random if omitted)')
            .addChoices(...Object.values(IFF).map((v) => ({ name: v, value: v }))))
        .addStringOption((opt) =>
          opt.setName('classification').setDescription('Classification (random if omitted)')
            .addChoices(...Object.values(CLASSIFICATION).map((v) => ({ name: v, value: v }))))
    )
    .addSubcommand((sub) =>
      sub
        .setName('clear')
        .setDescription('[Controller] Manually fade/remove a contact')
        .addIntegerOption((opt) => opt.setName('id').setDescription('Contact ID').setRequired(true))
    )
    .addSubcommand((sub) => sub.setName('list').setDescription('List all active contacts')),

  async execute(interaction) {
    const guildId = interaction.guildId;
    const sub = interaction.options.getSubcommand();

    if (['spawn', 'clear'].includes(sub) && !isController(interaction)) return denyController(interaction);

    if (sub === 'spawn') {
      await interaction.deferReply({ flags: MessageFlags.Ephemeral });
      const contact = await ops.spawnContact(interaction.client, guildId, {
        iff: interaction.options.getString('iff') ?? undefined,
        classification: interaction.options.getString('classification') ?? undefined,
        actorId: interaction.user.id,
      });
      return interaction.editReply(`Injected contact #${contact.id} (**${contact.callsign}**).`);
    }

    if (sub === 'clear') {
      const contact = contacts.get(interaction.options.getInteger('id', true));
      if (!contact || contact.guild_id !== guildId) return interaction.reply(ephemeral('No contact with that ID.'));
      await interaction.deferReply({ flags: MessageFlags.Ephemeral });
      const res = await ops.fadeContact(interaction.client, guildId, contact, { actorId: interaction.user.id, reason: 'Cleared by controller' });
      return interaction.editReply(res.error ?? `Cleared contact #${contact.id} (**${contact.callsign}**).`);
    }

    if (sub === 'list') {
      const rows = contacts.listActive(guildId);
      return interaction.reply(ephemeral(rows.length ? fitLines(rows.map(contactLine), 1900) : 'Airspace clear — no active contacts.'));
    }
  },
};
