const { SlashCommandBuilder } = require('discord.js');
const { ephemeral } = require('../../util/reply');
const { isController, denyController } = require('../../util/permissions');
const tagsRepo = require('../../db/repos/tags');
const configRepo = require('../../db/repos/config');
const { TAG_CATEGORY } = require('../../util/constants');

const MAX_TAGS_PER_CALL = 20;
const withTagsOption = (sub) => sub.addStringOption((o) =>
  o.setName('tags').setDescription('One or more tags, separated by commas or spaces — e.g. SAAF or SAAF, UAEAF').setRequired(true));

const LABEL = {
  [TAG_CATEGORY.US]: 'US (our force — registered pilots get auto-patrols)',
  [TAG_CATEGORY.FRIENDLY]: 'FRIENDLY (shown on the picture, never scrambled)',
  [TAG_CATEGORY.HOSTILE]: 'HOSTILE (scramble when seen)',
};

// "SAAF, [uaeaf]  USAF" -> { valid: ['SAAF','UAEAF','USAF'], invalid: [...] }  (deduplicated, brackets/case ignored)
function parseTagList(raw) {
  const valid = []; const invalid = [];
  for (const piece of String(raw).split(/[\s,;]+/).filter(Boolean)) {
    const t = tagsRepo.normalize(piece);
    if (!t) invalid.push(piece);
    else if (!valid.includes(t)) valid.push(t);
  }
  return { valid, invalid };
}
const fmt = (tags) => tags.map((t) => `\`[${t}]\``).join(' ');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('tags')
    .setDescription('Manage which callsign tags are ours, friendly, or hostile')
    .addSubcommandGroup((g) =>
      g.setName('add').setDescription('Add callsign tags')
        .addSubcommand((s) => withTagsOption(s.setName('us').setDescription('Tag(s) of YOUR force — registered pilots get auto-patrols')))
        .addSubcommand((s) => withTagsOption(s.setName('friendly').setDescription('Friendly forces — shown on the picture, never scrambled')))
        .addSubcommand((s) => withTagsOption(s.setName('hostile').setDescription('Hostile forces — a pilot seen with one of these triggers a scramble'))))
    .addSubcommand((s) => withTagsOption(s.setName('remove').setDescription('Stop recognizing tag(s)')))
    .addSubcommand((s) => s.setName('list').setDescription('Show all recognized tags by category')),

  async execute(interaction) {
    const guildId = interaction.guildId;
    const sub = interaction.options.getSubcommand();
    const group = interaction.options.getSubcommandGroup(false);

    if (sub === 'list') {
      const by = tagsRepo.listByCategory(guildId);
      const lines = [TAG_CATEGORY.US, TAG_CATEGORY.FRIENDLY, TAG_CATEGORY.HOSTILE]
        .map((c) => `**${LABEL[c]}**\n${by[c].length ? fmt(by[c]) : '_none_'}`);
      return interaction.reply(ephemeral(lines.join('\n\n')));
    }

    if (!isController(interaction)) return denyController(interaction);

    const { valid, invalid } = parseTagList(interaction.options.getString('tags', true));
    if (!valid.length) return interaction.reply(ephemeral('No valid tags found. Use 1–12 letters/digits (brackets optional), separated by commas or spaces.'));
    if (valid.length > MAX_TAGS_PER_CALL) return interaction.reply(ephemeral(`Too many tags at once (max ${MAX_TAGS_PER_CALL}).`));

    const lines = [];
    if (group === 'add') {
      const category = sub; // us | friendly | hostile
      const added = []; const moved = []; const unchanged = [];
      for (const tag of valid) {
        const r = tagsRepo.add(guildId, tag, interaction.user.id, category);
        if (r.status === 'added') added.push(tag);
        else if (r.status === 'moved') moved.push(`\`[${tag}]\` (was ${r.from})`);
        else unchanged.push(tag);
      }
      if (added.length) lines.push(`Added to **${category}**: ${fmt(added)}`);
      if (moved.length) lines.push(`Moved to **${category}**: ${moved.join(', ')}`);
      if (unchanged.length) lines.push(`Already **${category}**: ${fmt(unchanged)}`);
      if (category === TAG_CATEGORY.HOSTILE && !configRepo.get(guildId).scramble_role_id) {
        lines.push('⚠ No scramble role is set, so hostile sightings will be posted but nobody will be pinged. Set one with `/aewc setup scramble_role:@role`.');
      }
    } else if (sub === 'remove') {
      const removed = valid.filter((t) => tagsRepo.remove(guildId, t));
      const missing = valid.filter((t) => !removed.includes(t));
      if (removed.length) lines.push(`Removed: ${fmt(removed)}`);
      if (missing.length) lines.push(`Not in the list: ${fmt(missing)}`);
    }
    if (invalid.length) lines.push(`Ignored (not a valid tag): ${invalid.map((t) => `\`${t}\``).join(' ')}`);
    return interaction.reply(ephemeral(lines.join('\n')));
  },
};
