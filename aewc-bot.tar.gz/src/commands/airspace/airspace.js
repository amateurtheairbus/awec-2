const { SlashCommandBuilder } = require('discord.js');
const { MessageFlags } = require('discord.js');
const picture = require('../../services/picture');
const { isController, denyController } = require('../../util/permissions');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('airspace')
    .setDescription('View the current airspace picture')
    .addSubcommand((sub) =>
      sub.setName('status').setDescription('On-demand snapshot of contacts + active patrols')
    )
    .addSubcommand((sub) =>
      sub.setName('refresh').setDescription('[Controller] Force-regenerate the live picture message')
    ),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();

    if (sub === 'status') {
      return interaction.reply({ embeds: [picture.buildEmbed(interaction.guildId)] });
    }

    if (sub === 'refresh') {
      if (!isController(interaction)) return denyController(interaction);
      await interaction.deferReply({ flags: MessageFlags.Ephemeral });
      const ok = await picture.refresh(interaction.client, interaction.guildId, { forceNew: true });
      return interaction.editReply(ok ? 'Live picture regenerated.' : 'Couldn\'t update the picture — run `/aewc setup` first, and make sure I can post in the picture channel.');
    }
  },
};
