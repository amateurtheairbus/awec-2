const { SlashCommandBuilder } = require('discord.js');
const { EmbedBuilder, MessageFlags } = require('discord.js');
const { ephemeral } = require('../../util/reply');
const { discordTs, toUnix } = require('../../util/time');
const { patrolLine, fitLines } = require('../../services/format');
const ops = require('../../services/ops');
const patrols = require('../../db/repos/patrols');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('patrol')
    .setDescription('Manage your patrol status')
    .addSubcommand((sub) =>
      sub
        .setName('start')
        .setDescription('Start a patrol')
        .addStringOption((opt) => opt.setName('aircraft').setDescription('Aircraft/callsign').setRequired(true))
    )
    .addSubcommand((sub) => sub.setName('rtb').setDescription('Mark your active patrol as RTB'))
    .addSubcommand((sub) => sub.setName('end').setDescription('End your active patrol'))
    .addSubcommand((sub) => sub.setName('status').setDescription('Show your current patrol status'))
    .addSubcommand((sub) => sub.setName('list').setDescription('List all currently active patrols'))
    .addSubcommand((sub) =>
      sub
        .setName('history')
        .setDescription('Show past patrols for a pilot')
        .addUserOption((opt) => opt.setName('discord_user').setDescription('Defaults to yourself').setRequired(false))
    ),

  async execute(interaction) {
    const guildId = interaction.guildId;
    const client = interaction.client;
    const sub = interaction.options.getSubcommand();
    const me = interaction.user.id;

    if (sub === 'start') {
      await interaction.deferReply({ flags: MessageFlags.Ephemeral });
      const res = await ops.startPatrol(client, guildId, {
        discordId: me, aircraft: interaction.options.getString('aircraft', true).slice(0, 60),
      });
      return interaction.editReply(res.error ?? `Patrol \`#${res.patrol.id}\` started — **${ops.unitText(res.patrol)}**.`);
    }

    if (sub === 'rtb' || sub === 'end') {
      const open = patrols.getOpenForUser(guildId, me);
      if (!open) return interaction.reply(ephemeral('You have no open patrol.'));
      await interaction.deferReply({ flags: MessageFlags.Ephemeral });
      const res = sub === 'rtb' ? await ops.rtbPatrol(client, guildId, open) : await ops.endPatrol(client, guildId, open);
      return interaction.editReply(res.error ?? (sub === 'rtb' ? `Patrol \`#${open.id}\` marked RTB.` : `Patrol \`#${open.id}\` ended.`));
    }

    if (sub === 'status') {
      const open = patrols.getOpenForUser(guildId, me);
      return interaction.reply(ephemeral(open ? `Patrol \`#${open.id}\`: ${patrolLine(open)}` : 'You have no open patrol.'));
    }

    if (sub === 'list') {
      const rows = patrols.listOpen(guildId);
      if (!rows.length) return interaction.reply(ephemeral('No patrols on station.'));
      return interaction.reply({
        embeds: [new EmbedBuilder().setTitle(`Patrols on station (${rows.length})`).setColor(0x2e8b57)
          .setDescription(fitLines(rows.map(patrolLine), 4000))],
        flags: MessageFlags.Ephemeral,
      });
    }

    if (sub === 'history') {
      const target = interaction.options.getUser('discord_user') ?? interaction.user;
      const rows = patrols.history(guildId, target.id, 10);
      if (!rows.length) return interaction.reply(ephemeral(`No patrol history for <@${target.id}>.`));
      const lines = rows.map((p) => {
        const dur = p.ended_at ? ` · ${formatDuration(toUnix(p.ended_at) - toUnix(p.started_at))}` : '';
        return `\`#${p.id}\` ${ops.unitText(p)} · ${p.status}${p.auto_started ? ' · auto' : ''} · ${discordTs(p.started_at, 'f')}${dur}`;
      });
      return interaction.reply({
        embeds: [new EmbedBuilder().setTitle('Patrol history').setColor(0x2e8b57)
          .setDescription(`<@${target.id}> — ${patrols.countForUser(guildId, target.id)} total\n\n${fitLines(lines, 3800)}`)],
        flags: MessageFlags.Ephemeral,
      });
    }
  },
};

function formatDuration(totalSeconds) {
  const s = Math.max(0, totalSeconds);
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  return h ? `${h}h ${m}m` : `${m}m`;
}
