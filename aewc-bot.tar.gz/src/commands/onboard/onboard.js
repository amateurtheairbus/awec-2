const { SlashCommandBuilder } = require('discord.js');
const { ephemeral } = require('../../util/reply');
const { isController, denyController } = require('../../util/permissions');
const { respondNames } = require('../../util/autocomplete');
const { normalizeCallsign } = require('../../util/callsign');
const orgRepo = require('../../db/repos/org');
const ranksRepo = require('../../db/repos/ranks');
const pilotsRepo = require('../../db/repos/pilots');
const orgSvc = require('../../services/org');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('onboard')
    .setDescription('Register a pilot, put them in a squadron, and give them their roles')
    .addUserOption((o) => o.setName('user').setDescription('The new pilot').setRequired(true))
    .addStringOption((o) => o.setName('squadron').setDescription('Squadron to join').setRequired(true).setAutocomplete(true))
    .addStringOption((o) => o.setName('geofs_id').setDescription('Their GeoFS account ID (needed unless they are already registered)')),

  async autocomplete(interaction) {
    await respondNames(interaction, orgRepo.listSquadrons(interaction.guildId).map((s) => s.name));
  },

  async execute(interaction) {
    if (!isController(interaction)) return denyController(interaction);
    const guildId = interaction.guildId;
    const user = interaction.options.getUser('user', true);
    if (user.bot) return interaction.reply(ephemeral('Bots can\'t be onboarded.'));

    const squadron = orgRepo.getSquadron(guildId, normalizeCallsign(interaction.options.getString('squadron', true)));
    if (!squadron) {
      const names = orgRepo.listSquadrons(guildId).map((s) => `\`${s.name}\``).join(', ');
      return interaction.reply(ephemeral(`No squadron by that name.${names ? ` Squadrons: ${names}` : ' Create one with `/force squadrons create`.'}`));
    }
    const geofsId = interaction.options.getString('geofs_id')?.trim() || null;
    if (geofsId && !/^\d{1,12}$/.test(geofsId)) return interaction.reply(ephemeral('GeoFS IDs are numeric account IDs — double-check it and try again.'));
    if (!geofsId && !pilotsRepo.getByDiscord(guildId, user.id)) {
      return interaction.reply(ephemeral(`<@${user.id}> isn't registered yet — add their \`geofs_id\` so I can register them.`));
    }

    await interaction.deferReply({ flags: 64 });
    const ladder = ranksRepo.list(guildId);
    const before = orgRepo.seatSnapshot(guildId);
    const r = orgRepo.onboardPilot(guildId, { discordId: user.id, geofsId, squadronId: squadron.id, actorId: interaction.user.id, startingRank: ladder[0]?.name });
    if (r.error) return interaction.editReply(r.error);

    const report = await orgSvc.afterChange(interaction.client, interaction.guild, guildId, { before, extraPilots: [user.id] });
    const a = orgRepo.assignmentOf(guildId, user.id);
    const pilot = pilotsRepo.getByDiscord(guildId, user.id);
    return interaction.editReply(
      `Onboarded <@${user.id}> as **${a.callsign}** in ${squadron.name} · GeoFS ID \`${pilot.geofs_id}\`` +
      (pilot.rank_name ? ` · rank **${pilot.rank_name}**` : '') +
      (r.from ? `\n(moved from ${r.from.name})` : '') +
      (ladder.length ? '' : '\nNo ranks are set up yet, so no enlisted/rank roles were given — see `/ranks setup`.') +
      (report.problems.length ? `\n⚠ Some roles couldn't be updated (check my **Manage Roles** permission and that my role is above them):\n${orgSvc.problemText(report.problems)}` : ''));
  },
};

// Who may run it (shown by /commands list). Keys are subcommand paths (longest prefix wins); enforced in execute().
module.exports.access = { default: 'controller' };
