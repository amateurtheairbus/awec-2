const { SlashCommandBuilder } = require('discord.js');
const { ephemeral } = require('../../util/reply');
const { isController, denyController } = require('../../util/permissions');
const { normalizeCallsign } = require('../../util/callsign');
const territoriesRepo = require('../../db/repos/territories');
const contactsRepo = require('../../db/repos/contacts');
const zones = require('../../services/territory');
const { coords } = require('../../services/format');

const NAME_RE = /^[A-Z0-9][A-Z0-9 _-]{0,23}$/;
const normName = (raw) => { const n = normalizeCallsign(raw); return NAME_RE.test(n) ? n : null; };

function describe(t) {
  const alt = t.min_alt_ft == null && t.max_alt_ft == null ? 'any altitude'
    : `${t.min_alt_ft != null ? t.min_alt_ft.toLocaleString('en-US') : 'surface'}–${t.max_alt_ft != null ? t.max_alt_ft.toLocaleString('en-US') + ' ft' : 'unlimited'}`;
  const shape = t.shape === 'circle'
    ? `circle, ${t.radius_nm} nm around ${coords(t.center_lat, t.center_lon)}`
    : `polygon, ${t.points.length} points`;
  return `${shape} · ${alt}`;
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('territory')
    .setDescription('Define the airspace where hostile contacts trigger a scramble')
    .addSubcommand((s) =>
      s.setName('add').setDescription('Add scramble airspace — a circle (center + radius) OR a polygon (points)')
        .addStringOption((o) => o.setName('name').setDescription('Name, e.g. HOME or NORTHERN BORDER').setRequired(true))
        .addNumberOption((o) => o.setName('center_lat').setDescription('Circle: center latitude').setMinValue(-90).setMaxValue(90))
        .addNumberOption((o) => o.setName('center_lon').setDescription('Circle: center longitude').setMinValue(-180).setMaxValue(180))
        .addNumberOption((o) => o.setName('radius_nm').setDescription('Circle: radius in nautical miles').setMinValue(1).setMaxValue(5000))
        .addStringOption((o) => o.setName('points').setDescription('Polygon: lat,lon pairs, e.g. 25.2,55.3; 26,56; 24,57 (3–50 points, auto-closed)'))
        .addIntegerOption((o) => o.setName('min_alt_ft').setDescription('Only scramble at/above this altitude (feet)').setMinValue(-2000).setMaxValue(100000))
        .addIntegerOption((o) => o.setName('max_alt_ft').setDescription('Only scramble at/below this altitude (feet)').setMinValue(-2000).setMaxValue(100000)))
    .addSubcommand((s) => s.setName('list').setDescription('Show the scramble airspace'))
    .addSubcommand((s) =>
      s.setName('remove').setDescription('Remove scramble airspace')
        .addStringOption((o) => o.setName('name').setDescription('Name of the territory to remove').setRequired(true))),

  async execute(interaction) {
    const guildId = interaction.guildId;
    const sub = interaction.options.getSubcommand();

    if (sub === 'list') {
      const all = territoriesRepo.list(guildId);
      if (!all.length) {
        return interaction.reply(ephemeral('No scramble airspace defined — **hostiles scramble anywhere they are seen**. Define some with `/territory add`.'));
      }
      const hostileInside = {};
      for (const c of contactsRepo.listLive(guildId)) if (c.iff === 'hostile' && c.territory) hostileInside[c.territory] = (hostileInside[c.territory] ?? 0) + 1;
      const lines = all.map((t) => `• **${t.name}** — ${describe(t)}${hostileInside[t.name] ? ` · ⚠ ${hostileInside[t.name]} hostile inside now` : ''}`);
      return interaction.reply(ephemeral(`**Scramble airspace (${all.length})** — a hostile inside any of these triggers a scramble\n${lines.join('\n')}`));
    }

    if (!isController(interaction)) return denyController(interaction);

    const name = normName(interaction.options.getString('name', true));
    if (!name) return interaction.reply(ephemeral('Invalid name. Use up to 24 letters, digits, spaces, `-` or `_` (it is stored in capitals).'));

    if (sub === 'remove') {
      if (!territoriesRepo.remove(guildId, name)) {
        const names = territoriesRepo.list(guildId).map((t) => `\`${t.name}\``).join(', ');
        return interaction.reply(ephemeral(`No territory named **${name}**.${names ? ` Existing: ${names}` : ''}`));
      }
      const left = territoriesRepo.list(guildId).length;
      return interaction.reply(ephemeral(`Removed **${name}**.` + (left ? '' : ' No scramble airspace is left, so hostiles will scramble anywhere again.')));
    }

    // ---- add ----
    const o = interaction.options;
    const lat = o.getNumber('center_lat'); const lon = o.getNumber('center_lon'); const radius = o.getNumber('radius_nm');
    const pointsRaw = o.getString('points');
    const minAlt = o.getInteger('min_alt_ft'); const maxAlt = o.getInteger('max_alt_ft');

    const anyCircle = lat !== null || lon !== null || radius !== null;
    if (anyCircle && pointsRaw) return interaction.reply(ephemeral('Pick ONE shape: either a circle (`center_lat`, `center_lon`, `radius_nm`) or a polygon (`points`), not both.'));
    if (!anyCircle && !pointsRaw) return interaction.reply(ephemeral('Give a shape: a circle (`center_lat`, `center_lon`, `radius_nm`) or a polygon (`points`, e.g. `25.2,55.3; 26,56; 24,57`).'));
    if (minAlt !== null && maxAlt !== null && minAlt > maxAlt) return interaction.reply(ephemeral('`min_alt_ft` can\'t be higher than `max_alt_ft`.'));

    let shape;
    if (anyCircle) {
      if (lat === null || lon === null || radius === null) return interaction.reply(ephemeral('A circle needs all three: `center_lat`, `center_lon` and `radius_nm`.'));
      shape = { shape: 'circle', centerLat: lat, centerLon: lon, radiusNm: radius };
    } else {
      const parsed = zones.parsePoints(pointsRaw);
      if (parsed.error) return interaction.reply(ephemeral(parsed.error));
      shape = { shape: 'polygon', points: parsed.points };
    }

    const hadNone = territoriesRepo.list(guildId).length === 0;
    const r = territoriesRepo.add(guildId, { name, ...shape, minAltFt: minAlt, maxAltFt: maxAlt, addedBy: interaction.user.id });
    if (r.error) return interaction.reply(ephemeral(r.error));
    return interaction.reply(ephemeral(
      `Added scramble airspace **${name}**: ${describe(r.territory)}.` +
      (hadNone ? '\nScrambles are now limited to defined airspace (before, hostiles scrambled anywhere they were seen).' : '') +
      '\nA hostile that enters it triggers a scramble; hostiles outside still show on the picture.'));
  },
};
