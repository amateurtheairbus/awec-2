// /commands list, /ping, the status report, and verification that every command's declared access is real.
process.env.DB_PATH = ':memory:';
const assert = require('assert');
require('../src/db/migrate')();

const { Collection } = require('discord.js');
const { loadCommands } = require('../src/util/commandLoader');
const commandList = require('../src/services/commandList');
const status = require('../src/services/status');
const geofs = require('../src/services/geofs');
const presence = require('../src/loops/presencePoller');

const mods = loadCommands();
const byName = new Map(mods.map((m) => [m.data.name, m]));
const commandsCmd = byName.get('commands');
const pingCmd = byName.get('ping');

// ---------- fakes ----------
function mkClient({ deployed = null, fail = false, ping = 55 } = {}) {
  return {
    commands: new Collection(mods.map((m) => [m.data.name, m])),
    ws: { ping },
    application: { commands: { fetch: async (opts) => {
      if (fail) throw new Error('offline');
      return new Map((opts?.guildId ? [] : (deployed ?? mods.map((m) => m.data.name))).map((n, i) => [`id${i}`, { name: n, id: String(900000 + i) }]));
    } } },
  };
}
function mkInteraction({ client, opts = {}, sub = 'list', group = null, guildId = 'g1', admin = false, controller = false }) {
  const calls = { defer: null, replies: [], edits: [], follow: [] };
  const i = {
    client, guildId, user: { id: 'u', tag: 'u' },
    memberPermissions: { has: () => admin },
    member: { roles: { cache: { some: (fn) => controller && fn({ name: 'AEW&C Controller' }) } } },
    guild: { members: { me: { permissions: { has: () => true } } }, roles: { cache: new Map() } },
    options: {
      getSubcommand: () => sub, getSubcommandGroup: () => group,
      getString: (k) => opts[k] ?? null, getBoolean: (k) => opts[k] ?? null, getInteger: (k) => opts[k] ?? null,
      getNumber: (k) => opts[k] ?? null, getUser: (k) => opts[k] ?? null, getRole: (k) => opts[k] ?? null, getChannel: (k) => opts[k] ?? null,
      getFocused: () => opts.__focused ?? '',
    },
    reply: async (p) => { calls.replies.push(p); },
    deferReply: async (p) => { calls.defer = p ?? {}; },
    editReply: async (p) => { calls.edits.push(p); },
    followUp: async (p) => { calls.follow.push(p); },
    respond: async (c) => { calls.choices = c; },
    _calls: calls,
  };
  return i;
}
const embedText = (embeds) => embeds.map((e) => `${e.data.title ?? ''}\n${e.data.description ?? ''}\n${e.data.footer?.text ?? ''}`).join('\n');
const allLeaves = () => mods.flatMap((m) => commandList.leaves(m.data.toJSON()).map((l) => ({ mod: m, leaf: l })));

(async () => {
  let n = 0; const ok = (m) => { console.log(`  ✓ ${m}`); n++; };

  // ================= loader + access metadata =================
  assert.ok(mods.length >= 14); assert.ok(byName.has('commands') && byName.has('ping') && byName.has('force'));
  for (const m of mods) {
    const acc = m.access ?? assert.fail(`/${m.data.name} has no access metadata`);
    assert.ok(['everyone', 'controller', 'admin'].includes(acc.default), `/${m.data.name} needs a valid default access`);
    const paths = commandList.leaves(m.data.toJSON()).map((l) => l.path.join(' '));
    for (const [key, level] of Object.entries(acc)) {
      assert.ok(['everyone', 'controller', 'admin'].includes(level), `/${m.data.name} ${key}: bad level ${level}`);
      if (key !== 'default') assert.ok(paths.some((p) => p === key || p.startsWith(`${key} `)), `/${m.data.name} access key "${key}" matches no subcommand (stale/typo?)`);
    }
  }
  ok('every command is discovered by the shared loader and declares valid access (no stale/typo keys)');

  // ================= access labels are TRUE =================
  const realFetch = globalThis.fetch;
  globalThis.fetch = async () => { throw new Error('no network in tests'); };
  geofs._resetCache();
  let checked = 0; const restricted = [];
  for (const { mod, leaf } of allLeaves()) {
    const level = commandList.accessOf(mod, leaf.path);
    const i = mkInteraction({ client: mkClient(), sub: leaf.path.at(-1) ?? null, group: leaf.path.length === 2 ? leaf.path[0] : null, guildId: 'gx' });
    try { await mod.execute(i); } catch { /* missing options -> a crash AFTER the permission check is fine */ }
    const said = [...i._calls.replies, ...i._calls.edits].map((r) => (typeof r === 'string' ? r : r.content ?? '')).join('\n');
    const denied = /requires (server admin|the \*\*AEW&C Controller\*\*)/.test(said);
    const path = `/${[mod.data.name, ...leaf.path].join(' ')}`;
    if (level === 'everyone') assert.ok(!denied, `${path} is labeled "everyone" but denied an ordinary member`);
    else { assert.ok(denied, `${path} is labeled "${level}" but an ordinary member was NOT denied`); restricted.push(path); }
    assert.ok(level !== 'admin' || /server admin/.test(said), `${path}: admin commands should say they need server admin`);
    assert.ok(level !== 'controller' || /Controller/.test(said), `${path}: controller commands should name the role`);
    checked++;
  }
  assert.ok(checked > 50 && restricted.length > 25);
  ok(`access labels verified by running all ${checked} subcommands as an ordinary member (${restricted.length} correctly denied)`);

  // admins/controllers get through the same gate: controller role satisfies "controller", not "admin"
  const ctl = mkInteraction({ client: mkClient(), controller: true, guildId: 'gx', sub: 'spawn' });
  await byName.get('contact').execute(ctl);
  assert.ok(!/requires/.test(JSON.stringify(ctl._calls)), 'controllers can use controller commands');
  const ctl2 = mkInteraction({ client: mkClient(), controller: true, guildId: 'gx', sub: 'setup' });
  await byName.get('ranks').execute(ctl2);
  assert.match(JSON.stringify(ctl2._calls.replies), /requires server admin/, 'a controller is NOT an admin');
  ok('controller role satisfies controller commands but not admin ones');

  // ================= /commands list =================
  commandList.clearIdCache();
  let i = mkInteraction({ client: mkClient({ deployed: [...byName.keys()] }) });
  await commandsCmd.execute(i);
  assert.deepStrictEqual(i._calls.defer, { flags: 64 }, 'ephemeral reply');
  let text = embedText(i._calls.edits[0].embeds);
  const leafCount = allLeaves().length;
  assert.match(text, new RegExp(`Commands — ${mods.length} commands, ${leafCount} subcommands`));
  assert.match(text, /<\/force wings edit:\d+>/); assert.match(text, /<\/force squadrons edit:\d+>/);
  assert.match(text, /<\/commands list:\d+>/); assert.match(text, /<\/ping:\d+>/);
  assert.ok(!/not deployed/.test(text), 'nothing flagged when everything is registered');
  assert.match(text, /<\/force wings edit:\d+> `wing \[wing_name\] \[wingcom\] \[wing_role\] \[member_channel\] \[force_tag\]` — Change a wing[^\n]*_Manage Server_/, 'usage shows required vs [optional] options and the access tag');
  assert.match(text, /<\/onboard:\d+> `user squadron \[geofs_id\]`[^\n]*_AEW&C Controller_/);
  const patrolStart = text.split('\n').find((l) => l.includes('/patrol start'));
  assert.ok(patrolStart && !/_Manage Server_|_AEW&C Controller_/.test(patrolStart), 'open commands carry no role tag');
  assert.ok(i._calls.edits[0].embeds.every((e) => (e.data.description ?? '').length <= 4096) && i._calls.edits[0].embeds.length <= 10);
  ok('/commands list: every command + subcommand with usage, description, access tag, clickable mentions');

  commandList.clearIdCache();
  i = mkInteraction({ client: mkClient({ deployed: mods.map((m) => m.data.name).filter((x) => x !== 'ping').concat('oldcmd') }) });
  await commandsCmd.execute(i);
  text = embedText(i._calls.edits[0].embeds);
  assert.match(text, /\*\*\/ping\*\* — [^\n]*⚠ _not deployed — run `npm run deploy-commands`_/);
  assert.match(text, /no longer in the bot: oldcmd/); assert.match(text, /`\/ping`/, 'undeployed commands fall back to plain text');
  ok('flags commands that exist in the code but are not registered with Discord (and stale registered ones)');

  commandList.clearIdCache();
  i = mkInteraction({ client: mkClient({ fail: true }) });
  await commandsCmd.execute(i);
  text = embedText(i._calls.edits[0].embeds);
  assert.match(text, /`\/force wings create`/); assert.ok(!/<\/force/.test(text) && !/not deployed/.test(text), 'Discord unreachable -> plain commands, no false "not deployed" flags');
  ok('works (plain text) when Discord can\'t be reached');

  commandList.clearIdCache();
  i = mkInteraction({ client: mkClient(), opts: { command: '/Force' } });
  await commandsCmd.execute(i);
  text = embedText(i._calls.edits[0].embeds);
  assert.match(text, /^\/force/); assert.ok(text.includes('/force wings create') || text.includes('force wings create')); assert.ok(!/\/patrol/.test(text), 'filter shows only that command');
  i = mkInteraction({ client: mkClient(), opts: { command: 'nope' } });
  await commandsCmd.execute(i);
  assert.match(i._calls.replies[0].content, /No command called `\/nope`\. Commands: .*`force`/);
  i = mkInteraction({ client: mkClient(), opts: { __focused: 'fo' } });
  await commandsCmd.autocomplete(i);
  assert.deepStrictEqual(i._calls.choices.map((c) => c.value), ['force']);
  i = mkInteraction({ client: mkClient(), opts: { __focused: '' } });
  await commandsCmd.autocomplete(i);
  assert.strictEqual(i._calls.choices.length, mods.length);
  ok('/commands list command:<name> filter (case/slash tolerant), unknown-command help, autocomplete');

  // ================= status helpers =================
  assert.strictEqual(status.formatDuration(45), '45s'); assert.strictEqual(status.formatDuration(125), '2m 5s');
  assert.strictEqual(status.formatDuration(3 * 3600 + 5 * 60), '3h 5m'); assert.strictEqual(status.formatDuration(90061), '1d 1h 1m');
  assert.strictEqual(status.formatBytes(2 * 1024 ** 3), '2.0 GB'); assert.strictEqual(status.formatBytes(81 * 1024 ** 2), '81 MB'); assert.strictEqual(status.formatBytes(null), '—');
  const good = { apiMs: 100, geo: { ok: true, ms: 150 }, poller: { running: true, failures: 0, lastOkAt: Date.now() }, db: { ok: true } };
  assert.strictEqual(status.verdict(good).level, 'ok');
  assert.strictEqual(status.verdict({ ...good, geo: { ok: true, ms: 5000 } }).level, 'warn');
  assert.strictEqual(status.verdict({ ...good, apiMs: 4000 }).level, 'warn');
  assert.strictEqual(status.verdict({ ...good, geo: { ok: false, error: 'x' } }).level, 'bad');
  assert.strictEqual(status.verdict({ ...good, db: { ok: false } }).level, 'bad');
  assert.strictEqual(status.verdict({ ...good, poller: { running: true, failures: 2, lastError: 'boom' } }).level, 'warn');
  assert.strictEqual(status.verdict({ ...good, poller: { running: true, failures: 0, lastOkAt: Date.now() - 10 * 60_000 } }).level, 'warn');
  assert.strictEqual(status.verdict({ ...good, geo: { ok: false }, apiMs: 4000 }).level, 'bad', 'a hard problem outranks a warning');
  const ps = presence.status(presence.newState());
  assert.deepStrictEqual(Object.keys(ps).sort(), ['backoffUntil', 'failures', 'lastError', 'lastOkAt', 'lastPlayers', 'running']);
  ok('status helpers: durations, sizes, verdict levels (ok / degraded / problem), poller health snapshot');

  // ================= GeoFS latency measurement =================
  let fetchCalls = 0;
  const feed = (users = [{ acid: 1, cs: 'A' }, { acid: 2, cs: 'B' }, { acid: 0, cs: 'Foo' }]) => async () => {
    fetchCalls++; await new Promise((r) => setTimeout(r, 25));
    return { ok: true, json: async () => ({ userCount: users.length, users }) };
  };
  globalThis.fetch = feed(); geofs._resetCache();
  let m1 = await geofs.measure();
  assert.ok(m1.ok && m1.ms >= 20 && m1.ms < 2000 && m1.status === 200 && m1.players === 2 && m1.cached === false, 'fresh measurement of a real request');
  const m2 = await geofs.measure();
  assert.ok(m2.cached && fetchCalls === 1, 'a measurement under 10 s old is reused — GeoFS never sees more than 1 request / 10 s');
  geofs._resetCache(); globalThis.fetch = async () => ({ ok: false, status: 503 });
  const m3 = await geofs.measure();
  assert.ok(!m3.ok && m3.status === 503 && /503/.test(m3.error));
  geofs._resetCache(); globalThis.fetch = async () => { throw new Error('getaddrinfo ENOTFOUND'); };
  const m4 = await geofs.measure();
  assert.ok(!m4.ok && /ENOTFOUND/.test(m4.error));
  ok('GeoFS latency: real round trip, 10 s reuse, HTTP errors and network failures reported');

  // ================= /ping =================
  fetchCalls = 0; globalThis.fetch = feed(); geofs._resetCache();
  i = mkInteraction({ client: mkClient({ ping: 55 }) });
  await pingCmd.execute(i);
  assert.deepStrictEqual(i._calls.defer, { flags: 64 }, 'private by default');
  const reply = i._calls.edits[0];
  assert.strictEqual(reply.content, 'Pong!');
  const e = reply.embeds[0].data;
  assert.match(e.title, /Pong!/); assert.match(e.description, /All systems operational/);
  const field = (name) => e.fields.find((f) => f.name === name).value;
  assert.match(field('Discord'), /Gateway heartbeat: \*\*55 ms\*\*/); assert.match(field('Discord'), /API round-trip: \*\*\d+ ms\*\*/);
  assert.match(field('GeoFS'), /Multiplayer feed: \*\*\d+ ms\*\* · HTTP 200 · 2 players online/); assert.match(field('GeoFS'), /Presence poller:/);
  assert.match(field('Server'), /Bot uptime[^\n]*host uptime/); assert.match(field('Server'), /Memory: bot \d+ MB/); assert.match(field('Server'), /Load: [\d. ]+\(\d+ cores?\)/);
  assert.match(field('Server'), /Database: OK · [\d.]+ ms/); assert.match(field('Server'), /Node v\d+/); assert.match(field('Server'), /discord\.js 14\./);
  assert.ok(!/\/home|\/opt|\/var|localhost|127\.0|192\.168/.test(JSON.stringify(e)), 'no paths/hosts/addresses leaked');
  ok('/ping: pong, Discord gateway + API latency, GeoFS latency + players, poller, uptime/memory/load/database/versions');

  // a second ping right away reuses the GeoFS measurement instead of hitting GeoFS again
  i = mkInteraction({ client: mkClient(), opts: { public: true } });
  await pingCmd.execute(i);
  assert.deepStrictEqual(i._calls.defer, {}, 'public: true -> visible to everyone');
  assert.strictEqual(fetchCalls, 1, 'GeoFS contacted once for both pings');
  assert.match(i._calls.edits[0].embeds[0].data.fields.find((f) => f.name === 'GeoFS').value, /\(measured \d+s ago\)/);
  ok('/ping public option; repeated pings reuse the <10 s GeoFS measurement');

  // GeoFS down -> clearly flagged
  geofs._resetCache(); globalThis.fetch = async () => { throw new Error('connect ETIMEDOUT'); };
  i = mkInteraction({ client: mkClient({ ping: -1 }) });
  await pingCmd.execute(i);
  const bad = i._calls.edits[0].embeds[0].data;
  assert.match(bad.description, /Problem detected/); assert.match(bad.description, /GeoFS unreachable \(connect ETIMEDOUT\)/);
  assert.match(bad.fields.find((f) => f.name === 'GeoFS').value, /unreachable/); assert.match(bad.fields.find((f) => f.name === 'Discord').value, /measuring…/);
  assert.strictEqual(bad.color, 0xcc2222);
  ok('/ping when GeoFS is unreachable: red status with the reason; gateway "measuring…" before the first heartbeat');

  globalThis.fetch = realFetch;
  console.log(`\n${n} checks passed`);
})().catch((e) => { console.error('\nFAILED:', e); process.exit(1); });
