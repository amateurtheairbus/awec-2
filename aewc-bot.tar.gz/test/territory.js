// Scramble airspace: geometry, /territory command, and scramble-on-entry behavior.
process.env.DB_PATH = ':memory:';
const assert = require('assert');
require('../src/db/migrate')();

const db = require('../src/db/index');
const config = require('../src/db/repos/config');
const tags = require('../src/db/repos/tags');
const contacts = require('../src/db/repos/contacts');
const territories = require('../src/db/repos/territories');
const zones = require('../src/services/territory');
const geofs = require('../src/services/geofs');
const picture = require('../src/services/picture');
const presence = require('../src/loops/presencePoller');
const cmd = require('../src/commands/territory/territory.js');

// ---- fake Discord ----
const sent = []; const msgs = new Map(); let seq = 0;
function mk() { const id = `m${++seq}`; const m = { id, edit: async () => m, delete: async () => msgs.delete(id) }; msgs.set(id, m); return m; }
function chan(id) { return { id, isTextBased: () => true, send: async (p) => { sent.push({ channel: id, payload: p }); return mk(); }, messages: { fetch: async (mid) => { const m = msgs.get(mid); if (!m) throw new Error('Unknown Message'); return m; } } }; }
const chans = { pic: chan('pic'), threat: chan('threat'), patrol: chan('patrol'), intel: chan('intel') };
const client = { channels: { fetch: async (id) => chans[id] ?? null } };
const titleOf = (s) => s.payload.embeds[0].data.title;
const descOf = (s) => s.payload.embeds[0].data.description;
const scrambles = () => sent.filter((s) => s.channel === 'threat' && titleOf(s) === 'SCRAMBLE');

const U = (acid, cs, { lat = 0, lon = 0, alt = 3000, hdg = 90, as = 400 } = {}) =>
  geofs.normalizeUser({ id: `s${acid}`, acid, cs, co: [lat, lon, alt, hdg, 0, 0], st: { as } });

(async () => {
  let n = 0; const ok = (m) => { console.log(`  ✓ ${m}`); n++; };

  // ================= geometry =================
  const circle = { shape: 'circle', center_lat: 25, center_lon: 55, radius_nm: 100 };
  assert.ok(zones.contains(circle, { lat: 25, lon: 55 }));
  assert.ok(zones.contains(circle, { lat: 25, lon: 56 }), '~54 nm east of centre is inside a 100 nm circle');
  assert.ok(!zones.contains(circle, { lat: 25, lon: 58 }), '~163 nm away is outside');
  assert.ok(!zones.contains(circle, { lat: NaN, lon: 55 }));

  // concave "L" shape: the notch must be OUTSIDE
  const L = zones.parsePoints('0,0; 0,10; 5,10; 5,5; 10,5; 10,0').points;
  const poly = { shape: 'polygon', points: L };
  assert.ok(zones.contains(poly, { lat: 2, lon: 8 }) && zones.contains(poly, { lat: 8, lon: 2 }));
  assert.ok(!zones.contains(poly, { lat: 8, lon: 8 }), 'the notch of a concave polygon is outside');
  assert.ok(!zones.contains(poly, { lat: -1, lon: 5 }));

  // crosses the antimeridian
  const dl = { shape: 'polygon', points: zones.parsePoints('0,170 0,-170 10,-170 10,170').points };
  assert.ok(zones.contains(dl, { lat: 5, lon: 179 }) && zones.contains(dl, { lat: 5, lon: -175 }));
  assert.ok(!zones.contains(dl, { lat: 5, lon: 0 }) && !zones.contains(dl, { lat: 5, lon: -160 }));

  // altitude band
  const banded = { ...circle, min_alt_ft: 10000, max_alt_ft: 40000 };
  assert.ok(zones.contains(banded, { lat: 25, lon: 55, altitudeFt: 25000 }));
  assert.ok(!zones.contains(banded, { lat: 25, lon: 55, altitudeFt: 5000 }) && !zones.contains(banded, { lat: 25, lon: 55, altitudeFt: 45000 }));
  assert.ok(zones.contains({ ...circle, min_alt_ft: 10000, max_alt_ft: null }, { lat: 25, lon: 55, altitudeFt: 99999 }), 'open-ended band');
  ok('geometry: circle, concave polygon, antimeridian polygon, altitude bands');

  // ================= point parsing =================
  assert.deepStrictEqual(zones.parsePoints('1,1; 1,5; 5,5').points, [[1, 1], [1, 5], [5, 5]]);
  assert.deepStrictEqual(zones.parsePoints('1,1 1,5 5,5').points, [[1, 1], [1, 5], [5, 5]], 'space-separated pairs');
  assert.deepStrictEqual(zones.parsePoints('1 1; 1 5; 5 5; 1 1').points, [[1, 1], [1, 5], [5, 5]], '"lat lon" pairs; repeated first point dropped');
  assert.match(zones.parsePoints('1,1; 2,2').error, /at least 3/);
  assert.match(zones.parsePoints('1,1; 2,2; 3,3').error, /straight line/);
  assert.match(zones.parsePoints('1,1; 1,5; 95,5').error, /out of range/);
  assert.match(zones.parsePoints('1,1; 1,5; 500,5').error, /Latitude 500/);
  assert.match(zones.parsePoints('1,1; 1,500; 5,5').error, /Longitude 500/);
  assert.match(zones.parsePoints('1,1; abc; 5,5').error, /Couldn't read/);
  assert.match(zones.parsePoints(Array.from({ length: 51 }, (_, i) => `${i % 80},${i}`).join(';')).error, /at most 50/);
  ok('polygon point parsing: formats accepted, bad input explained');

  // ================= repo =================
  const G0 = 'g0';
  assert.ok(territories.add(G0, { name: 'HOME', shape: 'circle', centerLat: 1, centerLon: 2, radiusNm: 50, addedBy: 'a' }).territory);
  assert.match(territories.add(G0, { name: 'HOME', shape: 'circle', centerLat: 1, centerLon: 2, radiusNm: 50, addedBy: 'a' }).error, /already/);
  assert.strictEqual(territories.getByName(G0, 'HOME').radius_nm, 50);
  territories.add(G0, { name: 'POLY', shape: 'polygon', points: [[0, 0], [0, 1], [1, 1]], addedBy: 'a' });
  assert.deepStrictEqual(territories.list(G0).find((t) => t.name === 'POLY').points, [[0, 0], [0, 1], [1, 1]], 'polygon points round-trip');
  assert.ok(territories.remove(G0, 'HOME') && !territories.remove(G0, 'HOME'));
  for (let i = 0; i < 24; i++) territories.add(G0, { name: `Z${i}`, shape: 'circle', centerLat: 0, centerLon: 0, radiusNm: 1, addedBy: 'a' });
  assert.match(territories.add(G0, { name: 'ONE-TOO-MANY', shape: 'circle', centerLat: 0, centerLon: 0, radiusNm: 1, addedBy: 'a' }).error, /Limit reached/);
  ok('territory storage: CRUD, duplicate names, per-server limit');

  // ================= /territory command =================
  const run = async ({ sub, opts = {}, controller = true, guild = 'gc' }) => {
    const replies = [];
    await cmd.execute({
      guildId: guild, user: { id: 'ctl' }, memberPermissions: { has: () => false },
      member: { roles: { cache: { some: (fn) => controller && fn({ name: 'AEW&C Controller' }) } } },
      options: { getSubcommand: () => sub, getString: (k) => opts[k] ?? null, getNumber: (k) => opts[k] ?? null, getInteger: (k) => opts[k] ?? null },
      reply: async (p) => { replies.push(p); },
    });
    return replies.map((r) => r.content).join('\n');
  };
  assert.match(await run({ sub: 'list' }), /hostiles scramble anywhere/);
  assert.match(await run({ sub: 'add', controller: false, opts: { name: 'X', center_lat: 1, center_lon: 1, radius_nm: 5 } }), /requires the \*\*AEW&C Controller\*\*/);
  assert.match(await run({ sub: 'remove', controller: false, opts: { name: 'X' } }), /requires the/);
  assert.match(await run({ sub: 'add', opts: { name: '!!!', center_lat: 1, center_lon: 1, radius_nm: 5 } }), /Invalid name/);
  assert.match(await run({ sub: 'add', opts: { name: 'A' } }), /Give a shape/);
  assert.match(await run({ sub: 'add', opts: { name: 'A', center_lat: 1, center_lon: 1, radius_nm: 5, points: '1,1;2,2;3,3' } }), /ONE shape/);
  assert.match(await run({ sub: 'add', opts: { name: 'A', center_lat: 1, radius_nm: 5 } }), /needs all three/);
  assert.match(await run({ sub: 'add', opts: { name: 'A', points: '1,1; 2,2' } }), /at least 3/);
  assert.match(await run({ sub: 'add', opts: { name: 'A', center_lat: 1, center_lon: 1, radius_nm: 5, min_alt_ft: 9000, max_alt_ft: 1000 } }), /can't be higher/);
  assert.strictEqual(territories.list('gc').length, 0, 'nothing saved by rejected input');

  let out = await run({ sub: 'add', opts: { name: 'home', center_lat: 25.2, center_lon: 55.3, radius_nm: 150 } });
  assert.match(out, /Added scramble airspace \*\*HOME\*\*: circle, 150 nm around 25\.20N 55\.30E · any altitude/);
  assert.match(out, /now limited to defined airspace/, 'first territory explains the behavior change');
  out = await run({ sub: 'add', opts: { name: 'Northern Border', points: '27,50; 27,60; 29,60; 29,50', min_alt_ft: 10000, max_alt_ft: 45000 } });
  assert.match(out, /NORTHERN BORDER\*\*: polygon, 4 points · 10,000–45,000 ft/);
  assert.ok(!/now limited/.test(out));
  assert.match(await run({ sub: 'add', opts: { name: 'HOME', center_lat: 1, center_lon: 1, radius_nm: 5 } }), /already a territory/);
  out = await run({ sub: 'list' });
  assert.match(out, /Scramble airspace \(2\)/); assert.match(out, /\*\*HOME\*\* — circle/); assert.match(out, /\*\*NORTHERN BORDER\*\* — polygon/);
  assert.match(await run({ sub: 'remove', opts: { name: 'nope' } }), /No territory named \*\*NOPE\*\*\. Existing: `HOME`, `NORTHERN BORDER`/);
  assert.match(await run({ sub: 'remove', opts: { name: 'northern border' } }), /Removed \*\*NORTHERN BORDER\*\*\.$/);
  assert.match(await run({ sub: 'remove', opts: { name: 'home' } }), /scramble anywhere again/);
  assert.strictEqual(territories.list('gc').length, 0);
  ok('/territory add/list/remove: shape validation, naming, gating, explanatory replies');

  // ================= scramble behavior =================
  const G = 'g1';
  config.setChannels(G, { picture: 'pic', threatLog: 'threat', patrolLog: 'patrol', intel: 'intel' });
  config.setScrambleRole(G, 'SCR');
  tags.add(G, 'RUAF', 'a', 'hostile'); tags.add(G, 'FRND', 'a', 'friendly');
  const st = presence.newState();
  const run2 = (players, nowUnix) => presence.processGuild(client, G, players, { nowUnix: nowUnix ?? Math.floor(Date.now() / 1000), state: st });

  // --- no territories: legacy behavior, scramble anywhere on first sight ---
  await run2([U('500', 'viper[ruaf]', { lat: -40, lon: 100 })]);
  assert.strictEqual(scrambles().length, 1, 'no territories defined -> scramble anywhere');
  assert.ok(!/inside/.test(descOf(scrambles()[0])));
  await run2([U('500', 'viper[ruaf]', { lat: -40, lon: 101 })]);
  assert.strictEqual(scrambles().length, 1, 'no repeat while it stays');
  contacts.fade(contacts.getLive(G, '500').id);
  ok('no territories defined: hostile scrambles anywhere (legacy), once');

  // --- with territories ---
  territories.add(G, { name: 'HOME', shape: 'circle', centerLat: 25, centerLon: 55, radiusNm: 100, addedBy: 'a' });
  territories.add(G, { name: 'HIGH ROAD', shape: 'polygon', points: [[40, 10], [40, 20], [45, 20], [45, 10]], minAltFt: 30000, addedBy: 'a' });
  const base = scrambles().length;
  const post = (n) => sent.filter((s) => s.channel === 'threat').length;
  const t0 = Math.floor(Date.now() / 1000);

  // outside every territory: shown, NOT scrambled
  await run2([U('600', 'bandit[ruaf]', { lat: 0, lon: 0 })], t0);
  assert.strictEqual(scrambles().length, base, 'hostile outside scramble airspace: no scramble');
  const c = contacts.getLive(G, '600');
  assert.ok(c && c.iff === 'hostile' && c.in_zone === 0 && c.territory === null, 'still tracked as a contact');
  assert.ok(sent.some((s) => titleOf(s) === 'CONTACT' && /BANDIT\[RUAF\]/.test(descOf(s))), 'and still posted');
  ok('hostile outside scramble airspace is posted but not scrambled');

  // enters HOME: scramble, naming the territory
  await run2([U('600', 'bandit[ruaf]', { lat: 25, lon: 55.5 })], t0 + 45);
  assert.strictEqual(scrambles().length, base + 1);
  let sc = scrambles().at(-1);
  assert.strictEqual(sc.payload.content, '<@&SCR>'); assert.match(descOf(sc), /inside \*\*HOME\*\*/); assert.match(descOf(sc), /BANDIT\[RUAF\]/);
  assert.strictEqual(contacts.getLive(G, '600').territory, 'HOME');
  const line = picture.buildEmbed(G).toJSON().fields.find((f) => f.name.startsWith('Contacts')).value;
  assert.match(line, /⚠ IN HOME/, 'picture flags contacts inside scramble airspace');
  ok('entering scramble airspace -> SCRAMBLE naming the territory; picture shows ⚠ IN HOME');

  // stays inside: no repeat
  await run2([U('600', 'bandit[ruaf]', { lat: 25.1, lon: 55.6 })], t0 + 90);
  assert.strictEqual(scrambles().length, base + 1, 'no repeat while it stays inside');

  // leaves and re-enters immediately (border flapping): cooldown suppresses
  await run2([U('600', 'bandit[ruaf]', { lat: 10, lon: 10 })], t0 + 135);
  assert.strictEqual(contacts.getLive(G, '600').territory, null);
  await run2([U('600', 'bandit[ruaf]', { lat: 25, lon: 55 })], t0 + 180);
  assert.strictEqual(scrambles().length, base + 1, 'border flapping inside the 5 min cooldown does not re-scramble');

  // leaves, comes back after the cooldown: scramble again
  await run2([U('600', 'bandit[ruaf]', { lat: 10, lon: 10 })], t0 + 225);
  db.prepare("UPDATE contacts SET scrambled_at = datetime('now','-400 seconds') WHERE geofs_id = '600'").run();
  await run2([U('600', 'bandit[ruaf]', { lat: 25, lon: 55 })], t0 + 270);
  assert.strictEqual(scrambles().length, base + 2, 're-entering after the cooldown scrambles again');
  ok('no repeat while inside; border flapping is debounced (5 min); real re-entry scrambles again');

  // altitude band on the polygon
  await run2([U('700', 'high[ruaf]', { lat: 42, lon: 15, alt: 3000 })], t0 + 300);     // ~10,000 ft: below the 30,000 ft floor
  assert.strictEqual(scrambles().length, base + 2, 'inside the polygon but below its altitude floor');
  await run2([U('700', 'high[ruaf]', { lat: 42, lon: 15, alt: 11000 })], t0 + 345);    // ~36,000 ft
  assert.strictEqual(scrambles().length, base + 3, 'climbing into the altitude band scrambles');
  assert.match(descOf(scrambles().at(-1)), /inside \*\*HIGH ROAD\*\*/);
  ok('altitude band: a hostile only scrambles once inside the band');

  // friendlies never scramble, even deep inside
  const before = scrambles().length;
  await run2([U('800', 'ally[frnd]', { lat: 25, lon: 55 })], t0 + 400);
  assert.strictEqual(scrambles().length, before);
  assert.strictEqual(contacts.getLive(G, '800').territory, null, 'friendlies are not zone-tracked');
  ok('friendlies inside scramble airspace never scramble');

  // a friendly re-tagged hostile while inside HOME scrambles
  tags.add(G, 'FRND', 'a', 'hostile');
  await run2([U('800', 'ally[frnd]', { lat: 25, lon: 55 })], t0 + 445);
  assert.strictEqual(scrambles().length, before + 1);
  assert.match(descOf(scrambles().at(-1)), /inside \*\*HOME\*\*/);
  ok('re-categorizing a tag to hostile scrambles for players already inside scramble airspace');

  // removing all territories goes back to "anywhere" for NEW contacts
  territories.remove(G, 'HOME'); territories.remove(G, 'HIGH ROAD');
  const b2 = scrambles().length;
  await run2([U('900', 'far[ruaf]', { lat: -60, lon: -100 })], t0 + 500);
  assert.strictEqual(scrambles().length, b2 + 1);
  ok('removing every territory restores scramble-anywhere for new contacts');

  console.log(`\n${n} checks passed`);
})().catch((e) => { console.error('\nFAILED:', e); process.exit(1); });
