// Tests for the GeoFS client, presence poller and threat timer — fake Discord, fake GeoFS feed.
process.env.DB_PATH = ':memory:';
const assert = require('assert');
require('../src/db/migrate')();

const db = require('../src/db/index');
const config = require('../src/db/repos/config');
const tags = require('../src/db/repos/tags');
const pilots = require('../src/db/repos/pilots');
const patrols = require('../src/db/repos/patrols');
const contacts = require('../src/db/repos/contacts');
const intel = require('../src/db/repos/intel');
const geofs = require('../src/services/geofs');
const presence = require('../src/loops/presencePoller');
const threat = require('../src/loops/threatTimer');
const ops = require('../src/services/ops');

// ---- fake Discord ----
const sent = []; const edits = []; const msgs = new Map(); let seq = 0;
function chan(id) {
  return {
    id, isTextBased: () => true,
    send: async (p) => { const m = mk(); sent.push({ channel: id, payload: p }); return m; },
    messages: { fetch: async (mid) => { const m = msgs.get(mid); if (!m) throw new Error('Unknown Message'); return m; } },
  };
}
function mk() { const id = `m${++seq}`; const m = { id, edit: async (p) => { edits.push({ id, p }); return m; }, delete: async () => msgs.delete(id) }; msgs.set(id, m); return m; }
const chans = { pic: chan('pic'), threat: chan('threat'), patrol: chan('patrol'), intel: chan('intel') };
const client = { channels: { fetch: async (id) => chans[id] ?? null } };
const postsTo = (c) => sent.filter((s) => s.channel === c).length;
const text = (s) => JSON.stringify(s.payload.embeds?.[0]?.data ?? {});

const G = 'g1';
const P = (geofsId, callsign, extra = {}) => ({ geofsId, callsign, sessionId: 's' + geofsId, aircraftId: 1, lat: 25.2, lon: 55.3, altitudeM: 3000, headingDeg: 90, ...extra });

(async () => {
  let n = 0; const ok = (m) => { console.log(`  ✓ ${m}`); n++; };

  // ================= GeoFS client =================
  geofs._resetCache();
  const fakeFetch = async (url, opts) => {
    assert.ok(url.endsWith('/map')); assert.strictEqual(opts.method, 'POST');
    assert.deepStrictEqual(JSON.parse(opts.body), { id: '', gid: null });
    return { ok: true, json: async () => ({ userCount: 5, users: [
      { id: 'a1', acid: 2018929, cs: 'LEOPARD-2[H7T][SAAF]', co: [25.1, 55.2, 3048, 90, 0, 0], ac: 7 },
      { id: 'a2', acid: 0, cs: 'Foo', co: [0, 0, 0, 0, 0, 0] },                 // anonymous
      { id: 'a3', acid: 555, cs: 'AAL123', ad: 1, co: [1, 2, 3, 4, 5, 6] },      // ADS-B traffic
      { id: 'a4', cs: 'NoAccount' },                                              // no acid at all
      { id: 'a5', acid: '777', cs: 'Str', co: [] },
      null,                                                                       // real feeds contain null entries
      'garbage', 42,
    ] }) };
  };
  let snap = await geofs.getOnlinePlayers({ fetchImpl: fakeFetch, now: 1_000_000 });
  assert.strictEqual(snap.players.length, 2);
  assert.strictEqual(snap.players[0].geofsId, '2018929'); assert.strictEqual(snap.players[0].callsign, 'LEOPARD-2[H7T][SAAF]');
  assert.strictEqual(snap.players[1].geofsId, '777'); assert.strictEqual(snap.players[1].lat, null);
  ok('GeoFS /map normalization: numeric acid -> geofsId, traffic/anonymous filtered, bad coords tolerated');

  let calls = 0; const counting = async (...a) => { calls++; return fakeFetch(...a); };
  geofs._resetCache();
  await geofs.getOnlinePlayers({ fetchImpl: counting, now: 5_000_000 });
  await geofs.getOnlinePlayers({ fetchImpl: counting, now: 5_003_000 });          // within 10 s -> cached
  await geofs.getOnlinePlayers({ fetchImpl: counting, now: 5_011_000 });          // after 10 s -> refetch
  assert.strictEqual(calls, 2);
  ok('GeoFS client never hits /map faster than once per 10 s');

  await assert.rejects(geofs.getOnlinePlayers({ fetchImpl: async () => ({ ok: false, status: 503 }), force: true }), /503/);
  await assert.rejects(geofs.getOnlinePlayers({ fetchImpl: async () => ({ ok: true, json: async () => ({}) }), force: true }), /users array/);
  ok('feed errors / malformed responses throw (never silently "empty")');

  // ================= Presence poller =================
  config.setChannels(G, { picture: 'pic', threatLog: 'threat', patrolLog: 'patrol', intel: 'intel' });
  tags.add(G, 'SAAF', 'admin'); tags.add(G, 'USAF', 'admin');
  pilots.register(G, 'p1', '2018929', 'admin');
  pilots.register(G, 'p2', '3000', 'admin');
  intel.add(G, '9999', { notes: 'Known troll', alertOnSighting: true, flaggedBy: 'ctl' });
  intel.add(G, '8888', { notes: 'Quiet one', alertOnSighting: false, flaggedBy: 'ctl' });
  const st = presence.newState();
  const run = (players, nowUnix) => presence.processGuild(client, G, players, { nowUnix: nowUnix ?? Math.floor(Date.now() / 1000), state: st });

  const base = [
    P('2018929', 'LEOPARD-2[H7T][SAAF]'),
    P('3000', 'Cessna 172'),             // registered but NOT flying under a tag
    P('9999', 'Bad Guy'),
    P('8888', 'Quiet'),
    P('777', 'Rando[SAAF]'),             // tagged but unregistered
  ];
  const patrolPostsBefore = postsTo('patrol'); const intelPostsBefore = postsTo('intel');
  await run(base);

  const p1 = patrols.getOpenForUser(G, 'p1');
  assert.ok(p1, 'p1 auto patrol started');
  assert.strictEqual(p1.auto_started, 1); assert.strictEqual(p1.callsign_tag, 'SAAF');
  assert.strictEqual(p1.aircraft, 'LEOPARD-2'); assert.strictEqual(p1.geofs_id, '2018929');
  assert.strictEqual(patrols.getOpenForUser(G, 'p2'), undefined, 'untagged registered pilot is NOT auto-patrolled');
  assert.strictEqual(patrols.listOpen(G).length, 1, 'unregistered tagged player does not create a patrol');
  assert.strictEqual(postsTo('patrol'), patrolPostsBefore + 1, 'patrol start mirrored to patrol log');
  ok('registered + tagged -> auto patrol (tag/callsign recorded); untagged or unregistered -> none');

  assert.strictEqual(postsTo('intel'), intelPostsBefore + 1, 'only the alert-enabled intel entry posted');
  assert.match(text(sent.filter((s) => s.channel === 'intel').pop()), /9999/);
  assert.strictEqual(db.prepare("SELECT COUNT(*) n FROM event_log WHERE event_type='intel_sighting'").get().n, 2, 'both sightings are in event_log');
  assert.strictEqual(intel.get(G, '8888').last_seen_callsign, 'Quiet');
  ok('intel: alert-enabled entry posts, alert-disabled logs silently, last-seen updated');

  const sentBefore = sent.length;
  await run(base);
  assert.strictEqual(sent.length, sentBefore, 'steady state: no duplicate patrols or alerts');
  assert.strictEqual(patrols.listOpen(G).length, 1);
  ok('steady state is quiet (no duplicate patrols/alerts)');

  // pilot ends patrol manually but stays online -> bot must not restart it
  await ops.endPatrol(client, G, patrols.getOpenForUser(G, 'p1'), { actorId: 'p1' });
  await run(base);
  assert.strictEqual(patrols.getOpenForUser(G, 'p1'), undefined);
  ok('manually ended patrol is not auto-restarted while the pilot stays online');

  // drop off, then come back -> new session -> new auto patrol
  await run(base.filter((p) => p.geofsId !== '2018929'));
  await run(base);
  assert.ok(patrols.getOpenForUser(G, 'p1'));
  ok('pilot returns after dropping offline -> fresh auto patrol');

  // grace period
  const offline = base.filter((p) => p.geofsId !== '2018929');
  db.prepare("UPDATE patrols SET last_seen_at = datetime('now','-100 seconds') WHERE status IN ('active','rtb')").run();
  await run(offline);
  assert.ok(patrols.getOpenForUser(G, 'p1'), 'still open inside the 5-minute grace window');
  db.prepare("UPDATE patrols SET last_seen_at = datetime('now','-400 seconds') WHERE status IN ('active','rtb')").run();
  const patrolPosts = postsTo('patrol');
  await run(offline);
  assert.strictEqual(patrols.getOpenForUser(G, 'p1'), undefined, 'auto-ended after grace');
  assert.strictEqual(postsTo('patrol'), patrolPosts + 1);
  assert.match(text(sent.filter((s) => s.channel === 'patrol').pop()), /auto-ended/);
  ok('grace period: stays open inside 5 min, auto-ends after');

  // manual patrols are never auto-ended
  await ops.startPatrol(client, G, { discordId: 'p2', aircraft: 'F-16' });
  db.prepare("UPDATE patrols SET last_seen_at = datetime('now','-9999 seconds') WHERE discord_id='p2'").run();
  await run(offline);
  assert.ok(patrols.getOpenForUser(G, 'p2'), 'manual patrol untouched by poller');
  ok('manually started patrols are never auto-ended');

  // intel cooldown / re-alert
  const intelPosts = postsTo('intel');
  await run(base.filter((p) => p.geofsId !== '9999'));           // 9999 drops
  await run(base);                                               // 9999 returns immediately
  assert.strictEqual(postsTo('intel'), intelPosts, 'quick reconnect inside cooldown -> no re-alert');
  db.prepare("UPDATE intel_contacts SET last_seen_at = datetime('now','-1000 seconds') WHERE geofs_id='9999'").run();
  await run(base.filter((p) => p.geofsId !== '9999'));
  await run(base);
  assert.strictEqual(postsTo('intel'), intelPosts + 1, 're-alerts after the cooldown');
  ok('intel alert cooldown: no spam on reconnect, re-alerts for a genuinely new session');

  // feed outage must not end patrols
  await ops.startPatrol(client, G, { discordId: 'p3', aircraft: 'X', auto: true });
  db.prepare("UPDATE patrols SET last_seen_at = datetime('now','-9999 seconds') WHERE discord_id='p3'").run();
  geofs._resetCache();
  const st2 = presence.newState();
  const warn = console.warn; console.warn = () => {};
  await presence.tick(client, { now: Date.now() + 1e7, fetchImpl: async () => { throw new Error('network down'); }, state: st2 });
  console.warn = warn;
  assert.ok(patrols.getOpenForUser(G, 'p3'), 'patrol survives a failed poll');
  assert.ok(st2.backoffUntil > Date.now(), 'backoff scheduled');
  ok('feed outage: nothing is ended, poller backs off');

  // ================= Threat timer =================
  config.setTunables(G, { threat_spawn_min_s: 30, threat_spawn_max_s: 30, threat_population_cap: 2 });
  const tst = threat.newState();
  const t0 = 10_000_000;
  const before = contacts.countActive(G);
  await threat.tickGuild(client, G, { nowMs: t0, rng: () => 0.5, state: tst });        // schedules
  assert.strictEqual(contacts.countActive(G), before);
  await threat.tickGuild(client, G, { nowMs: t0 + 29_000, rng: () => 0.5, state: tst });
  assert.strictEqual(contacts.countActive(G), before, 'not yet due');
  await threat.tickGuild(client, G, { nowMs: t0 + 31_000, rng: () => 0.5, state: tst });
  assert.strictEqual(contacts.countActive(G), before + 1, 'spawned when due');
  ok('threat timer: schedules on first sight, spawns when the interval elapses');

  await threat.tickGuild(client, G, { nowMs: t0 + 70_000, rng: () => 0.5, state: tst });
  await threat.tickGuild(client, G, { nowMs: t0 + 110_000, rng: () => 0.5, state: tst });
  assert.ok(contacts.countActive(G) <= 2, 'population cap respected');
  ok('threat timer respects the population cap');

  const u = contacts.create(G, { callsign: 'TRK-0001', iff: 'unknown', classification: 'fighter', bearing: 1, range_nm: 50, altitude_ft: 30000, heading: 1, speed_kt: 400, expires_at: '2000-01-01 00:00:00' });
  const f = contacts.create(G, { callsign: 'TRK-0002', iff: 'friendly', classification: 'transport', bearing: 1, range_nm: 50, altitude_ft: 30000, heading: 1, speed_kt: 300, expires_at: '2000-01-01 00:00:00' });
  const threatPosts = postsTo('threat');
  await threat.tickGuild(client, G, { nowMs: t0 + 120_000, rng: () => 0.1, state: tst });
  assert.strictEqual(contacts.get(u.id).iff, 'hostile'); assert.strictEqual(contacts.get(u.id).status, 'active');
  assert.ok(contacts.get(u.id).expires_at > '2001', 'escalated contact gets a fresh lifespan');
  assert.strictEqual(contacts.get(f.id).status, 'faded', 'non-unknown contacts just fade');
  assert.ok(postsTo('threat') >= threatPosts + 2);
  assert.strictEqual(db.prepare("SELECT COUNT(*) n FROM event_log WHERE event_type='contact_escalated'").get().n, 1);
  ok('expiry: unknown contact is reclassified (event logged), others fade');

  const u2 = contacts.create(G, { callsign: 'TRK-0003', iff: 'unknown', classification: 'bomber', bearing: 1, range_nm: 50, altitude_ft: 30000, heading: 1, speed_kt: 400, expires_at: '2000-01-01 00:00:00' });
  await threat.tickGuild(client, G, { nowMs: t0 + 130_000, rng: () => 0.9, state: tst });
  assert.strictEqual(contacts.get(u2.id).status, 'faded');
  ok('expiry: unidentified contact can simply fade');

  console.log(`\n${n} checks passed`);
})().catch((e) => { console.error('\nFAILED:', e); process.exit(1); });
