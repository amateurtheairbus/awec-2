// /force wings edit and /force squadrons edit.
process.env.DB_PATH = ':memory:';
const assert = require('assert');
require('../src/db/migrate')();

const db = require('../src/db/index');
const tags = require('../src/db/repos/tags');
const pilots = require('../src/db/repos/pilots');
const orgRepo = require('../src/db/repos/org');
const roster = require('../src/services/roster');
const force = require('../src/commands/force/force.js');
const onboardCmd = require('../src/commands/onboard/onboard.js');

// ---------- fakes ----------
const sent = []; const msgs = new Map(); let seq = 0;
function mk() { const id = `m${++seq}`; const m = { id, delete: async () => { msgs.delete(id); } }; msgs.set(id, m); return m; }
function chan(id) { return { id, isTextBased: () => true, send: async (p) => { const m = mk(); sent.push({ channel: id, payload: p, id: m.id }); return m; }, messages: { fetch: async (mid) => { const m = msgs.get(mid); if (!m) throw new Error('Unknown Message'); return m; } } }; }
const chans = Object.fromEntries(['chW', 'chW2', 'chW3'].map((id) => [id, chan(id)]));
const client = { channels: { fetch: async (id) => chans[id] ?? null } };
const postsIn = (c) => sent.filter((s) => s.channel === c);

const ROLE_IDS = ['3001', '3002', '3003', '3004', '4001', '4002', '4003', '4004'];
const MEMBER_IDS = ['w1', 'w2', 'sc', 'u1', 'u2', 'u3', 'u4', 'u5', 'u6'];
const roles = new Map(ROLE_IDS.map((id) => [id, { id, name: `role-${id}` }]));
const held = new Map(MEMBER_IDS.map((id) => [id, new Set()]));
const failRemove = new Set();
const guild = {
  roles: { cache: roles },
  members: {
    me: { permissions: { has: () => true } },
    fetch: async (id) => {
      if (!held.has(id)) throw new Error('Unknown Member');
      const set = held.get(id);
      return { id, roles: { cache: { has: (r) => set.has(r) }, add: async (r) => { set.add(r); }, remove: async (r) => { if (failRemove.has(r)) throw new Error('Missing Permissions'); set.delete(r); } } };
    },
  },
};
const G = 'g1';
const okCh = (id) => ({ id, permissionsFor: () => ({ has: () => true }) });
const noCh = (id) => ({ id, permissionsFor: () => ({ has: () => false }) });
const U = (id) => ({ id, bot: false });
const R = (id) => ({ id, name: `role-${id}`, mentionable: true });

async function run(cmd, { group = null, sub = null, opts = {}, admin = false, controller = false }) {
  const replies = [];
  await cmd.execute({
    guildId: G, guild, client, user: { id: 'adm', tag: 'adm' }, memberPermissions: { has: () => admin },
    member: { roles: { cache: { some: (fn) => controller && fn({ name: 'AEW&C Controller' }) } } },
    options: {
      getSubcommandGroup: () => group, getSubcommand: () => sub,
      getString: (k) => opts[k] ?? null, getInteger: (k) => opts[k] ?? null, getBoolean: (k) => opts[k] ?? null,
      getNumber: (k) => opts[k] ?? null, getUser: (k) => opts[k] ?? null, getRole: (k) => opts[k] ?? null, getChannel: (k) => opts[k] ?? null,
    },
    reply: async (p) => { replies.push(p); }, deferReply: async () => {}, followUp: async (p) => { replies.push(p); },
    editReply: async (p) => { replies.push(typeof p === 'string' ? { content: p } : p); },
  });
  return replies.map((r) => r.content ?? '').join('\n');
}
const wingEdit = (opts, who = { admin: true }) => run(force, { group: 'wings', sub: 'edit', ...who, opts });
const sqEdit = (opts, who = { admin: true }) => run(force, { group: 'squadrons', sub: 'edit', ...who, opts });
const roleSet = (id) => [...held.get(id)].sort().join(',');
const cs = (id) => orgRepo.assignmentOf(G, id).callsign;
const wingRow = (name) => orgRepo.getWing(G, name);
const sqRow = (name) => orgRepo.getSquadron(G, name);

(async () => {
  let n = 0; const ok = (m) => { console.log(`  ✓ ${m}`); n++; };
  roster.configure({ debounce: 3_600_000 });

  // ---------- world ----------
  for (const [d, id] of [['w1', '900'], ['w2', '901'], ['sc', '902']]) pilots.register(G, d, id, 'adm');
  await run(force, { group: 'wings', sub: 'create', admin: true, opts: { wing_name: '1st wing', wingcom: U('w1'), wing_role: R('4001'), member_channel: okCh('chW'), force_tag: 'saaf' } });
  await run(force, { group: 'squadrons', sub: 'create', admin: true, opts: { squad_name: 'Cobra Squadron', callsign: 'cobra', pilots: 4, squadron_role: R('3002'), squadcom: U('sc'), parent_wing: '1st wing' } });
  await run(force, { group: 'wings', sub: 'create', admin: true, opts: { wing_name: '2nd wing', wingcom: U('w2'), wing_role: R('4002'), member_channel: okCh('chW2'), force_tag: 'saafb' } });
  await run(force, { group: 'squadrons', sub: 'create', admin: true, opts: { squad_name: 'Leopard', callsign: 'leopard', pilots: 4, squadron_role: R('3001') } });
  const onboard = (user, squadron, geofs) => run(onboardCmd, { controller: true, opts: { user: U(user), squadron, geofs_id: geofs } });
  await onboard('u1', 'COBRA SQUADRON', '101'); await onboard('u2', 'COBRA SQUADRON', '102');
  await onboard('u3', 'LEOPARD', '103'); await onboard('u4', 'LEOPARD', '104');
  held.get('u5').add('4001'); // an unrelated person who happens to hold the wing role: edits must not touch them
  assert.deepStrictEqual(['sc', 'w1', 'u1', 'u2'].map(cs), ['COBRA-1[SAAF]', 'COBRA-2[SAAF]', 'COBRA-3[SAAF]', 'COBRA-4[SAAF]']);
  assert.strictEqual(roleSet('u1'), '3002,4001');

  // ================= wings edit: validation =================
  assert.match(await wingEdit({ wing: '1st wing', wing_name: 'X' }, {}), /requires server admin/);
  assert.match(await wingEdit({ wing: 'nope', wing_name: 'X' }), /No wing by that name\. Wings: `1ST WING`, `2ND WING`/);
  assert.match(await wingEdit({ wing: '1st wing' }), /Nothing to change/);
  assert.match(await wingEdit({ wing: '1st wing', wing_name: '!!' }), /Invalid wing name/);
  assert.match(await wingEdit({ wing: '1st wing', force_tag: '!!' }), /Invalid force tag/);
  assert.match(await wingEdit({ wing: '1st wing', wingcom: { id: 'bot', bot: true } }), /bot can't be wing commander/);
  assert.match(await wingEdit({ wing: '1st wing', member_channel: noCh('chW3') }), /can't post in <#chW3>/);
  assert.match(await wingEdit({ wing: '1st wing', wing_name: '2nd wing' }), /already a wing called \*\*2ND WING\*\*/);
  assert.match(await wingEdit({ wing: '1st wing', wing_name: '1st wing', force_tag: 'saaf' }), /already has those settings — nothing changed/);
  assert.strictEqual(wingRow('1ST WING').channel_id, 'chW');
  ok('/force wings edit: admin only; unknown wing, empty edit, invalid input, duplicates, no-op all handled');

  // ================= wings edit: rename / tag / role / channel / wingcom =================
  await roster.flush(); const rosterBefore = postsIn('chW').length;
  let out = await wingEdit({ wing: '1st wing', wing_name: 'First Wing' });
  assert.match(out, /Updated wing \*\*FIRST WING\*\*:\n• Renamed \*\*1ST WING\*\* → \*\*FIRST WING\*\*/);
  assert.ok(wingRow('FIRST WING') && !wingRow('1ST WING'));
  await roster.flush();
  assert.strictEqual(postsIn('chW').length, rosterBefore + 1, 'the roster is re-posted after a rename');
  assert.match(postsIn('chW').at(-1).payload.embeds[0].data.title, /FIRST WING \[SAAF\]/);

  out = await wingEdit({ wing: 'first wing', force_tag: 'saafx' });
  assert.match(out, /Tag \[SAAF\] → \[SAAFX\]/); assert.match(out, /still a recognized tag/);
  assert.strictEqual(cs('u1'), 'COBRA-3[SAAFX]', 'callsigns follow the wing tag');
  assert.ok(tags.listByCategory(G).us.includes('SAAFX') && tags.listByCategory(G).us.includes('SAAF'), 'new tag registered as ours; the old one is kept until removed');
  await roster.flush();
  assert.match(postsIn('chW').at(-1).payload.embeds[0].data.description, /`COBRA-1\[SAAFX\]` — <@sc>/);
  ok('rename and tag change: callsigns/rosters follow, new tag becomes one of ours');

  out = await wingEdit({ wing: 'first wing', wing_role: R('4003') });
  assert.match(out, /Wing role <@&4001> → <@&4003> \(4 members moved\)/);
  for (const id of ['sc', 'w1', 'u1', 'u2']) assert.ok(held.get(id).has('4003') && !held.get(id).has('4001'), `${id}: wing role swapped`);
  assert.ok(held.get('u5').has('4001'), 'someone outside the wing keeps their role');
  assert.ok(held.get('u1').has('3002'), 'squadron role untouched');
  await roster.flush();
  assert.strictEqual(postsIn('chW').at(-1).payload.content, '<@&4003>', 'roster pings the NEW wing role');
  ok('wing role change: members move to the new role, the old one is removed, outsiders untouched, roster pings the new role');

  failRemove.add('4002');
  out = await wingEdit({ wing: '2nd wing', wing_role: R('4004') });
  assert.match(out, /Updated wing \*\*2ND WING\*\*/); assert.match(out, /Some roles couldn't be updated/); assert.match(out, /<@w2> \/ <@&4002>: couldn't remove it \(Missing Permissions\)/);
  assert.strictEqual(wingRow('2ND WING').role_id, '4004', 'the change still stands');
  failRemove.clear();
  ok('role-removal failures are reported while the edit still applies');

  const oldRoster = wingRow('FIRST WING').roster_message_id;
  assert.ok(oldRoster && msgs.has(oldRoster));
  out = await wingEdit({ wing: 'first wing', member_channel: okCh('chW3') });
  assert.match(out, /Roster channel <#chW> → <#chW3>/);
  assert.strictEqual(msgs.has(oldRoster), false, 'the old roster message was deleted from the old channel');
  assert.strictEqual(wingRow('FIRST WING').channel_id, 'chW3');
  const w3Before = postsIn('chW3').length; await roster.flush();
  assert.strictEqual(postsIn('chW3').length, w3Before + 1, 'a fresh roster appears in the new channel');
  assert.match(postsIn('chW3').at(-1).payload.embeds[0].data.title, /FIRST WING/);
  ok('roster channel change: old post deleted, fresh roster posted in the new channel');

  out = await wingEdit({ wing: 'first wing', wingcom: U('u1') });
  assert.match(out, /Wingcom <@w1> → <@u1> → \*\*COBRA-2\[SAAFX\]\*\*; <@w1> is now COBRA-3\[SAAFX\]/);
  assert.deepStrictEqual(['sc', 'u1', 'w1', 'u2'].map(cs), ['COBRA-1[SAAFX]', 'COBRA-2[SAAFX]', 'COBRA-3[SAAFX]', 'COBRA-4[SAAFX]']);
  assert.strictEqual(orgRepo.assignmentOf(G, 'u1').commandsWing.name, 'FIRST WING');
  ok('wingcom change: new commander takes callsign-2, the old one is moved to a free slot');

  // all-or-nothing
  assert.match(await wingEdit({ wing: 'first wing', wing_name: 'Renamed Wing', force_tag: 'nope', wingcom: U('sc') }), /squadron commander; command roles are exclusive/);
  assert.strictEqual(wingRow('FIRST WING').force_tag, 'SAAFX'); assert.ok(!wingRow('RENAMED WING'), 'a refused edit changes NOTHING (name, tag untouched)');
  assert.match(await wingEdit({ wing: 'first wing', wing_name: '2nd wing', force_tag: 'zzz' }), /already a wing called/);
  assert.strictEqual(wingRow('FIRST WING').force_tag, 'SAAFX');
  assert.match(await wingEdit({ wing: 'first wing', wingcom: U('nobody') }), /isn't a registered pilot/);
  out = await wingEdit({ wing: 'first wing', wing_name: 'Alpha Wing', force_tag: 'alpha', wingcom: U('w1') });
  assert.match(out, /Renamed[^]*Tag \[SAAFX\] → \[ALPHA\][^]*Wingcom <@u1> → <@w1> → \*\*COBRA-2\[ALPHA\]\*\*; <@u1> is now COBRA-3\[ALPHA\]/);
  ok('wing edits are all-or-nothing; several fields can change in one call');

  // ================= squadrons edit: validation =================
  assert.match(await sqEdit({ squadron: 'cobra squadron', squad_name: 'X' }, {}), /requires server admin/);
  assert.match(await sqEdit({ squadron: 'nope', squad_name: 'X' }), /No squadron by that name\. Squadrons: `COBRA SQUADRON`, `LEOPARD`/);
  assert.match(await sqEdit({ squadron: 'cobra squadron' }), /Nothing to change/);
  assert.match(await sqEdit({ squadron: 'cobra squadron', squad_name: '!!' }), /Invalid squadron name/);
  assert.match(await sqEdit({ squadron: 'cobra squadron', callsign: 'CO-BRA' }), /Invalid callsign/);
  assert.match(await sqEdit({ squadron: 'cobra squadron', squad_name: 'leopard' }), /already a squadron called \*\*LEOPARD\*\*/);
  assert.match(await sqEdit({ squadron: 'cobra squadron', callsign: 'leopard' }), /callsign \*\*LEOPARD\*\* is already used/);
  assert.match(await sqEdit({ squadron: 'cobra squadron', squadcom: { id: 'bot', bot: true } }), /bot can't be squadron commander/);
  assert.match(await sqEdit({ squadron: 'cobra squadron', parent_wing: 'nope' }), /No wing by that name/);
  assert.match(await sqEdit({ squadron: 'cobra squadron', squad_name: 'cobra squadron', pilots: 4 }), /already has those settings/);
  ok('/force squadrons edit: admin only; unknown squadron, empty edit, invalid/duplicate input, no-op all handled');

  // ================= squadrons edit: rename + callsign =================
  out = await sqEdit({ squadron: 'cobra squadron', squad_name: 'King Squadron', callsign: 'king' });
  assert.match(out, /Renamed \*\*COBRA SQUADRON\*\* → \*\*KING SQUADRON\*\*/); assert.match(out, /Callsign \*\*COBRA\*\* → \*\*KING\*\* — slots are now KING-1\[ALPHA\] … KING-4\[ALPHA\]; pilots keep their numbers/);
  assert.deepStrictEqual(['sc', 'w1', 'u1', 'u2'].map(cs), ['KING-1[ALPHA]', 'KING-2[ALPHA]', 'KING-3[ALPHA]', 'KING-4[ALPHA]']);
  await roster.flush();
  assert.match(postsIn('chW3').at(-1).payload.embeds[0].data.description, /KING SQUADRON[^]*`KING-3\[ALPHA\]` — <@u1>/);
  ok('squadron rename + callsign change: pilots keep their slot numbers under the new callsign; roster refreshed');

  // ================= squadrons edit: slots =================
  out = await sqEdit({ squadron: 'king squadron', pilots: 6 });
  assert.match(out, /Slots 4 → 6/); assert.strictEqual(sqRow('KING SQUADRON').slots, 6);
  await onboard('u5', 'KING SQUADRON', '105'); await onboard('u6', 'KING SQUADRON', '106');
  assert.deepStrictEqual([cs('u5'), cs('u6')], ['KING-5[ALPHA]', 'KING-6[ALPHA]']);
  assert.match(await sqEdit({ squadron: 'king squadron', pilots: 4 }), /has 6 pilots, so it can't shrink to 4 slots/);
  assert.strictEqual(sqRow('KING SQUADRON').slots, 6, 'refused shrink changes nothing');
  await run(force, { group: 'squadrons', sub: 'assign', controller: true, opts: { pilot: U('u2'), squadron: 'leopard' } });   // KING-4 -> LEOPARD-3
  await run(force, { group: 'squadrons', sub: 'assign', controller: true, opts: { pilot: U('u6'), squadron: 'leopard' } });   // KING-6 -> LEOPARD-4
  assert.deepStrictEqual([cs('u2'), cs('u6'), cs('u5')], ['LEOPARD-3', 'LEOPARD-4', 'KING-5[ALPHA]']);
  out = await sqEdit({ squadron: 'king squadron', pilots: 4 });
  assert.match(out, /Slots 6 → 4\n {2}Moved: <@u5> KING-5\[ALPHA\] → KING-4\[ALPHA\]/);
  assert.strictEqual(cs('u5'), 'KING-4[ALPHA]'); assert.strictEqual(sqRow('KING SQUADRON').slots, 4);
  assert.match(await sqEdit({ squadron: 'king squadron', pilots: 3 }), /has 4 pilots, so it can't shrink to 3 slots/);
  ok('slots: grow; refuse to shrink below the pilot count; shrinking relocates pilots from removed slots to the lowest free ones');

  // ================= squadrons edit: role =================
  out = await sqEdit({ squadron: 'king squadron', squadron_role: R('3003') });
  assert.match(out, /Squadron role <@&3002> → <@&3003> \(4 members moved\)/);
  for (const id of ['sc', 'w1', 'u1', 'u5']) assert.ok(held.get(id).has('3003') && !held.get(id).has('3002'), `${id}: squadron role swapped`);
  assert.ok(held.get('u3').has('3001') && !held.get('u3').has('3003'), 'another squadron is untouched');
  ok('squadron role change moves its members to the new role and removes the old one');

  // ================= squadrons edit: squadcom =================
  out = await sqEdit({ squadron: 'king squadron', squadcom: U('u5') });
  assert.match(out, /Squadcom <@u5> → \*\*KING-1\[ALPHA\]\*\*; previous commander <@sc> is now \*\*KING-4\[ALPHA\]\*\*/);
  assert.deepStrictEqual([cs('u5'), cs('sc')], ['KING-1[ALPHA]', 'KING-4[ALPHA]']);
  assert.match(await sqEdit({ squadron: 'king squadron', squadcom: U('w1') }), /wing commander of ALPHA WING; command roles are exclusive/);
  assert.match(await sqEdit({ squadron: 'king squadron', squad_name: 'Zed', squadcom: U('w1') }), /command roles are exclusive/);
  assert.strictEqual(sqRow('KING SQUADRON').name, 'KING SQUADRON', 'refused edit changed nothing');
  ok('squadcom change takes callsign-1 and bumps the old commander; exclusivity and all-or-nothing hold');

  // ================= squadrons edit: parent wing =================
  const leopard = () => sqRow('LEOPARD');
  assert.match(await sqEdit({ squadron: 'leopard', parent_wing: '2nd wing' }), /LEOPARD is full — there's no room to move <@u4> aside/);
  assert.strictEqual(leopard().wing_id, null, 'refused: nothing nested');
  out = await sqEdit({ squadron: 'leopard', pilots: 5, parent_wing: '2nd wing' });
  assert.match(out, /Slots 4 → 5/); assert.match(out, /Nested in \*\*2ND WING\*\* \[SAAFB\]; wingcom <@w2> → \*\*LEOPARD-2\[SAAFB\]\*\*/);
  assert.strictEqual(cs('w2'), 'LEOPARD-2[SAAFB]'); assert.strictEqual(cs('u4'), 'LEOPARD-5[SAAFB]', 'bumped to the slot added by the same edit');
  const w2role = wingRow('2ND WING').role_id;
  for (const id of ['u3', 'u4', 'u2', 'u6', 'w2']) assert.ok(held.get(id).has(w2role), `${id} has the new wing's role`);
  assert.match(await sqEdit({ squadron: 'leopard', parent_wing: '2nd wing' }), /already has those settings/);
  ok('parent_wing: nests the squadron (wingcom seated, roles/callsign tags follow); resize + nest in one call; same wing is a no-op');

  // moving a wing's FIRST squadron out releases its wingcom's seat
  out = await sqEdit({ squadron: 'king squadron', parent_wing: '2nd wing' });
  assert.match(out, /Nested in \*\*2ND WING\*\* \[SAAFB\] \(was in ALPHA WING\)/);
  assert.strictEqual(orgRepo.assignmentOf(G, 'w1').squadron, null, 'w1 lost KING-2: ALPHA WING has no squadron left');
  assert.strictEqual(orgRepo.getWing(G, 'ALPHA WING').wingcom_id, 'w1', 'but is still its commander');
  assert.deepStrictEqual(orgRepo.squadronsInWing(wingRow('2ND WING').id).map((s) => s.name), ['LEOPARD', 'KING SQUADRON']);
  assert.ok(held.get('u1').has(w2role) && !held.get('u1').has('4003'), 'KING members swap to wing 2 role');
  ok('moving the first squadron out of a wing releases that wing\'s commander seat');

  // a roster post happened for the affected wing(s)
  await roster.flush();
  assert.ok(postsIn('chW2').length >= 1 && /LEOPARD-1\[SAAFB\]/.test(postsIn('chW2').at(-1).payload.embeds[0].data.description));
  ok('rosters refresh after squadron edits');

  console.log(`\n${n} checks passed`);
})().catch((e) => { console.error('\nFAILED:', e); process.exit(1); });
