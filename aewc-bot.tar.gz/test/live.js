// Callsign normalization, tag categories, /tags, live contacts + scrambles, bullseye display, config.
process.env.DB_PATH = ':memory:';
const assert = require('assert');
const { execFileSync } = require('child_process');
const os = require('os'); const path = require('path'); const fs = require('fs');
require('../src/db/migrate')();

const db = require('../src/db/index');
const config = require('../src/db/repos/config');
const tags = require('../src/db/repos/tags');
const pilots = require('../src/db/repos/pilots');
const patrols = require('../src/db/repos/patrols');
const contacts = require('../src/db/repos/contacts');
const geofs = require('../src/services/geofs');
const format = require('../src/services/format');
const picture = require('../src/services/picture');
const presence = require('../src/loops/presencePoller');
const { normalizeCallsign } = require('../src/util/callsign');

// ---- fake Discord ----
const sent = []; const msgs = new Map(); let seq = 0;
function mk() { const id = `m${++seq}`; const m = { id, edit: async () => m, delete: async () => msgs.delete(id) }; msgs.set(id, m); return m; }
function chan(id) { return { id, isTextBased: () => true, send: async (p) => { mk(); sent.push({ channel: id, payload: p }); return mk(); }, messages: { fetch: async (mid) => { const m = msgs.get(mid); if (!m) throw new Error('Unknown Message'); return m; } } }; }
const chans = { pic: chan('pic'), threat: chan('threat'), patrol: chan('patrol'), intel: chan('intel') };
const client = { channels: { fetch: async (id) => chans[id] ?? null } };
const posts = (c) => sent.filter((s) => s.channel === c);
const titleOf = (s) => s.payload.embeds[0].data.title;
const descOf = (s) => s.payload.embeds[0].data.description;

// Players as the real client builds them (raw /map entry -> normalizeUser), so callsigns are upper-cased.
const U = (acid, cs, { lat = 25.2, lon = 55.3, alt = 3000, hdg = 90, as = 400 } = {}) =>
  geofs.normalizeUser({ id: `s${acid}`, acid, cs, co: [lat, lon, alt, hdg, 0, 0], st: { as } });

const G = 'g1'; const G2 = 'g2';

(async () => {
  let n = 0; const ok = (m) => { console.log(`  ✓ ${m}`); n++; };

  // ================= normalization =================
  assert.strictEqual(normalizeCallsign('  leopard-2[h7t][saaf] '), 'LEOPARD-2[H7T][SAAF]');
  assert.strictEqual(normalizeCallsign('Eagle［frnd］'), 'EAGLE[FRND]', 'full-width brackets folded');
  assert.strictEqual(normalizeCallsign('SA\u200BAF  x'), 'SAAF X', 'zero-width chars stripped, spaces collapsed');
  assert.strictEqual(normalizeCallsign(null), '');
  assert.strictEqual(normalizeCallsign(normalizeCallsign('a b')), normalizeCallsign('a b'), 'idempotent');
  assert.strictEqual(U('1', 'viper-1[k9x][ruaf]').callsign, 'VIPER-1[K9X][RUAF]', 'feed callsigns are upper-cased at the source');
  assert.strictEqual(U('1', 'x', { as: 350 }).speedKt, 350);
  ok('callsigns are normalized to ALL CAPS (and look-alike/invisible characters folded) before anything else');

  // ================= tag categories =================
  assert.deepStrictEqual(tags.add(G, 'SAAF', 'a', 'us'), { status: 'added' });
  tags.add(G, 'FRND', 'a', 'friendly'); tags.add(G, 'RUAF', 'a', 'hostile');
  assert.deepStrictEqual(tags.add(G, 'FRND', 'a', 'friendly'), { status: 'unchanged' });
  assert.deepStrictEqual(tags.listByCategory(G), { us: ['SAAF'], friendly: ['FRND'], hostile: ['RUAF'] });
  assert.strictEqual(tags.parseCallsign(G, 'viper-1[k9x][ruaf]').category, 'hostile');
  assert.strictEqual(tags.parseCallsign(G, 'Eagle[frnd]').category, 'friendly');
  assert.strictEqual(tags.parseCallsign(G, 'x[SaAf]').category, 'us');
  assert.strictEqual(tags.parseCallsign(G, 'Cessna'), null);
  assert.strictEqual(tags.parseCallsign(G, 'FAKE[SAAF][RUAF]').category, 'hostile', 'hostile beats us — a hostile tag cannot hide behind ours');
  assert.strictEqual(tags.parseCallsign(G, 'FAKE[FRND][SAAF]').category, 'us', 'us beats friendly');
  assert.strictEqual(tags.parseCallsign(G, 'RU\u200BAF[x]'), null, 'a tag split by an invisible char is just folded, not matched twice');
  assert.strictEqual(tags.parseCallsign(G, 'A[RU\u200BAF]').category, 'hostile', 'invisible characters cannot be used to dodge a tag');
  assert.deepStrictEqual(tags.add(G, 'FRND', 'a', 'hostile'), { status: 'moved', from: 'friendly' });
  tags.add(G, 'FRND', 'a', 'friendly');
  ok('tag categories: add/move/unchanged, hostile > us > friendly, case- and evasion-proof recognition');

  // ================= /tags command =================
  const tagsCmd = require('../src/commands/tags/tags.js');
  const runTags = async ({ group = null, sub, tagsStr, controller = true, admin = false, guild = G2 }) => {
    const replies = [];
    const i = {
      guildId: guild, user: { id: 'ctl' },
      memberPermissions: { has: () => admin },
      member: { roles: { cache: { some: (fn) => controller && fn({ name: 'AEW&C Controller' }) } } },
      options: { getSubcommand: () => sub, getSubcommandGroup: () => group, getString: () => tagsStr },
      reply: async (p) => { replies.push(p); },
    };
    await tagsCmd.execute(i);
    return replies.map((r) => r.content).join('\n');
  };
  assert.match(await runTags({ group: 'add', sub: 'us', tagsStr: 'SAAF', controller: false }), /requires the \*\*AEW&C Controller\*\*/);
  assert.match(await runTags({ sub: 'remove', tagsStr: 'SAAF', controller: false }), /requires the/);
  assert.match(await runTags({ sub: 'list', controller: false }), /HOSTILE/, 'list is open to everyone');

  let out = await runTags({ group: 'add', sub: 'us', tagsStr: 'SAAF, [uaeaf]  usaf' });
  assert.match(out, /Added to \*\*us\*\*/); assert.deepStrictEqual(tags.listByCategory(G2).us, ['SAAF', 'UAEAF', 'USAF']);
  out = await runTags({ group: 'add', sub: 'hostile', tagsStr: 'ruaf, !!!' });
  assert.match(out, /Added to \*\*hostile\*\*/); assert.match(out, /Ignored \(not a valid tag\): `!!!`/);
  assert.match(out, /No scramble role is set/, 'hostile tags warn when nobody would be pinged');
  out = await runTags({ group: 'add', sub: 'friendly', tagsStr: 'RUAF USAF' });
  assert.match(out, /Moved to \*\*friendly\*\*: `\[RUAF\]` \(was hostile\), `\[USAF\]` \(was us\)/);
  out = await runTags({ group: 'add', sub: 'friendly', tagsStr: 'ruaf' });
  assert.match(out, /Already \*\*friendly\*\*/);
  config.setScrambleRole(G2, 'SCR');
  assert.ok(!/No scramble role/.test(await runTags({ group: 'add', sub: 'hostile', tagsStr: 'xyz' })), 'no warning once a scramble role exists');
  out = await runTags({ sub: 'remove', tagsStr: 'xyz nope' });
  assert.match(out, /Removed: `\[XYZ\]`/); assert.match(out, /Not in the list: `\[NOPE\]`/);
  out = await runTags({ sub: 'list' });
  assert.match(out, /US \(our force[^]*SAAF[^]*FRIENDLY[^]*RUAF[^]*HOSTILE/);
  assert.match(await runTags({ group: 'add', sub: 'us', tagsStr: '!!! ???' }), /No valid tags/);
  assert.match(await runTags({ group: 'add', sub: 'us', tagsStr: Array.from({ length: 21 }, (_, i) => `T${i}`).join(',') }), /Too many tags/);
  ok('/tags add us|friendly|hostile, remove, list: multi-tag parsing, moves, warnings, gating');

  // ================= live contacts + scramble =================
  config.setChannels(G, { picture: 'pic', threatLog: 'threat', patrolLog: 'patrol', intel: 'intel' });
  config.setScrambleRole(G, 'SCR');
  pilots.register(G, 'p1', '2018929', 'a');
  pilots.register(G, 'p2', '3000', 'a');
  const st = presence.newState();
  const run = (players, nowUnix) => presence.processGuild(client, G, players, { nowUnix: nowUnix ?? Math.floor(Date.now() / 1000), state: st });

  const players = () => [
    U('500', 'viper-1[k9x][ruaf]', { lat: 25.2, lon: 55.3 }),   // hostile
    U('600', 'Eagle[frnd]'),                                     // friendly
    U('700', 'Cessna 172'),                                      // no tag -> nothing
    U('2018929', 'leopard-2[h7t][saaf]'),                        // us + registered -> patrol, NOT a contact
    U('3000', 'Wingman[frnd]'),                                  // registered, but flying a FRIENDLY tag -> no patrol
  ];
  await run(players());

  const live = contacts.listLive(G);
  assert.deepStrictEqual(live.map((c) => c.callsign).sort(), ['EAGLE[FRND]', 'VIPER-1[K9X][RUAF]', 'WINGMAN[FRND]']);
  assert.ok(live.every((c) => c.source === 'live' && c.geofs_id));
  assert.strictEqual(live.find((c) => c.geofs_id === '500').iff, 'hostile');
  assert.strictEqual(live.find((c) => c.geofs_id === '600').iff, 'friendly');
  ok('players under friendly/hostile tags become live contacts named by their ALL-CAPS callsign');

  assert.ok(patrols.getOpenForUser(G, 'p1'), 'our-force pilot still gets a patrol');
  assert.strictEqual(patrols.getOpenForUser(G, 'p1').aircraft, 'LEOPARD-2', 'patrol unit name is upper-case');
  assert.strictEqual(patrols.getOpenForUser(G, 'p2'), undefined, 'friendly tag does not trigger a patrol');
  assert.ok(!live.some((c) => c.callsign.includes('SAAF')), 'our own pilots are patrols, not contacts');
  ok('patrols only for OUR tags; our pilots are never listed as contacts');

  const scrambles = posts('threat').filter((s) => titleOf(s) === 'SCRAMBLE');
  assert.strictEqual(scrambles.length, 1, 'exactly one scramble — for the hostile');
  assert.strictEqual(scrambles[0].payload.content, '<@&SCR>');
  assert.deepStrictEqual(scrambles[0].payload.allowedMentions.roles, ['SCR']);
  assert.match(descOf(scrambles[0]), /VIPER-1\[K9X\]\[RUAF\]/); assert.match(descOf(scrambles[0]), /500/);
  assert.strictEqual(posts('threat').filter((s) => s.payload.content).length, 1, 'only the scramble pings anyone');
  assert.ok(posts('threat').some((s) => titleOf(s) === 'CONTACT' && /EAGLE\[FRND\]/.test(descOf(s))), 'friendly is posted');
  ok('hostile -> SCRAMBLE with a scramble-role ping; friendly -> posted, no ping');

  const embed = picture.buildEmbed(G).toJSON();
  const contactsField = embed.fields.find((f) => f.name.startsWith('Contacts')).value;
  assert.ok(contactsField.indexOf('VIPER-1[K9X][RUAF]') < contactsField.indexOf('EAGLE[FRND]'), 'hostile listed first');
  assert.ok(!/TRK-/.test(contactsField));
  assert.match(contactsField, /25\.20N 55\.30E/, 'no bullseye -> coordinates');
  ok('picture lists real callsigns (hostile first), no TRK-####');

  // steady state: position updates, no new posts
  const threatBefore = posts('threat').length;
  await run([U('500', 'viper-1[k9x][ruaf]', { lat: 26.0, lon: 56.0, alt: 9000 }), U('600', 'Eagle[frnd]'), U('3000', 'Wingman[frnd]'), U('2018929', 'leopard-2[h7t][saaf]')]);
  assert.strictEqual(posts('threat').length, threatBefore, 'moving contacts are not re-announced');
  const moved = contacts.getLive(G, '500');
  assert.strictEqual(moved.lat, 26.0); assert.strictEqual(moved.altitude_ft, Math.round(9000 * 3.28084));
  assert.strictEqual(contacts.listLive(G).length, 3);
  ok('steady state: positions update silently, no duplicate contacts/scrambles');

  // hostile drops off -> fades; returns -> new contact + new scramble
  const rest = [U('600', 'Eagle[frnd]'), U('3000', 'Wingman[frnd]'), U('2018929', 'leopard-2[h7t][saaf]')];
  db.prepare("UPDATE contacts SET last_seen_at = datetime('now','-100 seconds') WHERE geofs_id = '500'").run();
  await run(rest);
  assert.ok(contacts.getLive(G, '500'), 'still on the picture inside the 3 min window');
  db.prepare("UPDATE contacts SET last_seen_at = datetime('now','-400 seconds') WHERE geofs_id = '500'").run();
  await run(rest);
  assert.strictEqual(contacts.getLive(G, '500'), undefined, 'faded once undetected for 3+ minutes');
  assert.match(descOf(posts('threat').pop()), /No longer detected/);
  const scrBefore = posts('threat').filter((s) => titleOf(s) === 'SCRAMBLE').length;
  await run(players());
  assert.strictEqual(posts('threat').filter((s) => titleOf(s) === 'SCRAMBLE').length, scrBefore + 1, 'a returning hostile scrambles again');
  ok('hostile fades after 3 min undetected; when it returns it is a new contact and scrambles again');

  // a tag changing category while the player is on the picture
  const sc2 = posts('threat').filter((s) => titleOf(s) === 'SCRAMBLE').length;
  tags.add(G, 'FRND', 'a', 'hostile');
  await run(players());
  assert.strictEqual(posts('threat').filter((s) => titleOf(s) === 'SCRAMBLE').length, sc2 + 2, 'both FRND players (600, 3000) now scramble');
  assert.strictEqual(contacts.getLive(G, '600').iff, 'hostile');
  assert.ok(posts('threat').some((s) => titleOf(s) === 'CONTACT UPGRADED'));
  tags.add(G, 'FRND', 'a', 'friendly');
  ok('re-categorizing a tag reclassifies live contacts (and scrambles if it became hostile)');

  // live contacts can't be cleared by hand (they would instantly come back)
  const contactCmd = require('../src/commands/contact/contact.js');
  const replies = [];
  await contactCmd.execute({
    guildId: G, client, user: { id: 'ctl' }, memberPermissions: { has: () => true },
    options: { getSubcommand: () => 'clear', getInteger: () => contacts.getLive(G, '600').id },
    reply: async (p) => replies.push(p), deferReply: async () => {}, editReply: async (p) => replies.push({ content: p }),
  });
  assert.match(replies[0].content, /live contact/); assert.ok(contacts.getLive(G, '600'));
  ok('/contact clear refuses live contacts (explains why)');

  // ================= bullseye rendering =================
  const base = { id: 7, source: 'live', callsign: 'TEST[RUAF]', iff: 'hostile', classification: 'unknown', lat: 0, lon: 1, altitude_ft: 32500, heading: 270, speed_kt: 450, bearing: 0, range_nm: 0 };
  assert.match(format.contactLine(base, { bullseye: { lat: 0, lon: 0 } }), /\*\*TEST\[RUAF\]\*\* · HOSTILE · BULL 090\/60 nm · FL325 · HDG 270 · 450 kt/);
  assert.match(format.contactLine({ ...base, lat: 1, lon: 0 }, { bullseye: { lat: 0, lon: 0 } }), /BULL 000\/60 nm/);
  assert.match(format.contactLine({ ...base, lat: -26.1, lon: -28.2 }, {}), /26\.10S 28\.20W/);
  assert.ok(!/ kt/.test(format.contactLine({ ...base, speed_kt: 0 }, {})), 'unknown speed is omitted for live contacts');
  assert.match(format.contactLine({ id: 1, source: 'sim', callsign: 'SIM-1234', iff: 'unknown', classification: 'fighter', bearing: 257, range_nm: 145, altitude_ft: 8500, heading: 12, speed_kt: 510 }), /SIM-1234\*\* · UNKNOWN FIGHTER · BRG 257\/145 nm · 8,500 ft · HDG 012 · 510 kt/);
  ok('contact lines: BULL bearing/range from the bullseye, coordinates without one, sim format unchanged');

  // ================= /aewc config + setup =================
  const aewc = require('../src/commands/aewc/aewc.js');
  const runAewc = async ({ sub, opts = {}, guild = G }) => {
    const replies = [];
    const i = {
      guildId: guild, client, user: { id: 'adm' }, memberPermissions: { has: () => true },
      guild: { members: { me: { permissions: { has: () => false } } } },
      options: {
        getSubcommand: () => sub, getSubcommandGroup: () => null,
        getString: (k) => opts[k] ?? null, getInteger: (k) => opts[k] ?? null, getBoolean: (k) => opts[k] ?? null,
        getNumber: (k) => opts[k] ?? null, getChannel: (k) => opts[k] ?? null, getRole: (k) => opts[k] ?? null,
      },
      reply: async (p) => { replies.push(p); }, deferReply: async () => {}, editReply: async (p) => { replies.push(typeof p === 'string' ? { content: p } : p); },
    };
    await aewc.execute(i);
    return replies.map((r) => r.content).join('\n');
  };
  assert.match(await runAewc({ sub: 'config', opts: { bullseye_lat: 25 } }), /together/);
  assert.match(await runAewc({ sub: 'config', opts: { bullseye_lat: 95, bullseye_lon: 10 } }), /between -90 and 90/);
  assert.match(await runAewc({ sub: 'config', opts: { bullseye_lat: 10, bullseye_lon: 190 } }), /between -180 and 180/);
  out = await runAewc({ sub: 'config', opts: { bullseye_lat: -26.1, bullseye_lon: 28.2, threat_sim: true } });
  assert.match(out, /Bullseye: -26\.1, 28\.2/); assert.match(out, /Simulated random contacts: on/);
  assert.strictEqual(config.get(G).bullseye_lat, -26.1); assert.strictEqual(config.get(G).threat_sim_enabled, 1);
  const withBull = picture.buildEmbed(G).toJSON().fields.find((f) => f.name.startsWith('Contacts')).value;
  assert.match(withBull, /BULL \d{3}\/\d+ nm/, 'picture switches to bearing/range once a bullseye is set');
  out = await runAewc({ sub: 'config', opts: { clear_bullseye: true, threat_sim: false } });
  assert.match(out, /not set/); assert.strictEqual(config.get(G).bullseye_lat, null); assert.strictEqual(config.get(G).threat_sim_enabled, 0);
  const okCh = (id) => ({ id, permissionsFor: () => ({ has: () => true }) });
  out = await runAewc({ sub: 'setup', guild: 'g3', opts: { picture_channel: okCh('pic'), threat_log_channel: okCh('threat'), patrol_log_channel: okCh('patrol'), scramble_role: { id: 'SCR3', mentionable: true } } });
  assert.match(out, /Scramble role: <@&SCR3>/); assert.strictEqual(config.get('g3').scramble_role_id, 'SCR3');
  assert.match(out, /\/tags add us/);
  assert.ok(!require('../src/commands/aewc/aewc.js').data.toJSON().options.some((o) => o.name === 'tags'), 'old /aewc tags is gone');
  ok('/aewc config (bullseye, sim toggle) and /aewc setup scramble_role work; /aewc tags removed');

  // ================= migration: shared scramble role =================
  const tmp = path.join(os.tmpdir(), `aewc-live-${process.pid}.db`); fs.rmSync(tmp, { force: true });
  const Database = require('better-sqlite3');
  const old = new Database(tmp);
  old.exec("CREATE TABLE bot_state (guild_id TEXT PRIMARY KEY, picture_channel_id TEXT, flightcode_scramble_role_id TEXT);" +
    "INSERT INTO bot_state VALUES ('o1','c','OLDROLE');" +
    "CREATE TABLE callsign_tags (guild_id TEXT NOT NULL, tag TEXT NOT NULL, added_by TEXT, added_at TEXT NOT NULL DEFAULT (datetime('now')), PRIMARY KEY (guild_id, tag));" +
    "INSERT INTO callsign_tags (guild_id, tag) VALUES ('o1','SAAF');");
  old.close();
  execFileSync(process.execPath, [path.join(__dirname, '..', 'src', 'db', 'migrate.js')], { env: { ...process.env, DB_PATH: tmp }, stdio: 'pipe' });
  const up = new Database(tmp);
  assert.strictEqual(up.prepare("SELECT scramble_role_id FROM bot_state WHERE guild_id='o1'").get().scramble_role_id, 'OLDROLE', 'old flight-code scramble role carried over');
  assert.strictEqual(up.prepare("SELECT category FROM callsign_tags WHERE tag='SAAF'").get().category, 'us', 'existing tags default to "us"');
  up.close(); fs.rmSync(tmp, { force: true });
  ok('existing DB upgrades: old tags become "us", flight-code scramble role carries over');

  console.log(`\n${n} checks passed`);
})().catch((e) => { console.error('\nFAILED:', e); process.exit(1); });
