// End-to-end smoke test: in-memory DB, fake Discord client, fake interactions.
// Run with: npm test
process.env.DB_PATH = ':memory:';
const assert = require('assert');
require('../src/db/migrate')();

const config = require('../src/db/repos/config');
const tags = require('../src/db/repos/tags');
const pilots = require('../src/db/repos/pilots');
const patrols = require('../src/db/repos/patrols');
const contacts = require('../src/db/repos/contacts');

const G = 'guild1';

// ---- fake Discord client: records every message sent/edited ----
const sent = [];
const edits = [];
const msgStore = new Map();
let msgSeq = 0;
function fakeChannel(id) {
  return {
    id,
    isTextBased: () => true,
    send: async (payload) => { const m = mkMsg(id, payload); sent.push({ channel: id, payload }); return m; },
    messages: { fetch: async (mid) => { const m = msgStore.get(mid); if (!m) throw new Error('Unknown Message'); return m; } },
  };
}
function mkMsg(channelId, payload) {
  const id = `m${++msgSeq}`;
  const m = {
    id,
    edit: async (p) => { edits.push({ id, payload: p }); return m; },
    delete: async () => { msgStore.delete(id); },
  };
  msgStore.set(id, m);
  return m;
}
const channels = { pic: fakeChannel('pic'), threat: fakeChannel('threat'), patrol: fakeChannel('patrol'), intel: fakeChannel('intel') };
const client = { channels: { fetch: async (id) => channels[id] ?? null } };

// ---- fake interaction builder ----
function interaction({ command, sub, group = null, opts = {}, userId = 'u1', admin = false, controller = false }) {
  const replies = [];
  const i = {
    guildId: G, client, commandName: command,
    inGuild: () => true,
    user: { id: userId, bot: false },
    memberPermissions: { has: () => admin },
    member: { roles: { cache: { some: (fn) => controller && fn({ name: 'AEW&C Controller' }) } } },
    guild: { members: { me: {} } },
    options: {
      getSubcommand: () => sub,
      getSubcommandGroup: () => group,
      getString: (k) => opts[k] ?? null,
      getInteger: (k) => opts[k] ?? null,
      getBoolean: (k) => opts[k] ?? null,
      getUser: (k) => opts[k] ?? null,
      getChannel: (k) => opts[k] ?? null,
    },
    deferred: false,
    reply: async (p) => { replies.push(p); },
    deferReply: async () => { i.deferred = true; },
    editReply: async (p) => { replies.push(typeof p === 'string' ? { content: p } : p); },
    followUp: async (p) => { replies.push(p); },
    _replies: replies,
  };
  return i;
}
const run = async (cmd, args) => {
  const i = interaction({ command: cmd, ...args });
  await require(`../src/commands/${cmd}/${cmd}.js`).execute(i);
  return i._replies.map((r) => r.content ?? JSON.stringify(r.embeds?.[0]?.data ?? r)).join('\n');
};

(async () => {
  let n = 0; const ok = (name) => console.log(`  ✓ ${name}`) || n++;

  // --- repos: tags
  assert.strictEqual(tags.normalize('[usaf]'), 'USAF');
  assert.strictEqual(tags.normalize('bad tag!'), null);
  tags.add(G, 'USAF', 'u1'); tags.add(G, 'UAEAF', 'u1');
  assert.strictEqual(tags.matchCallsign(G, '[USAF] Viper 1'), 'USAF');
  assert.strictEqual(tags.matchCallsign(G, '[uaeaf] Falcon'), 'UAEAF');
  assert.strictEqual(tags.matchCallsign(G, 'LEOPARD-2[H7T][UAEAF]'), 'UAEAF', 'tag at end, after an unrelated bracket');
  assert.strictEqual(tags.matchCallsign(G, 'Viper [USAF] 1'), 'USAF', 'tag mid-callsign');
  assert.strictEqual(tags.matchCallsign(G, 'Cessna [H7T]'), null, 'unconfigured bracket ignored');
  assert.strictEqual(tags.matchCallsign(G, '[CIV] Cessna'), null);
  assert.deepStrictEqual(tags.parseCallsign(G, 'LEOPARD-2[H7T][UAEAF]'), { tag: 'UAEAF', code: 'H7T', name: 'LEOPARD-2' }, 'flight code = bracket right before the tag');
  assert.deepStrictEqual(tags.parseCallsign(G, '[USAF] Viper 1'), { tag: 'USAF', code: null, name: 'Viper 1' });
  assert.strictEqual(tags.parseCallsign(G, 'Cessna [H7T]'), null);
  assert.strictEqual(tags.matchCallsign(G, 'USAF no brackets'), null);
  ok('tag normalize + callsign matching');

  // --- setup (admin only)
  let out = await run('aewc', { sub: 'setup', opts: {
    picture_channel: { id: 'pic', permissionsFor: () => ({ has: () => true }) },
    threat_log_channel: { id: 'threat', permissionsFor: () => ({ has: () => true }) },
    patrol_log_channel: { id: 'patrol', permissionsFor: () => ({ has: () => true }) },
  }});
  assert.match(out, /requires server admin/);
  out = await run('aewc', { sub: 'setup', admin: true, opts: {
    picture_channel: { id: 'pic', permissionsFor: () => ({ has: () => true }) },
    threat_log_channel: { id: 'threat', permissionsFor: () => ({ has: () => true }) },
    patrol_log_channel: { id: 'patrol', permissionsFor: () => ({ has: () => true }) },
    intel_channel: { id: 'intel', permissionsFor: () => ({ has: () => true }) },
  }});
  assert.match(out, /Configured/);
  assert.ok(config.get(G).picture_message_id, 'picture message created on setup');
  ok('/aewc setup gated + posts initial picture');

  // --- config validation
  out = await run('aewc', { sub: 'config', admin: true, opts: { threat_spawn_min_s: 5000, threat_spawn_max_s: 100 } });
  assert.match(out, /cannot exceed/);
  out = await run('aewc', { sub: 'config', admin: true, opts: { poll_interval_s: 1 } });
  assert.match(out, /must be between/);
  out = await run('aewc', { sub: 'config', admin: true, opts: { patrol_grace_period_s: 300 } });
  assert.match(out, /Updated/);
  ok('/aewc config validation');

  // --- pilots
  const target = { id: 'u2', bot: false };
  assert.match(await run('pilot', { sub: 'register', opts: { discord_user: target, geofs_id: '1001' } }), /requires server admin/);
  assert.match(await run('pilot', { sub: 'register', admin: true, opts: { discord_user: target, geofs_id: '1001' } }), /Registered/);
  assert.match(await run('pilot', { sub: 'register', admin: true, opts: { discord_user: { id: 'u3', bot: false }, geofs_id: '1001' } }), /already registered/);
  assert.match(await run('pilot', { sub: 'register', admin: true, opts: { discord_user: target, geofs_id: 'bad id!' } }), /numeric account IDs/);
  assert.strictEqual(pilots.getByGeofs(G, '1001').discord_id, 'u2');
  ok('/pilot register: gating, duplicate GeoFS ID, validation');

  // --- patrols
  const before = sent.length;
  out = await run('patrol', { sub: 'start', userId: 'u2', opts: { aircraft: 'F-16C' } });
  assert.match(out, /started/);
  assert.strictEqual(patrols.getOpenForUser(G, 'u2').geofs_id, '1001', 'manual patrol links roster GeoFS ID');
  assert.ok(sent.slice(before).some((s) => s.channel === 'patrol'), 'patrol start mirrored to patrol log');
  assert.ok(edits.length > 0, 'picture edited in place, not re-posted');
  out = await run('patrol', { sub: 'start', userId: 'u2', opts: { aircraft: 'F-15' } });
  assert.match(out, /already has an open patrol/);
  assert.match(await run('patrol', { sub: 'rtb', userId: 'u2' }), /marked RTB/);
  assert.match(await run('patrol', { sub: 'rtb', userId: 'u2' }), /already rtb/);
  assert.match(await run('patrol', { sub: 'end', userId: 'u2' }), /ended/);
  assert.strictEqual(patrols.getOpenForUser(G, 'u2'), undefined);
  assert.match(await run('patrol', { sub: 'end', userId: 'u2' }), /no open patrol/);
  assert.match(await run('patrol', { sub: 'history', userId: 'u2', opts: {} }), /Patrol history/);
  ok('/patrol lifecycle: start → duplicate blocked → rtb → end → history');

  // --- contacts
  assert.match(await run('contact', { sub: 'spawn' }), /requires the \*\*AEW&C Controller\*\*/);
  out = await run('contact', { sub: 'spawn', controller: true, opts: { iff: 'hostile', classification: 'bomber' } });
  assert.match(out, /Injected contact #1/);
  const c1 = contacts.get(1);
  assert.strictEqual(c1.iff, 'hostile'); assert.strictEqual(c1.classification, 'bomber');
  assert.ok(c1.bearing >= 0 && c1.bearing <= 359 && c1.range_nm >= 20);
  assert.match(await run('contact', { sub: 'list' }), /TRK-\d{4}/);
  assert.match(await run('contact', { sub: 'clear', controller: true, opts: { id: 1 } }), /Cleared contact #1/);
  assert.match(await run('contact', { sub: 'clear', controller: true, opts: { id: 1 } }), /not active/);
  assert.match(await run('contact', { sub: 'clear', controller: true, opts: { id: 999 } }), /No contact/);
  assert.strictEqual(contacts.countActive(G), 0);
  ok('/contact spawn/list/clear: gating + attribute bands + double-clear safe');

  // --- intel
  assert.match(await run('intel', { sub: 'list' }), /requires the \*\*AEW&C Controller\*\*/);
  const b = sent.length;
  assert.match(await run('intel', { sub: 'add', controller: true, opts: { geofs_id: '5555', notes: 'Suspicious', alert_on_sighting: false } }), /Added `5555` — alerts off/);
  assert.ok(sent.slice(b).some((s) => s.channel === 'intel'), 'intel events go to intel channel');
  assert.match(await run('intel', { sub: 'alerts', controller: true, opts: { geofs_id: '5555', on: true } }), /turned on/);
  assert.match(await run('intel', { sub: 'lookup', controller: true, opts: { geofs_id: '5555' } }), /Suspicious/);
  assert.match(await run('intel', { sub: 'remove', controller: true, opts: { geofs_id: '5555' } }), /Removed/);
  assert.match(await run('intel', { sub: 'remove', controller: true, opts: { geofs_id: '5555' } }), /not on the watchlist/);
  ok('/intel add/alerts/lookup/remove: gating + routing to intel channel');

  // --- picture survives the message being deleted
  msgStore.delete(config.get(G).picture_message_id);
  const sentBefore = sent.length;
  await run('contact', { sub: 'spawn', controller: true });
  assert.ok(sent.slice(sentBefore).some((s) => s.channel === 'pic'), 'picture re-posted after deletion');
  ok('picture self-heals when its message is deleted');

  // --- airspace
  assert.match(await run('airspace', { sub: 'refresh' }), /requires the \*\*AEW&C Controller\*\*/);
  assert.match(await run('airspace', { sub: 'refresh', controller: true }), /regenerated/);
  assert.match(await run('airspace', { sub: 'status' }), /AEW&C AIRSPACE PICTURE/);
  ok('/airspace status + refresh');

  console.log(`\n${n} checks passed`);
})().catch((e) => { console.error('\nFAILED:', e); process.exit(1); });
