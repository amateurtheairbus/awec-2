// Flight-code verification tests: generation, rotation, verification rules, throttling, commands, migration.
process.env.DB_PATH = ':memory:';
const assert = require('assert');
const { execFileSync } = require('child_process');
const os = require('os'); const path = require('path'); const fs = require('fs');
require('../src/db/migrate')();

const db = require('../src/db/index');
const config = require('../src/db/repos/config');
const tags = require('../src/db/repos/tags');
const pilots = require('../src/db/repos/pilots');
const fc = require('../src/services/flightcode');
const rotator = require('../src/loops/flightCodeRotator');
const presence = require('../src/loops/presencePoller');
const repo = require('../src/db/repos/flightcode');

// ---- fake Discord ----
const sent = []; const msgs = new Map(); let seq = 0;
function mk(channelId) { const id = `m${++seq}`; const m = { id, channelId, deleted: false, delete: async () => { m.deleted = true; msgs.delete(id); } }; msgs.set(id, m); return m; }
function chan(id) { return { id, isTextBased: () => true, send: async (p) => { const m = mk(id); sent.push({ channel: id, payload: p, id: m.id }); return m; }, messages: { fetch: async (mid) => { const m = msgs.get(mid); if (!m) throw new Error('Unknown Message'); return m; } } }; }
const chans = { codes: chan('codes'), alerts: chan('alerts'), pic: chan('pic') };
const client = { channels: { fetch: async (id) => chans[id] ?? null } };
const posts = (c) => sent.filter((s) => s.channel === c);
const lastPayload = (c) => posts(c).pop().payload;
const desc = (p) => p.embeds[0].data.description;

const G = 'g1';
const P = (geofsId, callsign) => ({ geofsId, callsign, lat: -26.1, lon: 28.2, altitudeM: 3000 });

(async () => {
  let n = 0; const ok = (m) => { console.log(`  ✓ ${m}`); n++; };

  // ---------- generation ----------
  for (let i = 0; i < 300; i++) {
    assert.match(fc.generateCode('alnum', 3), /^[A-Z0-9]{3}$/);
    assert.match(fc.generateCode('letters', 4), /^[A-Z]{4}$/);
    assert.match(fc.generateCode('numbers', 5), /^[0-9]{5}$/);
  }
  const big = Array.from({ length: 400 }, () => fc.generateCode('alnum', 3)).join('');
  assert.ok(/[A-Z]/.test(big) && /[0-9]/.test(big), 'alnum uses both letters and digits');
  assert.throws(() => fc.generateCode('emoji', 3), /Unknown charset/);
  ok('code generation honors charset and length');

  // ---------- validity + grace ----------
  const now = 2_000_000_000;
  const ts = (u) => new Date(u * 1000).toISOString().replace('T', ' ').slice(0, 19);
  const cfgA = { flightcode_current: 'ABC', flightcode_previous: 'XYZ', flightcode_rotated_at: ts(now - 100) };
  assert.ok(fc.isValidCode(cfgA, 'abc', now), 'case-insensitive');
  assert.ok(fc.isValidCode(cfgA, 'XYZ', now), 'previous code valid inside grace');
  assert.ok(!fc.isValidCode({ ...cfgA, flightcode_rotated_at: ts(now - 700) }, 'XYZ', now), 'previous code expires after 10 min');
  assert.ok(!fc.isValidCode(cfgA, null, now) && !fc.isValidCode(cfgA, 'NOPE', now));
  ok('validity: case-insensitive, previous code only inside the grace window, missing code invalid');

  // ---------- commands ----------
  const aewc = require('../src/commands/aewc/aewc.js');
  const run = async ({ sub, opts = {}, admin = true, guild = G }) => {
    const replies = [];
    const i = {
      guildId: guild, client, user: { id: 'adm' }, memberPermissions: { has: () => admin },
      guild: { members: { me: { permissions: { has: () => false } } } },
      options: {
        getSubcommand: () => sub, getSubcommandGroup: () => 'flightcode',
        getString: (k) => opts[k] ?? null, getInteger: (k) => opts[k] ?? null, getBoolean: (k) => opts[k] ?? null,
        getChannel: (k) => opts[k] ?? null, getRole: (k) => opts[k] ?? null,
      },
      reply: async (p) => { replies.push(p); }, deferReply: async () => {}, editReply: async (p) => { replies.push(typeof p === 'string' ? { content: p } : p); },
    };
    await aewc.execute(i);
    return replies.map((r) => r.content).join('\n');
  };
  const okCh = (id) => ({ id, permissionsFor: () => ({ has: () => true }) });
  const role = { id: 'ROLE1', mentionable: true };

  assert.match(await run({ sub: 'setup', admin: false, opts: { force_tag: 'SAAF', channel: okCh('codes'), scramble_role: role } }), /requires server admin/);
  assert.match(await run({ sub: 'setup', opts: { force_tag: 'bad tag!', channel: okCh('codes'), scramble_role: role } }), /Invalid force tag/);
  assert.match(await run({ sub: 'setup', opts: { force_tag: 'SAAF', channel: okCh('codes'), scramble_role: role, length: 99 } }), /length must be/i);
  assert.match(await run({ sub: 'setup', opts: { force_tag: 'SAAF', channel: { id: 'codes', permissionsFor: () => ({ has: () => false }) }, scramble_role: role } }), /can't post/);
  assert.match(await run({ sub: 'status' }), /off/);
  assert.match(await run({ sub: 'rotate' }), /aren't set up/);
  ok('/aewc flightcode: admin-gated, validates tag/length/permissions, status/rotate before setup');

  const setupOut = await run({ sub: 'setup', opts: { force_tag: '[saaf]', channel: okCh('codes'), scramble_role: role, alert_channel: okCh('alerts'), charset: 'letters', length: 4, interval_minutes: 60 } });
  assert.match(setupOut, /\[SAAF\]/); assert.match(setupOut, /Posted the first code/);
  let cfg = config.get(G);
  assert.strictEqual(cfg.flightcode_enabled, 1); assert.strictEqual(cfg.flightcode_force_tag, 'SAAF');
  assert.match(cfg.flightcode_current, /^[A-Z]{4}$/); assert.strictEqual(cfg.flightcode_interval_s, 3600);
  assert.ok(tags.list(G).includes('SAAF'), 'force tag auto-added to callsign tags');
  assert.strictEqual(posts('codes').length, 1);
  assert.match(desc(lastPayload('codes')), new RegExp(cfg.flightcode_current));
  assert.match(desc(lastPayload('codes')), /NAME\[[A-Z]{4}\]\[SAAF\]/);
  assert.strictEqual(db.prepare("SELECT COUNT(*) n FROM event_log WHERE event_type='flightcode_rotated'").get().n, 1);
  assert.ok(!db.prepare('SELECT detail FROM event_log').all().some((r) => r.detail && r.detail.includes(cfg.flightcode_current)), 'code never written to event_log');
  assert.match(await run({ sub: 'status' }), new RegExp(`\\\`${cfg.flightcode_current}\\\``));
  ok('setup stores config, adds the tag, posts the first code (never logs the code itself)');

  // ---------- rotation ----------
  const firstCode = cfg.flightcode_current; const firstMsg = cfg.flightcode_message_id;
  await run({ sub: 'rotate' });
  cfg = config.get(G);
  assert.notStrictEqual(cfg.flightcode_current, firstCode); assert.strictEqual(cfg.flightcode_previous, firstCode);
  assert.ok(msgs.get(firstMsg) === undefined, 'old code post deleted');
  assert.match(desc(lastPayload('codes')), /previous code is also accepted/);
  ok('manual rotate: previous code kept for grace, old post deleted');

  // failed post must not change anything
  const keep = config.get(G).flightcode_current;
  db.prepare("UPDATE bot_state SET flightcode_channel_id = 'ghost' WHERE guild_id = ?").run(G);
  await assert.rejects(fc.rotate(client, G), /channel not found/);
  assert.strictEqual(config.get(G).flightcode_current, keep, 'code unchanged when the post fails');
  db.prepare("UPDATE bot_state SET flightcode_channel_id = 'codes' WHERE guild_id = ?").run(G);
  ok('failed post leaves the live code untouched');

  // ---------- verification ----------
  pilots.register(G, 'p1', '2018929', 'adm');
  const code = config.get(G).flightcode_current; const prev = config.get(G).flightcode_previous;
  const alertsBefore = () => posts('alerts').length;

  let a0 = alertsBefore();
  await fc.verify(client, G, [
    P('2018929', `LEOPARD-2[${code}][SAAF]`),   // registered + correct
    P('900', `Friend[${prev}][SAAF]`),           // unregistered but previous code, inside grace -> allowed (non-strict)
    P('901', 'Viper[WRONG][USAF]'),              // different force: ignored
    P('902', 'Civilian'),                        // no tag: ignored
  ], { nowUnix: Math.floor(Date.now() / 1000) });
  assert.strictEqual(alertsBefore(), a0, 'compliant / out-of-scope players raise nothing');
  ok('verification ignores compliant players, other forces, untagged players; accepts previous code in grace');

  await fc.verify(client, G, [P('2018929', 'LEOPARD-2[ZZZZ][SAAF]')]);
  assert.strictEqual(alertsBefore(), a0 + 1);
  let pl = lastPayload('alerts');
  assert.strictEqual(pl.content, '<@p1>'); assert.deepStrictEqual(pl.allowedMentions.users, ['p1']);
  assert.match(desc(pl), /wrong flight code/); assert.ok(!desc(pl).includes(code), 'alert never echoes the live code');
  await fc.verify(client, G, [P('2018929', 'LEOPARD-2[ZZZZ][SAAF]')]);
  assert.strictEqual(alertsBefore(), a0 + 1, 'no repeat inside the cooldown');
  db.prepare("UPDATE flightcode_alerts SET last_alert_at = datetime('now','-4000 seconds')").run();
  await fc.verify(client, G, [P('2018929', 'LEOPARD-2[ZZZZ][SAAF]')]);
  assert.strictEqual(alertsBefore(), a0 + 2, 're-pings after an hour');
  ok('registered pilot, wrong code -> ping the pilot once, re-ping only after the cooldown');

  await fc.verify(client, G, [P('2018929', 'LEOPARD-2[SAAF]')]);   // missing code, but throttled by kind 'update'
  assert.strictEqual(alertsBefore(), a0 + 2);
  await fc.verify(client, G, [P('2018929', `LEOPARD-2[${code}][SAAF]`)]);   // fixes it
  assert.strictEqual(repo.countAlerts(G), 0, 'compliance clears the throttle');
  await fc.verify(client, G, [P('2018929', 'LEOPARD-2[SAAF]')]);
  assert.strictEqual(alertsBefore(), a0 + 3, 'a fresh mismatch after fixing alerts immediately');
  assert.match(desc(lastPayload('alerts')), /no flight code/);
  ok('fixing the callsign clears the throttle; a later mismatch alerts immediately (missing code worded correctly)');

  await fc.verify(client, G, [P('777', 'Rando[SAAF]')]);
  pl = lastPayload('alerts');
  assert.strictEqual(pl.content, '<@&ROLE1>'); assert.deepStrictEqual(pl.allowedMentions.roles, ['ROLE1']);
  assert.match(desc(pl), /IMPERSONATOR/); assert.match(desc(pl), /777/); assert.match(desc(pl), /not on the roster/);
  assert.match(desc(pl), /-26\.10, 28\.20/, 'includes last known position');
  ok('unregistered ID under the force tag with no/wrong code -> scramble role pinged, "IMPERSONATOR" printed');

  const a1 = alertsBefore();
  await fc.verify(client, G, [P('778', `Fake[${code}][SAAF]`)]);
  assert.strictEqual(alertsBefore(), a1, 'non-strict: valid code from an unregistered ID is not flagged');
  db.prepare("UPDATE bot_state SET flightcode_strict = 1 WHERE guild_id = ?").run(G);
  await fc.verify(client, G, [P('778', `Fake[${code}][SAAF]`)]);
  assert.strictEqual(alertsBefore(), a1 + 1, 'strict: flagged');
  assert.match(desc(lastPayload('alerts')), /valid flight code but is \*\*not on the roster/);
  db.prepare("UPDATE bot_state SET flightcode_strict = 0 WHERE guild_id = ?").run(G);
  ok('strict mode also flags unregistered players holding a valid code');

  // verification runs inside the presence poll
  const st = presence.newState(); const a2 = alertsBefore();
  await presence.processGuild(client, G, [P('555', 'Spy[SAAF]')], { state: st });
  assert.strictEqual(alertsBefore(), a2 + 1);
  db.prepare("UPDATE bot_state SET flightcode_enabled = 0 WHERE guild_id = ?").run(G);
  await presence.processGuild(client, G, [P('556', 'Spy2[SAAF]')], { state: st });
  assert.strictEqual(alertsBefore(), a2 + 1, 'disabled -> no verification');
  db.prepare("UPDATE bot_state SET flightcode_enabled = 1 WHERE guild_id = ?").run(G);
  ok('presence poll runs verification; disabling turns it off');

  // ---------- rotator loop ----------
  const rst = rotator.newState(); const codesBefore = posts('codes').length;
  await rotator.tickGuild(client, G, { nowMs: Date.now() + 10 * 60_000, state: rst });       // 10 min after last rotation, interval 60
  assert.strictEqual(posts('codes').length, codesBefore, 'not due yet');
  await rotator.tickGuild(client, G, { nowMs: Date.now() + 61 * 60_000, state: rst });
  assert.strictEqual(posts('codes').length, codesBefore + 1, 'rotates when the interval elapses');
  db.prepare("UPDATE bot_state SET flightcode_channel_id = 'ghost' WHERE guild_id = ?").run(G);
  const warn = console.warn; console.warn = () => {};
  await rotator.tickGuild(client, G, { nowMs: Date.now() + 200 * 60_000, state: rst });
  await rotator.tickGuild(client, G, { nowMs: Date.now() + 201 * 60_000, state: rst });       // within retry backoff
  console.warn = warn;
  assert.ok(rst.retryAfter.has(G), 'failed rotation backs off');
  db.prepare("UPDATE bot_state SET flightcode_channel_id = 'codes' WHERE guild_id = ?").run(G);
  ok('rotator: rotates on interval, backs off after a failed post');

  assert.match(await run({ sub: 'disable' }), /off/);
  assert.strictEqual(config.get(G).flightcode_enabled, 0);
  ok('/aewc flightcode disable');

  // ---------- migrating a pre-flightcode database ----------
  const tmp = path.join(os.tmpdir(), `aewc-mig-${process.pid}.db`);
  fs.rmSync(tmp, { force: true });
  const Database = require('better-sqlite3');
  const old = new Database(tmp);
  old.exec("CREATE TABLE bot_state (guild_id TEXT PRIMARY KEY, picture_channel_id TEXT, picture_message_id TEXT, threat_log_channel_id TEXT, patrol_log_channel_id TEXT, intel_channel_id TEXT, threat_spawn_min_s INTEGER NOT NULL DEFAULT 300, threat_spawn_max_s INTEGER NOT NULL DEFAULT 1200, threat_population_cap INTEGER NOT NULL DEFAULT 8, poll_interval_s INTEGER NOT NULL DEFAULT 45, patrol_grace_period_s INTEGER NOT NULL DEFAULT 300, created_at TEXT NOT NULL DEFAULT (datetime('now')), updated_at TEXT NOT NULL DEFAULT (datetime('now')));INSERT INTO bot_state (guild_id, picture_channel_id) VALUES ('old1','chanX');");
  old.close();
  execFileSync(process.execPath, [path.join(__dirname, '..', 'src', 'db', 'migrate.js')], { env: { ...process.env, DB_PATH: tmp }, stdio: 'pipe' });
  execFileSync(process.execPath, [path.join(__dirname, '..', 'src', 'db', 'migrate.js')], { env: { ...process.env, DB_PATH: tmp }, stdio: 'pipe' }); // idempotent
  const upgraded = new Database(tmp);
  const cols = upgraded.prepare('PRAGMA table_info(bot_state)').all().map((r) => r.name);
  assert.ok(cols.includes('flightcode_current') && cols.includes('flightcode_scramble_role_id'));
  assert.strictEqual(upgraded.prepare("SELECT picture_channel_id, flightcode_enabled, flightcode_length FROM bot_state WHERE guild_id='old1'").get().picture_channel_id, 'chanX', 'existing data preserved');
  upgraded.close(); fs.rmSync(tmp, { force: true });
  ok('existing database upgrades in place (columns added, data preserved, re-run is a no-op)');

  console.log(`\n${n} checks passed`);
})().catch((e) => { console.error('\nFAILED:', e); process.exit(1); });
