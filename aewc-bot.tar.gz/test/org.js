// Organization: ranks, onboarding, wings/squadrons/seats, role sync, rosters, org chart, patrol hours.
process.env.DB_PATH = ':memory:';
const assert = require('assert');
require('../src/db/migrate')();

const db = require('../src/db/index');
const config = require('../src/db/repos/config');
const tags = require('../src/db/repos/tags');
const pilots = require('../src/db/repos/pilots');
const patrols = require('../src/db/repos/patrols');
const orgRepo = require('../src/db/repos/org');
const roster = require('../src/services/roster');
const presence = require('../src/loops/presencePoller');
const { periodStartUnix } = require('../src/util/time');
const { parseRanksSpec } = require('../src/util/roles');

const cmds = {
  ranks: require('../src/commands/ranks/ranks.js'), promote: require('../src/commands/promote/promote.js'),
  onboard: require('../src/commands/onboard/onboard.js'), force: require('../src/commands/force/force.js'),
  patrol: require('../src/commands/patrol/patrol.js'), pilot: require('../src/commands/pilot/pilot.js'),
};

// ---------- fakes ----------
const sent = []; const msgs = new Map(); let seq = 0;
function mk() { const id = `m${++seq}`; const m = { id, deleted: false, delete: async () => { m.deleted = true; msgs.delete(id); } }; msgs.set(id, m); return m; }
function chan(id) { return { id, isTextBased: () => true, send: async (p) => { const m = mk(); sent.push({ channel: id, payload: p, id: m.id }); return m; }, messages: { fetch: async (mid) => { const m = msgs.get(mid); if (!m) throw new Error('Unknown Message'); return m; } } }; }
const chans = Object.fromEntries(['chW', 'chW2', 'pic', 'threat', 'patrol', 'intel'].map((id) => [id, chan(id)]));
const client = { channels: { fetch: async (id) => chans[id] ?? null } };
const rosterPosts = (c) => sent.filter((s) => s.channel === c);

const ROLE_IDS = ['2001', '2002', '2003', '2004', '3001', '3002', '3003', '4001', '4002'];
const MEMBER_IDS = ['w1', 'w2', 'sc', 'u1', 'u2', 'u3', 'u4', 'u5'];
const roles = new Map(ROLE_IDS.map((id) => [id, { id, name: `role-${id}` }]));
const held = new Map(MEMBER_IDS.map((id) => [id, new Set()]));
const failAdd = new Set();
const guild = {
  roles: { cache: roles },
  members: {
    me: { permissions: { has: () => true } },
    fetch: async (id) => {
      if (!held.has(id)) throw new Error('Unknown Member');
      const set = held.get(id);
      return { id, roles: { cache: { has: (r) => set.has(r) }, add: async (r) => { if (failAdd.has(r)) throw new Error('Missing Permissions'); set.add(r); }, remove: async (r) => { set.delete(r); } } };
    },
  },
};
const G = 'g1';
const okCh = (id) => ({ id, permissionsFor: () => ({ has: () => true }) });
const U = (id) => ({ id, bot: false });
const R = (id) => ({ id, name: `role-${id}`, mentionable: true });

async function run(cmd, { group = null, sub = null, opts = {}, admin = false, controller = false, user = 'adm' }) {
  const replies = [];
  const i = {
    guildId: G, guild, client, user: { id: user, tag: user }, memberPermissions: { has: () => admin },
    member: { roles: { cache: { some: (fn) => controller && fn({ name: 'AEW&C Controller' }) } } },
    options: {
      getSubcommandGroup: () => group, getSubcommand: () => sub,
      getString: (k) => opts[k] ?? null, getInteger: (k) => opts[k] ?? null, getBoolean: (k) => opts[k] ?? null,
      getNumber: (k) => opts[k] ?? null, getUser: (k) => opts[k] ?? null, getRole: (k) => opts[k] ?? null, getChannel: (k) => opts[k] ?? null,
    },
    reply: async (p) => { replies.push(p); }, deferReply: async () => {}, followUp: async (p) => { replies.push(p); },
    editReply: async (p) => { replies.push(typeof p === 'string' ? { content: p } : p); },
  };
  await cmds[cmd].execute(i);
  return replies.map((r) => r.content ?? r.embeds?.map((e) => `${e.data.title ?? ''}\n${e.data.description ?? ''}${(e.data.fields ?? []).map((f) => `\n${f.name}: ${f.value}`).join('')}`).join('\n')).join('\n');
}
async function auto(cmd, name, value) {
  let choices = null;
  await cmds[cmd].autocomplete({ guildId: G, options: { getFocused: (full) => (full ? { name, value } : value) }, respond: async (c) => { choices = c; } });
  return choices.map((c) => c.value);
}
const roleSet = (id) => [...held.get(id)].sort().join(',');

(async () => {
  let n = 0; const ok = (m) => { console.log(`  ✓ ${m}`); n++; };
  roster.configure({ debounce: 3_600_000 }); // timers never fire; tests flush explicitly

  // ================= patrol hours (pure windows) =================
  const now = Date.UTC(2026, 10, 13, 15, 0, 0); const nowU = now / 1000;           // Fri 13 Nov 2026 15:00 UTC
  const ins = db.prepare("INSERT INTO patrols (guild_id, discord_id, status, started_at, ended_at, auto_started) VALUES ('gp', ?, ?, ?, ?, 0)");
  ins.run('a', 'ended', '2026-11-10 10:00:00', '2026-11-10 12:00:00');   // 2 h
  ins.run('a', 'ended', '2026-11-08 22:00:00', '2026-11-09 02:00:00');   // 4 h, straddles Monday 00:00 (2 h this week)
  ins.run('b', 'ended', '2026-10-30 08:00:00', '2026-10-30 11:00:00');   // 3 h, last month
  ins.run('b', 'ended', '2025-12-31 22:00:00', '2026-01-01 01:00:00');   // 3 h, straddles New Year (1 h this year)
  ins.run('c', 'active', '2026-11-13 13:30:00', null);                   // still open: 1.5 h up to "now"
  const stat = (period, extra = {}) => Object.fromEntries(patrols.statsByPilot('gp', { fromUnix: periodStartUnix(period, now), nowUnix: nowU, ...extra }).map((r) => [r.discord_id, [r.secs / 3600, r.patrols]]));
  assert.deepStrictEqual(stat('week'), { a: [4, 2], c: [1.5, 1] }, 'week: straddling patrol is clipped to Monday 00:00');
  assert.deepStrictEqual(stat('month'), { a: [6, 2], c: [1.5, 1] });
  assert.deepStrictEqual(stat('year'), { a: [6, 2], b: [4, 2], c: [1.5, 1] }, 'year: the New Year patrol counts only its 2026 hour');
  assert.deepStrictEqual(stat('all'), { a: [6, 2], b: [6, 2], c: [1.5, 1] });
  assert.deepStrictEqual(Object.keys(stat('year')), ['a', 'b', 'c'], 'sorted by hours flown');
  assert.deepStrictEqual(stat('all', { discordId: 'b' }), { b: [6, 2] });
  assert.strictEqual(new Date(periodStartUnix('week', now) * 1000).toISOString(), '2026-11-09T00:00:00.000Z');
  ok('patrol hours: week/month/year/all windows, clipping at boundaries, open patrols count to now, sorted');

  // auto-ended patrols stop the clock when the pilot was last SEEN, not when the grace period ran out
  config.setChannels('gz', { picture: 'pic', threatLog: 'threat', patrolLog: 'patrol', intel: 'intel' });
  const p = patrols.start('gz', { discordId: 'z', aircraft: 'X', callsignTag: 'SAAF', auto: true });
  db.prepare("UPDATE patrols SET started_at = datetime('now','-3600 seconds'), last_seen_at = datetime('now','-1000 seconds') WHERE id = ?").run(p.id);
  const seen = patrols.get(p.id).last_seen_at;
  await presence.processGuild(client, 'gz', [], { state: presence.newState() });
  const ended = patrols.get(p.id);
  assert.strictEqual(ended.status, 'ended'); assert.strictEqual(ended.ended_at, seen, 'ended_at = last time the pilot was seen');
  const h = patrols.statsByPilot('gz', { nowUnix: Math.floor(Date.now() / 1000) })[0].secs;
  assert.ok(h > 2500 && h < 2700, `~2600 s flown (3600 − 1000), not 3600 (${h})`);
  ok('auto-ended patrols count flight time only up to the last sighting');

  // ================= rank spec parsing =================
  const spec = (s) => parseRanksSpec(guild, s);
  assert.deepStrictEqual(spec('<@&2001>,<@&2002>;Cadet,2nd Lieutenant').ranks, [{ name: 'Cadet', roleIds: ['2001'] }, { name: '2nd Lieutenant', roleIds: ['2002'] }]);
  assert.deepStrictEqual(spec('@role-2001, @role-2002 ; Cadet , Ace').ranks.map((r) => r.roleIds[0]), ['2001', '2002'], 'role names work too');
  assert.deepStrictEqual(spec('<@&2001> <@&2004>,<@&2002>;Cadet,Ace').ranks[0].roleIds, ['2001', '2004'], 'one rank can grant several roles');
  assert.match(spec('<@&2001>,<@&2002> Cadet,Ace').error, /exactly one `;`/);
  assert.match(spec('<@&2001>;Cadet,Ace').error, /1 role\(s\) but 2 rank name/);
  assert.match(spec('<@&99999>;Cadet').error, /couldn't find the role/);
  assert.match(spec('<@&2001>,<@&2002>;Cadet,cadet').error, /twice/);
  assert.match(spec('<@&2001>;').error, /No rank names/);
  ok('rank spec "@roles;Names": mentions or names, one-to-one, helpful errors');

  // ================= /ranks =================
  const ranksArg = '<@&2001>,<@&2002>,<@&2003>;Cadet,2nd Lieutenant,1st Lieutenant';
  assert.match(await run('ranks', { sub: 'setup', opts: { ranks: ranksArg } }), /requires server admin/);
  assert.match(await run('ranks', { sub: 'list' }), /No ranks set up/);
  let out = await run('ranks', { sub: 'setup', admin: true, opts: { ranks: ranksArg, enlisted_roles: '<@&2004>' } });
  assert.match(out, /Rank ladder saved/); assert.match(out, /starts pilots at \*\*Cadet\*\*/); assert.match(out, /Manage Roles/);
  out = await run('ranks', { sub: 'list' });
  assert.match(out, /1\. \*\*Cadet\*\*[^]*2\. \*\*2nd Lieutenant\*\*[^]*3\. \*\*1st Lieutenant\*\*/); assert.match(out, /every registered pilot[^]*2004/);
  assert.match(await run('ranks', { sub: 'setup', admin: true, opts: { ranks: ranksArg, enlisted_roles: '<@&88888>' } }), /couldn't find the role/);
  ok('/ranks setup (admin) and /ranks list (open)');

  // ================= squadrons / wings: creation rules =================
  const mkSq = (opts, who = { admin: true }) => run('force', { group: 'squadrons', sub: 'create', ...who, opts });
  assert.match(await mkSq({ squad_name: 'LEOPARD SQUADRON', callsign: 'LEOPARD', pilots: 4, squadron_role: R('3001') }, {}), /requires server admin/);
  assert.match(await mkSq({ squad_name: 'X', callsign: 'LEO-PARD', pilots: 4, squadron_role: R('3001') }), /Invalid callsign/);
  assert.match(await mkSq({ squad_name: '!!', callsign: 'LEOPARD', pilots: 4, squadron_role: R('3001') }), /Invalid squadron name/);
  out = await mkSq({ squad_name: 'Leopard Squadron', callsign: 'leopard', pilots: 4, squadron_role: R('3001') });
  assert.match(out, /Created \*\*LEOPARD SQUADRON\*\* — callsigns LEOPARD-1 … LEOPARD-4/);
  assert.match(await mkSq({ squad_name: 'LEOPARD SQUADRON', callsign: 'OTHER', pilots: 4, squadron_role: R('3001') }), /already a squadron called/);
  assert.match(await mkSq({ squad_name: 'OTHER', callsign: 'LEOPARD', pilots: 4, squadron_role: R('3001') }), /callsign \*\*LEOPARD\*\* is already used/);
  assert.match(await mkSq({ squad_name: 'OTHER', callsign: 'OTHER', pilots: 4, squadron_role: R('3001'), parent_wing: 'NOPE' }), /No wing by that name/);
  ok('/force squadrons create: admin only; name/callsign validation and uniqueness');

  pilots.register(G, 'w1', '900', 'adm'); pilots.register(G, 'w2', '901', 'adm'); pilots.register(G, 'sc', '902', 'adm');
  const mkWing = (opts, who = { admin: true }) => run('force', { group: 'wings', sub: 'create', ...who, opts });
  const wingOpts = { wing_name: '1st Wing', wingcom: U('w1'), wing_role: R('4001'), member_channel: okCh('chW'), force_tag: 'saaf' };
  assert.match(await mkWing(wingOpts, {}), /requires server admin/);
  assert.match(await mkWing({ ...wingOpts, wingcom: U('nobody') }), /isn't a registered pilot/);
  assert.match(await mkWing({ ...wingOpts, member_channel: { id: 'chW', permissionsFor: () => ({ has: () => false }) } }), /can't post/);
  assert.match(await mkWing({ ...wingOpts, force_tag: '!!' }), /Invalid force tag/);
  out = await mkWing(wingOpts);
  assert.match(out, /Created wing \*\*1ST WING\*\* \[SAAF\]/); assert.match(out, /callsign-2 of the first squadron/);
  assert.strictEqual(roleSet('w1'), '2004,4001', 'wingcom gets the enlisted + wing roles straight away');
  assert.strictEqual(tags.listByCategory(G).us.includes('SAAF'), true, "the wing's tag is registered as one of OUR force tags");
  assert.match(await mkWing(wingOpts), /already a wing called/);
  assert.match(await mkWing({ ...wingOpts, wing_name: 'Other', wingcom: U('w1') }), /already commands 1ST WING/);
  ok('/force wings create: validation, wingcom must be registered, gets the wing role, tag becomes a "us" tag');

  // ================= first squadron seats the commanders =================
  out = await mkSq({ squad_name: 'Cobra Squadron', callsign: 'cobra', pilots: 4, squadron_role: R('3002'), squadcom: U('sc'), parent_wing: '1st wing' });
  assert.match(out, /Squadcom <@sc> → \*\*COBRA-1\[SAAF\]\*\*/); assert.match(out, /Wingcom <@w1> → \*\*COBRA-2\[SAAF\]\*\*/);
  assert.strictEqual(orgRepo.assignmentOf(G, 'sc').callsign, 'COBRA-1[SAAF]');
  assert.strictEqual(orgRepo.assignmentOf(G, 'w1').callsign, 'COBRA-2[SAAF]');
  assert.strictEqual(roleSet('sc'), '2004,3002,4001'); assert.strictEqual(roleSet('w1'), '2004,3002,4001');
  ok('squadcom takes callsign-1; wingcom takes callsign-2 of the wing\'s first squadron; roles follow');

  // ================= onboarding =================
  const onboard = (user, squadron, geofs, who = { controller: true }) => run('onboard', { ...who, opts: { user: U(user), squadron, ...(geofs ? { geofs_id: geofs } : {}) } });
  assert.match(await onboard('u1', 'COBRA SQUADRON', '101', {}), /requires the \*\*AEW&C Controller\*\*/);
  assert.match(await onboard('u1', 'NOPE', '101'), /No squadron by that name/);
  assert.match(await onboard('u1', 'COBRA SQUADRON', 'abc'), /numeric account IDs/);
  assert.match(await onboard('u1', 'COBRA SQUADRON'), /isn't registered yet/);
  out = await onboard('u1', 'cobra squadron', '101');
  assert.match(out, /Onboarded <@u1> as \*\*COBRA-3\[SAAF\]\*\* in COBRA SQUADRON · GeoFS ID `101` · rank \*\*Cadet\*\*/);
  assert.strictEqual(roleSet('u1'), '2001,2004,3002,4001', 'enlisted + starting rank + squadron + wing roles');
  assert.strictEqual(pilots.getByDiscord(G, 'u1').geofs_id, '101');
  out = await onboard('u2', 'COBRA SQUADRON', '102');
  assert.match(out, /COBRA-4\[SAAF\]/);
  // squadron is full: refused AND the registration is rolled back
  assert.match(await onboard('u3', 'COBRA SQUADRON', '103'), /COBRA SQUADRON is full \(4\/4\)/);
  assert.strictEqual(pilots.getByDiscord(G, 'u3'), undefined, 'failed onboarding leaves no half-registered pilot');
  assert.deepStrictEqual(held.get('u3').size, 0);
  assert.match(await onboard('u3', 'LEOPARD SQUADRON', '102'), /already registered to <@u2>/);
  assert.match(await onboard('sc', 'LEOPARD SQUADRON'), /holds a command seat/);
  ok('/onboard: registers + seats in the closest slot + gives enlisted/rank/squadron/wing roles; atomic on failure');

  // ================= promote =================
  assert.match(await run('promote', { opts: { user: U('u1'), rank: '2nd lieutenant' } }), /requires the/);
  assert.match(await run('promote', { controller: true, opts: { user: U('u5'), rank: 'Cadet' } }), /isn't a registered pilot/);
  assert.match(await run('promote', { controller: true, opts: { user: U('u1'), rank: 'General' } }), /No rank by that name/);
  assert.match(await run('promote', { controller: true, opts: { user: U('u1'), rank: '2nd lieutenant' } }), /Promoted <@u1> from \*\*Cadet\*\* to \*\*2nd Lieutenant\*\*/);
  assert.strictEqual(roleSet('u1'), '2002,2004,3002,4001', 'rank roles are swapped, other roles untouched');
  assert.match(await run('promote', { controller: true, opts: { user: U('u1'), rank: '2nd Lieutenant' } }), /already/);
  assert.match(await run('promote', { controller: true, opts: { user: U('u1'), rank: 'Cadet' } }), /Demoted/);
  assert.strictEqual(roleSet('u1'), '2001,2004,3002,4001');
  await run('promote', { controller: true, opts: { user: U('u1'), rank: '1st Lieutenant' } });
  assert.deepStrictEqual(await auto('promote', 'rank', 'lieut'), ['2nd Lieutenant', '1st Lieutenant'], 'rank autocomplete filters by what is typed');
  assert.deepStrictEqual(await auto('promote', 'rank', ''), ['Cadet', '2nd Lieutenant', '1st Lieutenant']);
  ok('/promote: swaps rank roles, promote/demote wording, validation, autocomplete');

  // ================= nesting + assign =================
  out = await run('force', { group: 'squadrons', sub: 'create', admin: true, opts: { squad_name: 'Viper', callsign: 'viper', pilots: 1, squadron_role: R('3003'), parent_wing: '1ST WING' } });
  assert.match(out, /Created \*\*VIPER\*\*/); // wing 1's first squadron is COBRA, so a 1-slot VIPER is fine
  assert.deepStrictEqual(orgRepo.squadronsInWing(orgRepo.getWing(G, '1ST WING').id).map((s) => s.name), ['COBRA SQUADRON', 'VIPER']);
  pilots.register(G, 'u4', '104', 'adm');
  assert.match(await run('force', { group: 'squadrons', sub: 'assign', controller: true, opts: { pilot: U('u4'), squadron: 'cobra squadron' } }), /COBRA SQUADRON is full/);
  out = await run('force', { group: 'squadrons', sub: 'assign', controller: true, opts: { pilot: U('u4'), squadron: 'viper' } });
  assert.match(out, /Assigned <@u4> to \*\*VIPER-1\[SAAF\]\*\*/); assert.strictEqual(roleSet('u4'), '2004,3003,4001');
  assert.match(await run('force', { group: 'squadrons', sub: 'assign', controller: true, opts: { pilot: U('u4'), squadron: 'viper' } }), /already in VIPER as \*\*VIPER-1/);
  assert.match(await run('force', { group: 'squadrons', sub: 'assign', controller: true, opts: { pilot: U('sc'), squadron: 'viper' } }), /squadron commander of COBRA SQUADRON/);
  assert.match(await run('force', { group: 'squadrons', sub: 'assign', controller: true, opts: { pilot: U('w1'), squadron: 'viper' } }), /wing commander of 1ST WING/);
  assert.match(await run('force', { group: 'squadrons', sub: 'assign', opts: { pilot: U('u4'), squadron: 'viper' } }), /requires the/);

  // transfer: u2 moves COBRA -> LEOPARD (standalone): closest free slot, roles swap, wing role dropped
  out = await run('force', { group: 'squadrons', sub: 'assign', controller: true, opts: { pilot: U('u2'), squadron: 'leopard squadron' } });
  assert.match(out, /Assigned <@u2> to \*\*LEOPARD-1\*\* \(LEOPARD SQUADRON\) — moved from COBRA SQUADRON/);
  assert.strictEqual(roleSet('u2'), '2001,2004,3001', 'no wing role/tag outside a wing');
  assert.strictEqual(orgRepo.assignmentOf(G, 'u1').callsign, 'COBRA-3[SAAF]');
  ok('/force squadrons assign: closest slot, full squadron refused, command holders refused, transfers swap roles');

  // squadcom assign: bumps the occupant of slot 1 to the next free slot
  orgRepo.onboardPilot(G, { discordId: 'u5', geofsId: '105', squadronId: orgRepo.getSquadron(G, 'LEOPARD SQUADRON').id, actorId: 'adm' }); // LEOPARD-2
  out = await run('force', { group: 'squadcom', sub: 'assign', controller: true, opts: { pilot: U('u1'), squadron: 'leopard squadron' } });
  assert.match(out, /now squadron commander of \*\*LEOPARD SQUADRON\*\* → \*\*LEOPARD-1\*\*/);
  assert.strictEqual(orgRepo.assignmentOf(G, 'u2').callsign, 'LEOPARD-3', 'the previous slot-1 holder was bumped to the next free slot');
  assert.strictEqual(orgRepo.assignmentOf(G, 'u5').callsign, 'LEOPARD-2');
  assert.match(roleSet('u1'), /3001/); assert.ok(!held.get('u1').has('3002') && !held.get('u1').has('4001'), 'left COBRA and the wing');
  assert.match(await run('force', { group: 'squadcom', sub: 'assign', controller: true, opts: { pilot: U('w1'), squadron: 'leopard squadron' } }), /wing commander of 1ST WING; command roles are exclusive/);
  assert.match(await run('force', { group: 'squadcom', sub: 'assign', controller: true, opts: { pilot: U('sc'), squadron: 'leopard squadron' } }), /already commands COBRA SQUADRON/);
  out = await run('force', { group: 'squadcom', sub: 'assign', controller: true, opts: { pilot: U('u2'), squadron: 'leopard squadron' } });
  assert.match(out, /Previous commander <@u1> is now \*\*LEOPARD-\d\*\*/);
  assert.strictEqual(orgRepo.assignmentOf(G, 'u2').callsign, 'LEOPARD-1');
  ok('/force squadcom assign: takes callsign-1, bumps the occupant, exclusive roles, replaces a previous commander');

  // wingcom assign: takes COBRA-2, bumps the old wingcom
  out = await run('force', { group: 'wingcom', sub: 'assign', controller: true, opts: { pilot: U('u5'), wing: '1st wing' } });
  assert.match(out, /now wing commander of \*\*1ST WING\*\* → \*\*COBRA-2\[SAAF\]\*\*/); assert.match(out, /Previous wingcom <@w1> is now COBRA-\d\[SAAF\]/);
  assert.strictEqual(orgRepo.assignmentOf(G, 'u5').callsign, 'COBRA-2[SAAF]');
  assert.ok(roleSet('u5').includes('4001') && roleSet('u5').includes('3002'), 'new wingcom is now in COBRA with the wing role');
  assert.ok(!held.get('u5').has('3001'), 'left LEOPARD');
  assert.match(await run('force', { group: 'wingcom', sub: 'assign', controller: true, opts: { pilot: U('sc'), wing: '1st wing' } }), /squadron commander/);
  assert.match(await run('force', { group: 'wingcom', sub: 'assign', controller: true, opts: { pilot: U('nobody'), wing: '1st wing' } }), /isn't a registered pilot/);
  ok('/force wingcom assign: takes callsign-2 of the first squadron, previous wingcom is moved, exclusivity enforced');

  // ================= nest: first squadron changes =================
  assert.match(await run('force', { group: 'wings', sub: 'create', admin: true, opts: { wing_name: '2nd Wing', wingcom: U('w2'), wing_role: R('4002'), member_channel: okCh('chW2'), force_tag: 'saafb' } }), /Created wing \*\*2ND WING\*\* \[SAAFB\]/);
  assert.match(await run('force', { group: 'squadrons', sub: 'nest', opts: { squadron: 'leopard squadron', parent_wing: '2nd wing' } }), /requires server admin/);
  assert.match(await run('force', { group: 'squadrons', sub: 'nest', admin: true, opts: { squadron: 'nope', parent_wing: '2nd wing' } }), /No squadron by that name/);
  out = await run('force', { group: 'squadrons', sub: 'nest', admin: true, opts: { squadron: 'leopard squadron', parent_wing: '2nd wing' } });
  assert.match(out, /Nested \*\*LEOPARD SQUADRON\*\* in \*\*2ND WING\*\* \[SAAFB\]/); assert.match(out, /Wingcom <@w2> → \*\*LEOPARD-\d\[SAAFB\]\*\*/);
  const w2seat = orgRepo.assignmentOf(G, 'w2');
  assert.strictEqual(w2seat.slot, 2); assert.strictEqual(w2seat.squadron.name, 'LEOPARD SQUADRON');
  assert.ok(held.get('u2').has('4002') && !held.get('u2').has('4001'), 'members swap wing roles on nesting');
  assert.strictEqual(orgRepo.assignmentOf(G, 'u2').callsign, 'LEOPARD-1[SAAFB]', 'callsign tag follows the wing');
  assert.match(await run('force', { group: 'squadrons', sub: 'nest', admin: true, opts: { squadron: 'leopard squadron', parent_wing: '2nd wing' } }), /already in 2ND WING/);

  // move wing 1's FIRST squadron (COBRA) out: its wingcom (u5) is released and re-seated in the new first squadron (VIPER) — needs 2 slots
  out = await run('force', { group: 'squadrons', sub: 'nest', admin: true, opts: { squadron: 'cobra squadron', parent_wing: '2nd wing' } });
  assert.match(out, /needs at least 2 slots/, 'refused: VIPER (1 slot) would become wing 1\'s first squadron and can\'t seat a wingcom');
  assert.strictEqual(orgRepo.getSquadron(G, 'COBRA SQUADRON').wing_id, orgRepo.getWing(G, '1ST WING').id, 'rolled back: COBRA is still in wing 1');
  assert.strictEqual(orgRepo.assignmentOf(G, 'u5').callsign, 'COBRA-2[SAAF]', 'and u5 is still seated');
  ok('/force squadrons nest: first-squadron wingcom seat follows the wing; impossible moves roll back cleanly');

  // ================= first-squadron slot rule =================
  assert.match(await run('force', { group: 'squadrons', sub: 'create', admin: true, opts: { squad_name: 'Tiny', callsign: 'tiny', pilots: 1, squadron_role: R('3003'), parent_wing: '2nd wing' } }), /Created/, 'a 1-slot squadron is fine when it is not first in the wing');
  const w3 = orgRepo.createWing(G, { name: 'EMPTY WING', forceTag: 'EMPT', roleId: '4002', channelId: 'chW2', wingcomId: 'u4' });
  assert.ok(w3.wing);
  assert.match(orgRepo.createSquadron(G, { name: 'ONESLOT', callsign: 'ONE', slots: 1, roleId: '3003', wingId: w3.wing.id }).error, /needs at least 2 slots/);
  assert.strictEqual(orgRepo.getSquadron(G, 'ONESLOT'), undefined, 'the squadron was not created');
  ok('first squadron of a wing with a wingcom needs ≥2 slots; failed creation leaves nothing behind');

  // ================= organization list =================
  orgRepo.createSquadron(G, { name: 'LONE WOLF', callsign: 'WOLF', slots: 3, roleId: '3003' });
  out = await run('force', { group: 'organization', sub: 'list' });
  assert.match(out, /WING 1ST WING\*\* \[SAAF\] — wingcom <@u5>/); assert.match(out, /├─ \*\*COBRA SQUADRON\*\* · COBRA-1…4 · 3\/4 · squadcom <@sc>/);
  assert.match(out, /└─ \*\*VIPER\*\* · VIPER-1…1 · 1\/1/); assert.match(out, /WING 2ND WING\*\* \[SAAFB\]/);
  assert.match(out, /UNATTACHED SQUADRONS\*\*[^]*LONE WOLF/); assert.ok(!/COBRA-1\[SAAF\]`/.test(out), 'no pilot lines unless asked');
  out = await run('force', { group: 'organization', sub: 'list', opts: { show_pilots: true } });
  assert.match(out, /`COBRA-1\[SAAF\]` <@sc>/); assert.match(out, /`COBRA-2\[SAAF\]` <@u5>/); assert.match(out, /`LEOPARD-1\[SAAFB\]` <@u2>/);
  ok('/force organization list: wings, nested squadrons, unattached squadrons; pilot callsigns on request');

  // ================= rosters =================
  const posted = (ch) => rosterPosts(ch).length;
  await roster.flush();                                  // every change above was batched
  const w1posts = rosterPosts('chW');
  assert.ok(w1posts.length >= 1, 'wing 1 roster posted');
  const last = w1posts.at(-1).payload;
  assert.strictEqual(last.content, '<@&4001>'); assert.deepStrictEqual(last.allowedMentions.roles, ['4001']);
  const text = last.embeds.map((e) => e.data.description).join('\n');
  assert.match(text, /`COBRA-1\[SAAF\]` — <@sc>[^\n]*★ SQUADCOM/); assert.match(text, /`COBRA-2\[SAAF\]` — <@u5>[^\n]*★ WINGCOM/); assert.match(text, /VIPER/);
  assert.match(last.embeds[0].data.title, /1ST WING \[SAAF\] — callsign roster/);
  // a rank change re-posts the roster, deletes the previous one, and several changes make ONE post
  const before1 = posted('chW'); const prevMsg = w1posts.at(-1).id;
  await run('promote', { controller: true, opts: { user: U('u1'), rank: 'Cadet' } });   // u1 is in COBRA (wing 1)
  await run('promote', { controller: true, opts: { user: U('u4'), rank: '2nd Lieutenant' } });   // u4 is in VIPER (wing 1)
  assert.strictEqual(posted('chW'), before1, 'nothing posts until the debounce window closes');
  await roster.flush();
  assert.strictEqual(posted('chW'), before1 + 1, 'two changes -> one roster post');
  assert.strictEqual(msgs.has(prevMsg), false, 'the previous roster message was deleted');
  assert.match(rosterPosts('chW').at(-1).payload.embeds[0].data.description, /<@u4>[^\n]*2nd Lieutenant/, 'roster shows ranks');
  assert.ok(posted('chW2') >= 1 && /LEOPARD-1\[SAAFB\]/.test(rosterPosts('chW2').at(-1).payload.embeds[0].data.description), 'wing 2 has its own roster');
  const emptyBefore = posted('chW2');
  orgRepo.setRosterMessage(w3.wing.id, null);
  roster.markDirty(client, G, w3.wing.id); await roster.flush();
  assert.strictEqual(posted('chW2'), emptyBefore, 'a wing with no squadrons posts nothing');
  ok('wing rosters: callsign list with ranks/commander marks, pings the wing role, batched, old one deleted');

  // ================= role problems are reported, not fatal =================
  failAdd.add('2001');
  out = await onboard('u3', 'LONE WOLF', '103');
  assert.match(out, /Onboarded <@u3> as \*\*WOLF-1\*\*/); assert.match(out, /Some roles couldn't be updated/); assert.match(out, /<@&2001>: couldn't add it \(Missing Permissions\)/);
  failAdd.clear();
  pilots.register(G, 'ghost', '777', 'adm');
  out = await onboard('ghost', 'LONE WOLF');
  assert.match(out, /<@ghost>: is not in this server/); assert.ok(orgRepo.assignmentOf(G, 'ghost').squadron, 'they are still seated in the database');
  ok('role failures (missing permission / member left) are reported while the database change still stands');

  // ================= autocomplete =================
  assert.deepStrictEqual(await auto('force', 'squadron', 'co'), ['COBRA SQUADRON']);
  assert.deepStrictEqual(await auto('force', 'parent_wing', ''), ['1ST WING', '2ND WING', 'EMPTY WING']);
  assert.deepStrictEqual(await auto('force', 'wing', '2nd'), ['2ND WING']);
  assert.deepStrictEqual(await auto('force', 'squadron', 'zzz'), []);
  assert.deepStrictEqual(await auto('onboard', 'squadron', 'wol'), ['LONE WOLF']);
  ok('autocomplete for squadrons, wings and ranks');

  // ================= patrol leaderboard / total commands =================
  const nowS = Math.floor(Date.now() / 1000);
  const sqlTs = (u) => new Date(u * 1000).toISOString().replace('T', ' ').slice(0, 19);
  const insR = db.prepare("INSERT INTO patrols (guild_id, discord_id, status, started_at, ended_at, auto_started) VALUES (?, ?, 'ended', ?, ?, 0)");
  insR.run(G, 'u1', sqlTs(nowS - 7200), sqlTs(nowS - 3600));        // 1 h
  insR.run(G, 'u1', sqlTs(nowS - 5400), sqlTs(nowS - 2700));        // 0.75 h more (1.75 h total)
  insR.run(G, 'u2', sqlTs(nowS - 14400), sqlTs(nowS - 3600 * 2));   // 2 h
  assert.match(await run('patrol', { sub: 'total', user: 'u1', opts: { period: 'all' } }).catch(() => ''), /./);
  out = await run('patrol', { sub: 'total', user: 'u1', opts: { user: U('u1'), period: 'all' } });
  assert.match(out, /<@u1> — \*\*1\.8 h \(1 h 45 m\)\*\* across 2 patrols \(all time\)/);
  out = await run('patrol', { sub: 'total', opts: { user: U('nobody2'), period: 'year' } });
  assert.match(out, /No patrols logged for <@nobody2> this year/);
  out = await run('patrol', { sub: 'leaderboard', opts: { period: 'all' } });
  assert.match(out, /Patrol leaderboard — all time/); assert.ok(out.indexOf('<@u2>') < out.indexOf('<@u1>'), 'u2 (2 h) ranks above u1 (1.75 h)');
  assert.match(out, /🥇 <@u2> — \*\*2\.0 h\*\* · 1 patrol\b/); assert.match(out, /🥈 <@u1> — \*\*1\.8 h\*\* · 2 patrols/);
  assert.match(await run('patrol', { sub: 'leaderboard', opts: { period: 'week' } }), /Patrol leaderboard — this week|No patrols logged this week/);
  out = await run('pilot', { sub: 'lookup', opts: { discord_user: U('u1') } });
  assert.match(out, /Callsign \/ rank: [^\n]*Cadet/); assert.match(out, /Patrol hours \(all time\): 1\.8 h/);
  ok('/patrol total & /patrol leaderboard (periods, ranking, hours); /pilot lookup shows callsign, rank, hours');

  console.log(`\n${n} checks passed`);
})().catch((e) => { console.error('\nFAILED:', e); process.exit(1); });
