// One-off check that the GeoFS /map feed is reachable from THIS machine and has the fields
// the bot relies on. Run it on the Alpine VM:   npm run probe
// Optionally pass force tags to see how callsigns parse:   npm run probe -- SAAF USAF UAEAF
require('dotenv').config();
const { fetchRaw, normalizeUser, HOST } = require('../src/services/geofs');

(async () => {
  console.log(`POST ${HOST}/map ...`);
  const raw = await fetchRaw(globalThis.fetch);
  const users = raw.users;
  const withAcid = users.filter((u) => u.acid != null && Number(u.acid) > 0);
  const withCs = users.filter((u) => typeof u.cs === 'string' && u.cs.length);
  console.log(`userCount=${raw.userCount}  entries=${users.length}  with acid=${withAcid.length}  with callsign=${withCs.length}  traffic(ad)=${users.filter((u) => u.ad).length}`);
  console.log('raw keys on first entry:', users[0] ? Object.keys(users[0]).join(', ') : '(none)');

  const tags = process.argv.slice(2).map((t) => t.toUpperCase());
  const players = users.map(normalizeUser).filter(Boolean);
  const shown = (tags.length
    ? players.filter((p) => tags.some((t) => p.callsign.toUpperCase().includes(`[${t}]`)))
    : players
  ).slice(0, 15);
  console.log(`\n${tags.length ? `Callsigns containing ${tags.map((t) => `[${t}]`).join(' / ')}` : 'First players'} (${shown.length} shown):`);
  for (const p of shown) console.log(`  id=${p.geofsId.padEnd(9)} callsign=${JSON.stringify(p.callsign)}`);
  if (!withAcid.length) console.log('\n!! No entries have an "acid" field — tell me and I will adapt the identity lookup.');
})().catch((e) => { console.error('Probe failed:', e.message); process.exit(1); });
