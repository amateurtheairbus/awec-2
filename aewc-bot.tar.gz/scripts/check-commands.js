// Validates every slash command definition against Discord's documented limits, offline.
//   npm run check-commands
const NAME_RE = /^[\p{L}\p{N}_-]{1,32}$/u;
let problems = 0;
const bad = (cmd, where, msg) => { problems++; console.error(`✗ /${cmd} ${where}: ${msg}`); };

function size(node) {   // characters counted toward Discord's 8000-per-command budget
  let n = (node.name?.length ?? 0) + (node.description?.length ?? 0);
  for (const c of node.choices ?? []) n += c.name.length + String(c.value).length;
  for (const o of node.options ?? []) n += size(o);
  return n;
}

function check(cmd, node, where, depth = 0) {
  if (!NAME_RE.test(node.name) || node.name !== node.name.toLowerCase()) bad(cmd, where, `invalid name "${node.name}"`);
  if (!node.description || node.description.length > 100) bad(cmd, where, `description must be 1–100 chars (${node.description?.length})`);
  if ((node.options?.length ?? 0) > 25) bad(cmd, where, 'more than 25 options');
  if ((node.choices?.length ?? 0) > 25) bad(cmd, where, 'more than 25 choices');
  const opts = node.options ?? [];
  const firstOptional = opts.findIndex((o) => !o.required && o.type > 2);
  if (firstOptional !== -1 && opts.slice(firstOptional).some((o) => o.required)) bad(cmd, where, 'a required option comes after an optional one');
  for (const o of opts) check(cmd, o, `${where}/${o.name}`, depth + 1);
}

const { loadCommands } = require('../src/util/commandLoader');
let total = 0;
for (const mod of loadCommands()) {
  const json = mod.data.toJSON();
  total++;
  check(json.name, json, '');
  const s = size(json);
  if (s > 8000) bad(json.name, '', `command is ${s} chars; Discord's limit is 8000`);
  console.log(`  /${json.name.padEnd(10)} ${String(s).padStart(5)} / 8000 chars`);
}
if (total > 100) bad('*', '', 'more than 100 commands');
console.log(problems ? `\n${problems} problem(s)` : `\n${total} commands OK`);
process.exit(problems ? 1 : 0);
