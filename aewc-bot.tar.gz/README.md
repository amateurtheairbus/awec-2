# AEW&C Bot

Military-roleplay AEW&C Discord bot: live airspace picture, random threat contacts, patrol
logging, intel watchlist, and automatic patrol logging from the GeoFS online-player feed.

## Setup
1. `npm install`  (Alpine: `apk add nodejs npm python3 make g++` first so `better-sqlite3` can compile)
2. Copy `.env.example` to `.env`; set `DISCORD_TOKEN`, `DISCORD_CLIENT_ID` (and `DISCORD_DEV_GUILD_ID` while developing)
3. `npm run migrate` — creates the SQLite schema (also runs automatically on boot)
4. `npm run probe` — **run this on the VM first.** Confirms the GeoFS feed is reachable from there and has the fields
   the bot needs. `npm run probe -- SAAF USAF` also shows how callsigns with those tags look.
5. `npm run deploy-commands`, then `npm start`
6. In Discord: `/aewc setup`, `/aewc tags add SAAF` (etc.), `/pilot register`, `/intel add`
7. `/aewc flightcode setup` (optional, see below)
8. `npm test` — 40 checks (fake Discord + fake GeoFS feed)

Alpine service: `deploy/aewc-bot.openrc` (supervise-daemon; auto-restart). Not yet tested on a live OpenRC box.

## How it works
- **SQLite is the source of truth.** Every action writes `event_log`, mirrors to the right channel, then re-renders the
  one live picture message. Discord is only ever a view.
- **GeoFS presence** (`src/services/geofs.js`, `src/loops/presencePoller.js`): POSTs the same `/map` endpoint the in-sim
  map uses (no login, never joins the sim, at most one request / 10 s shared across guilds). GeoFS ID = account ID (`acid`).
  - roster pilot online + recognized tag -> auto patrol (records the tag they're flying under)
  - auto patrol with the pilot not seen tagged for the grace period (default 5 min) -> auto-ended
  - a pilot who ends their patrol manually isn't re-patrolled until they drop offline and return
  - a failed poll is "unknown", never "everyone left" — nothing is ended during an outage; poller backs off
  - watchlisted ID appears -> sighting in `event_log`; posted to the intel channel only if that entry's alerts are on
    (5-min cooldown so reconnects don't re-alert)
- **Callsign format**: `NAME[CODE][TAG]` — tag can appear anywhere; the bracket right before it is the flight code.
- **Threat timer** (`src/loops/threatTimer.js`): random spawns between min/max seconds, population cap; unknown contacts
  at expiry are reclassified hostile (30%) / friendly (20%) or fade; others fade. Tunable with `/aewc config`.

## Flight codes (single server, single force)
`/aewc flightcode setup force_tag:SAAF channel:#codes scramble_role:@Scramble [charset] [length=3] [interval_minutes=1440] [alert_channel] [strict]`
- charset: letters+numbers (default) / letters only / numbers only; length 1–8
- Posts a fresh code every interval in the channel (the previous post is deleted so old codes don't linger).
  `/aewc flightcode rotate` forces a new one (e.g. after a suspected leak); `status` and `disable` also exist.
- Every presence poll (~45 s), each online callsign carrying the force tag (`NAME[CODE][SAAF]`) is checked:
  - wrong/missing code + GeoFS ID **on the roster** -> pings that pilot to update their callsign
  - wrong/missing code + ID **not on the roster** -> pings the scramble role and prints **IMPERSONATOR** (with last position)
  - correct code -> nothing
- Defaults I chose (constants at the top of `src/services/flightcode.js`):
  - after a rotation the previous code is still accepted for **10 minutes**
  - an unresolved mismatch pings once, then again only after **1 hour**; fixing the callsign resets this
  - `strict` (off by default) also flags unregistered players who *have* a valid code
- The scramble role must be mentionable, or the bot needs "Mention Everyone", or role pings won't notify anyone.
- If a rotation post fails (permissions/channel), the old code stays live and the bot retries every 5 min.
- The code itself is never written to `event_log` or echoed in alerts.

## Roadmap
### Other
- Optional notice when a roster pilot is online but flying untagged (deliberately omitted: noisy)
- Aircraft names in patrol records (needs the GeoFS aircraft id -> name table)

## Layout
`src/commands/*` slash commands · `src/services/*` ops, logger, picture, geofs client, contact generator ·
`src/loops/*` presence poller, threat timer, flight-code rotator · `src/db/*` schema + repositories · `test/*` · `scripts/probe-geofs.js` · `deploy/*`
