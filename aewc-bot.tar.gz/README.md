# AEW&C Bot

Military-roleplay AEW&C Discord bot: live airspace picture, random threat contacts, patrol
logging, intel watchlist, and automatic patrol logging from the GeoFS online-player feed.

## Setup
1. `npm install`  (Alpine: `apk add nodejs npm python3 make g++` first so `better-sqlite3` can compile)
2. Copy `.env.example` to `.env`; set `DISCORD_TOKEN`, `DISCORD_CLIENT_ID` (and `DISCORD_DEV_GUILD_ID` while developing)
3. `npm run migrate` — creates the SQLite schema (also runs automatically on boot)
4. `npm run probe` — **run this on the VM first.** Confirms the GeoFS feed is reachable from there and has the fields
   the bot needs. `npm run probe -- SAAF USAF` also shows how callsigns with those tags look.
5. `npm run deploy-commands`, then `npm start`
6. In Discord: `/aewc setup` (include `scramble_role`), then your tags — `/tags add us tags:SAAF`, `/tags add friendly tags:USAF, UAEAF`,
   `/tags add hostile tags:...` — then `/pilot register`, `/intel add`. **Re-run `npm run deploy-commands` after updating the bot.**
7. `/aewc flightcode setup` (optional, see below)
8. `/territory add` to define scramble airspace (optional — see below)
9. Organization (optional): `/ranks setup`, `/force wings create`, `/force squadrons create`, `/onboard` — see below
10. `npm test` — 85 checks; `npm run check-commands` validates the command definitions against Discord's limits (fake Discord + fake GeoFS feed)

Alpine service: `deploy/aewc-bot.openrc` (supervise-daemon; auto-restart). Not yet tested on a live OpenRC box.

## How it works
- **SQLite is the source of truth.** Every action writes `event_log`, mirrors to the right channel, then re-renders the
  one live picture message. Discord is only ever a view.
- **Callsigns are normalized first** (`src/util/callsign.js`): upper-cased, whitespace collapsed, full-width brackets folded,
  invisible characters stripped — *before* any tag or flight-code recognition. Everything the bot stores or displays is ALL CAPS.
- **Tag categories** (`/tags`): `us` = our force, `friendly` = allies, `hostile` = enemies. A callsign can carry several
  tags; **hostile beats us beats friendly**, so a hostile tag can't hide behind one of ours. `/tags add ...` takes several tags
  at once (commas/spaces, brackets optional); re-adding a tag under another category moves it. Add/remove need the
  AEW&C Controller role (or Manage Server); `/tags list` is open to everyone.
- **GeoFS presence** (`src/services/geofs.js`, `src/loops/presencePoller.js`): POSTs the same `/map` endpoint the in-sim
  map uses (no login, never joins the sim, at most one request / 10 s shared across guilds). GeoFS ID = account ID (`acid`).
  - roster pilot online under one of **our** tags -> auto patrol (records the tag they're flying under)
  - auto patrol with the pilot not seen under our tag for the grace period (default 5 min) -> auto-ended
  - a pilot who ends their patrol manually isn't re-patrolled until they drop offline and return
  - a failed poll is "unknown", never "everyone left" — nothing is ended during an outage; poller backs off
  - watchlisted ID appears -> sighting in `event_log`; posted to the intel channel only if that entry's alerts are on
    (5-min cooldown so reconnects don't re-alert)
- **Live contacts** (`src/services/liveContacts.js`): a player seen under a **friendly** or **hostile** tag becomes a contact on
  the picture, named by their ALL-CAPS callsign (e.g. `VIPER-1[K9X][RUAF]`).
  - friendly: posted to the threat log, never scrambled
  - hostile: posted, and **scrambles (pings the scramble role) when inside your scramble airspace** — see `/territory` below
  - a contact fades after **3 minutes** undetected; if the player returns it's a new contact (and scrambles again)
  - if a tag is re-categorized while its player is online, the contact is reclassified (scrambling if it became hostile)
  - position is shown as `BULL 090/60 nm` (bearing/range from a **bullseye** you set with `/aewc config bullseye_lat/lon`),
    or plain coordinates until a bullseye is set. Live contacts can't be cleared by hand — they'd instantly reappear.
- **Simulated contacts** (`src/loops/threatTimer.js`) are now **opt-in**: `/aewc config threat_sim:true`. They're named
  `SIM-####`, expire/escalate as before, and `/contact spawn` still injects one on demand for training.
- **Callsign format**: `NAME[CODE][TAG]` — tag can appear anywhere; the bracket right before it is the flight code.

## Organization
**Bot permissions:** organization commands add/remove roles, so the bot needs **Manage Roles**, and its own role must sit
**above** every rank / squadron / wing role in Server Settings → Roles. (Invite URL permissions integer: `268520448`.)
If a role can't be changed the command still succeeds and lists exactly which roles failed.

- **Ranks** — `/ranks setup ranks:"@of-1,@of-2;2nd Lieutenant,1st Lieutenant" [enlisted_roles:"@Pilot"]`
  Roles on the left of the `;`, rank names on the right, matched one-to-one, **lowest rank first** (an item may mention several
  roles). `enlisted_roles` are given to every registered pilot. `/ranks list` shows the ladder.
- **`/promote user rank`** — sets the rank (promote or demote); swaps that pilot's rank roles. Rank autocompletes.
- **Wings** — `/force wings create wing_name wingcom wing_role member_channel force_tag`. The wing's tag becomes one of *our* tags.
  The wingcom takes **callsign-2 of the wing's first squadron** (the first one nested in) and gets the wing role immediately.
- **Squadrons** — `/force squadrons create squad_name callsign pilots squadron_role [squadcom] [parent_wing]` makes slots
  `LEOPARD-1 … LEOPARD-N`; the squadcom carries callsign-1. `/force squadrons nest squadron parent_wing` moves it into a wing
  (members swap to the new wing's role and `[TAG]`). `/force squadrons assign pilot squadron` takes the **closest free slot**.
- **Commanders** — `/force squadcom assign pilot squadron` (callsign-1) and `/force wingcom assign pilot wing` (callsign-2 of the
  first squadron). Taking a command seat bumps whoever is there to the next free slot; if the squadron has no room, nothing changes.
  Command roles are exclusive (one pilot can't command two things), and commanders must already be registered.
- **`/onboard user squadron [geofs_id]`** — registers the pilot (GeoFS ID needed unless already registered), seats them in the closest
  free slot, and gives them the enlisted roles + the lowest rank + squadron + wing roles. All-or-nothing: a full squadron leaves
  no half-registered pilot behind.
- **Roles are reconciled, not just added:** a pilot's managed roles (enlisted, rank, squadron, wing) are always made to match the
  database; other roles are never touched.
- **Wing rosters** — whenever a wing's seats or ranks change, a fresh callsign roster (with ranks and ★ SQUADCOM / ★ WINGCOM marks) is
  posted in the wing's member channel pinging the wing role, and the previous one is deleted. Changes are batched (10 s), so bulk
  onboarding makes one post. Wings with no squadrons post nothing.
- **`/force organization list [show_pilots]`** — text chart of every wing, its nested squadrons, and unattached squadrons.
- Permissions: structure (`/ranks setup`, `/force wings create`, `squadrons create/nest`) needs Manage Server; day-to-day
  (`/onboard`, `/promote`, the assign commands) needs the AEW&C Controller role; the list views are open to everyone.
- Autocomplete is on for squadron, wing and rank options.

## Patrol hours
Computed straight from the patrol records, so every patrol counts automatically. `/patrol total [period] [user]` and
`/patrol leaderboard [period]` (top 10) with period **all time / this week / this month / this year** — calendar periods in **UTC**
(weeks start Monday 00:00 UTC). A patrol that straddles the start of a period only counts from that point; a patrol still open
counts up to now. Auto-ended patrols stop counting at the last time the pilot was actually seen, not when the grace period ran out.
`/pilot lookup` also shows callsign, rank and total hours.

## Scramble airspace (`/territory`)
The bot has no built-in idea of "your" airspace — you define it. Until you add a territory, **a hostile scrambles anywhere it is
seen** (the whole GeoFS map). Once you define one or more, hostiles only scramble inside them; hostiles elsewhere are still shown
on the picture and posted, just not scrambled.
- `/territory add name:HOME center_lat:25.2 center_lon:55.3 radius_nm:150` — a circle (great-circle distance)
- `/territory add name:BORDER points:"27,50; 27,60; 29,60; 29,50"` — a polygon, 3–50 `lat,lon` points, auto-closed, handles
  concave shapes and the ±180° dateline (edges are straight lines on the map — fine for regional airspace)
- optional `min_alt_ft` / `max_alt_ft` on either shape: only scramble inside that altitude band
- `/territory list` shows each one (and how many hostiles are inside right now); `/territory remove name:HOME`
- add/remove need the AEW&C Controller role (or Manage Server); list is open. Names are stored in capitals; max 25 per server.
- A scramble fires when a hostile **enters** the airspace, names it (`inside **HOME**`), and does not repeat while it stays.
  Border flapping is debounced: leaving and re-entering within 5 minutes doesn't re-scramble. Contacts inside scramble airspace
  show `⚠ IN HOME` on the picture.

## Flight codes (single server, single force)
`/aewc flightcode setup force_tag:SAAF channel:#codes scramble_role:@Scramble [charset] [length=3] [interval_minutes=1440] [alert_channel] [strict]`
- charset: letters+numbers (default) / letters only / numbers only; length 1–8
- Posts a fresh code every interval in the channel (the previous post is deleted so old codes don't linger).
  `/aewc flightcode rotate` forces a new one (e.g. after a suspected leak); `status` and `disable` also exist.
- Every presence poll (~45 s), each online callsign carrying the force tag (`NAME[CODE][SAAF]`) is checked:
  - wrong/missing code + GeoFS ID **on the roster** -> pings that pilot to update their callsign
  - wrong/missing code + ID **not on the roster** -> pings the scramble role and prints **IMPERSONATOR** (with last position)
  - correct code -> nothing
- Defaults I chose (constants at the top of `src/services/flightcode.js`):
  - after a rotation the previous code is still accepted for **10 minutes**
  - an unresolved mismatch pings once, then again only after **1 hour**; fixing the callsign resets this
  - `strict` (off by default) also flags unregistered players who *have* a valid code
- The scramble role must be mentionable, or the bot needs "Mention Everyone", or role pings won't notify anyone.
- If a rotation post fails (permissions/channel), the old code stays live and the bot retries every 5 min.
- The code itself is never written to `event_log` or echoed in alerts.

## Roadmap
### Other
- Optional notice when a roster pilot is online but flying untagged (deliberately omitted: noisy)
- Aircraft names in patrol records (needs the GeoFS aircraft id -> name table)

## Layout
`src/commands/*` slash commands (aewc, tags, territory, force, onboard, promote, ranks, pilot, intel, patrol, contact, airspace) · `src/services/*` ops, logger, picture, geofs client, contact generator ·
`src/loops/*` presence poller, simulated threat timer, flight-code rotator · `src/db/*` schema + repositories · `test/*` · `scripts/probe-geofs.js` · `deploy/*`
